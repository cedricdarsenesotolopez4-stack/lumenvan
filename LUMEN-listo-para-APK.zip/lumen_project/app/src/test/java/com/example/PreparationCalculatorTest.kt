package com.example

import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.UnitEntity
import com.example.domain.PreparationCalculator
import com.example.domain.RecommendationKind
import com.example.domain.RecommendationUseCase
import com.example.domain.TopicMasteryState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PreparationCalculatorTest {

    private val mathSubject = SubjectEntity(
        id = 1L,
        name = "Matemáticas",
        area = "Ciencias Exactas",
        description = "Cálculo y álgebra",
        iconKey = "functions",
        colorHex = "#394BFA"
    )

    private val course = CourseEntity(
        id = 10L,
        subjectId = 1L,
        title = "Cálculo",
        description = "Curso base",
        level = "Intermedio",
        coverKey = "math"
    )

    private val units = listOf(
        UnitEntity(101L, 10L, "Número", "Aritmética", 1),
        UnitEntity(102L, 10L, "Álgebra", "Polinomios", 2),
        UnitEntity(103L, 10L, "Variación", "Límites", 3),
        UnitEntity(104L, 10L, "Geometría", "Vectores", 4),
        UnitEntity(105L, 10L, "Estadística", "Datos", 5)
    )

    @Test
    fun `unstarted subject reports zero percent readiness`() {
        val topics = listOf(
            TopicEntity(1L, 101L, "Enteros", "Obj", masteryPercent = 0, isCompleted = false, orderIndex = 1),
            TopicEntity(2L, 102L, "Ecuaciones", "Obj", masteryPercent = 0, isCompleted = false, orderIndex = 1)
        )
        val report = PreparationCalculator.computeForSubject(
            subject = mathSubject,
            courses = listOf(course),
            units = units,
            topics = topics,
            lessons = emptyList(),
            quizzes = emptyList(),
            flashcards = emptyList(),
            sessions = emptyList()
        )
        assertEquals(0, report.overallPercent)
        assertEquals(5, report.segments.size)
        assertTrue(report.segments.all { it.readinessPercent == 0 })
    }

    @Test
    fun `mastered topics lessons quizzes flashcards and sessions increase readiness proportionately`() {
        val topics = listOf(
            TopicEntity(1L, 101L, "Enteros", "Obj", masteryPercent = 100, isCompleted = true, orderIndex = 1),
            TopicEntity(2L, 102L, "Ecuaciones", "Obj", masteryPercent = 70, isCompleted = false, orderIndex = 1)
        )
        val lesson = LessonEntity(
            id = 1L,
            courseId = 10L,
            unitId = 101L,
            title = "Límite",
            subtitle = "Sub",
            level = "Intermedio",
            durationMinutes = 15,
            explanation = "Exp",
            definitionsRaw = "",
            examplesRaw = "",
            diagramType = "TANGENT",
            comprehensionQuestion = "Q",
            comprehensionOptionsRaw = "A|||B",
            comprehensionAnswerIndex = 0,
            practicalActivity = "Act",
            evaluationQuestion = "Eval",
            evaluationOptionsRaw = "A|||B",
            evaluationAnswerIndex = 0,
            currentStage = 4,
            isCompleted = true,
            scorePercent = 100
        )
        val quiz = QuizEntity(
            id = 1L,
            title = "Test",
            subjectName = "Matemáticas",
            description = "Desc",
            bestScorePercent = 80,
            attemptsCount = 1
        )
        val card = FlashcardEntity(
            id = 1L,
            subjectName = "Matemáticas",
            front = "F",
            back = "B",
            masteryLevel = 4,
            repetitions = 2
        )
        val session = StudySessionEntity(
            id = 1L,
            subjectName = "Matemáticas",
            durationMinutes = 60,
            focusNotes = "Estudio",
            dateEpochDay = LocalDate.now().toEpochDay()
        )

        val report = PreparationCalculator.computeForSubject(
            subject = mathSubject,
            courses = listOf(course),
            units = units,
            topics = topics,
            lessons = listOf(lesson),
            quizzes = listOf(quiz),
            flashcards = listOf(card),
            sessions = listOf(session)
        )

        // Expected: topics=85*0.45 (38.25) + lessons=100*0.25 (25) + quizzes=80*0.15 (12) + flashcards=80*0.10 (8) + session=50*0.05 (2.5) = 85.75 -> 86
        assertEquals(86, report.overallPercent)
        assertEquals(100, report.segments[0].readinessPercent)
        assertEquals(70, report.segments[1].readinessPercent)
    }

    @Test
    fun `topic mastery states map cleanly across all four levels`() {
        assertEquals(TopicMasteryState.NOT_STARTED, TopicMasteryState.fromTopic(TopicEntity(1, 1, "T", "", 0, false)))
        assertEquals(TopicMasteryState.LEARNING, TopicMasteryState.fromTopic(TopicEntity(1, 1, "T", "", 30, false)))
        assertEquals(TopicMasteryState.PRACTICED, TopicMasteryState.fromTopic(TopicEntity(1, 1, "T", "", 70, false)))
        assertEquals(TopicMasteryState.MASTERED, TopicMasteryState.fromTopic(TopicEntity(1, 1, "T", "", 100, true)))
    }

    @Test
    fun `recommendation engine prioritizes upcoming exams and weakest segments`() {
        val report = PreparationCalculator.computeForSubject(
            subject = mathSubject,
            courses = listOf(course),
            units = units,
            topics = listOf(TopicEntity(1L, 101L, "A", "", 100, true, 1)),
            lessons = emptyList(),
            quizzes = emptyList(),
            flashcards = emptyList(),
            sessions = emptyList()
        )
        val exam = ExamEntity(
            id = 1L,
            subjectId = 1L,
            subjectName = "Matemáticas",
            title = "Parcial",
            examDateEpochDay = LocalDate.now().toEpochDay() + 10
        )

        val recs = RecommendationUseCase.buildRecommendations(
            subject = mathSubject,
            segments = report.segments,
            lessons = emptyList(),
            flashcards = emptyList(),
            quizzes = emptyList(),
            exams = listOf(exam)
        )

        assertTrue(recs.any { it.kind == RecommendationKind.PREPARE_EXAM })
        assertTrue(recs.any { it.kind == RecommendationKind.PRACTICE_WEAK_AREA })
        assertTrue(recs.any { it.kind == RecommendationKind.ASK_TUTOR })
    }
}
