package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.FirebaseAiRepository
import com.example.data.ai.LabToolType
import com.example.data.local.LumenDatabase
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LumenPersistenceAndNavTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `navigation across all primary tabs and more hub works`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_list").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_academy").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_subjects_list").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_tutors").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tutors_list").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_library").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("library_notes_list").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_planner").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("planner_list").assertIsDisplayed()

        composeRule.onNodeWithTag("more_hub_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("more_hub_list").assertIsDisplayed()

        composeRule.onNodeWithTag("more_hub_list")
            .performScrollToNode(hasTestTag("more_lessons_card"))
        composeRule.onNodeWithTag("more_lessons_card").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lessons_catalog_list").assertIsDisplayed()

        composeRule.onNodeWithTag("top_bar_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("more_hub_list")
            .performScrollToNode(hasTestTag("more_conversations_card"))
        composeRule.onNodeWithTag("more_conversations_card").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("conversations_list").assertIsDisplayed()

        composeRule.onNodeWithTag("top_bar_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("more_hub_list")
            .performScrollToNode(hasTestTag("more_lab_card"))
        composeRule.onNodeWithTag("more_lab_card").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lab_screen_list").assertIsDisplayed()

        composeRule.onNodeWithTag("top_bar_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("more_hub_list")
            .performScrollToNode(hasTestTag("more_settings_card"))
        composeRule.onNodeWithTag("more_settings_card").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_list").assertIsDisplayed()
    }

    @Test
    fun `interactive flows and form validations work across sections`() {
        composeRule.waitForIdle()

        // Home -> Continue Lesson -> LessonDetailScreen
        composeRule.onNodeWithTag("home_list")
            .performScrollToNode(hasTestTag("home_continue_lesson_button"))
        composeRule.onNodeWithTag("home_continue_lesson_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lesson_detail_screen").assertIsDisplayed()
        composeRule.onNodeWithText("1. Inicio").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lesson_detail_screen")
            .performScrollToNode(hasTestTag("lesson_start_button"))
        composeRule.onNodeWithTag("lesson_start_button").performClick()
        composeRule.waitForIdle()

        composeRule.activityRule.scenario.onActivity { it.onBackPressedDispatcher.onBackPressed() }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_list").assertIsDisplayed()

        // Academy -> Add Subject Dialog -> Validation & Save
        composeRule.onNodeWithTag("nav_academy").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_fab").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("save_subject_button").assertIsNotEnabled()
        composeRule.onNodeWithTag("subject_name_input").performTextInput("Astrofísica")
        composeRule.onNodeWithTag("save_subject_button").assertIsEnabled()
        composeRule.onNodeWithTag("save_subject_button").performClick()
        composeRule.waitForIdle()

        // Library -> Add Note Dialog -> Validation & Save
        composeRule.onNodeWithTag("nav_library").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("library_fab").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("save_note_button").assertIsNotEnabled()
        composeRule.onNodeWithTag("note_title_input").performTextInput("Resumen de Termodinámica")
        composeRule.onNodeWithTag("note_content_input").performTextInput("Primera y segunda ley de la termodinámica.")
        composeRule.onNodeWithTag("save_note_button").assertIsEnabled()
        composeRule.onNodeWithTag("save_note_button").performClick()
        composeRule.waitForIdle()

        // Lab -> Empty input disables generate, valid input enables
        composeRule.onNodeWithTag("more_hub_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("more_hub_list")
            .performScrollToNode(hasTestTag("more_lab_card"))
        composeRule.onNodeWithTag("more_lab_card").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lab_screen_list")
            .performScrollToNode(hasTestTag("lab_generate_button"))
        composeRule.onNodeWithTag("lab_generate_button").assertIsNotEnabled()
        composeRule.onNodeWithTag("lab_topic_input").performTextInput("Leyes de Newton")
        composeRule.onNodeWithTag("lab_generate_button").assertIsEnabled()
    }

    @Test
    fun `room persistence stores notes flashcards lessons and exports backup`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LumenDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = LumenRepository(db)
        repo.ensureSeeded()

        val initialSubjects = repo.subjects.first()
        assertTrue(initialSubjects.size >= 8)

        repo.saveSubject(
            SubjectEntity(
                name = "Economía Política",
                area = "Ciencias Sociales",
                description = "Macroeconomía y ciclos",
                iconKey = "public",
                colorHex = "#4D6BFF",
                masteryLevel = 20
            )
        )
        assertTrue(repo.subjects.first().any { it.name == "Economía Política" })

        repo.saveNote(
            NoteEntity(
                title = "Apunte de Prueba",
                content = "Contenido persistido en Room",
                folder = "Pruebas",
                tagsCsv = "test,room",
                category = "Apunte",
                subjectName = "Matemáticas"
            )
        )
        assertTrue(repo.notes.first().any { it.title == "Apunte de Prueba" })

        val card = FlashcardEntity(
            subjectName = "Matemáticas",
            front = "¿Derivada de sen(x)?",
            back = "cos(x)"
        )
        repo.saveFlashcard(card)
        val savedCard = repo.flashcards.first().first { it.front == "¿Derivada de sen(x)?" }
        repo.reviewFlashcard(savedCard, 5)
        val reviewedCard = repo.flashcards.first().first { it.id == savedCard.id }
        assertEquals(1, reviewedCard.repetitions)
        assertTrue(reviewedCard.nextReviewAt > System.currentTimeMillis())

        val json = repo.exportBackupJson()
        assertTrue(json.contains("Apunte de Prueba"))
        val imported = repo.importBackupJson(json)
        assertTrue(imported > 0)

        db.close()
    }

    @Test
    fun `datastore persists user preferences across reads`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefsRepo = UserPreferencesRepository(context)
        prefsRepo.setUserName("Elena")
        prefsRepo.setDailyStudyGoal(90)
        prefsRepo.setPreferredLevel("Avanzado")
        prefsRepo.setDarkTheme(false)

        val stored = prefsRepo.preferences.first()
        assertEquals("Elena", stored.userName)
        assertEquals(90, stored.dailyStudyGoalMinutes)
        assertEquals("Avanzado", stored.preferredLevel)
        assertFalse(stored.isDarkTheme)

        prefsRepo.setDarkTheme(true)
        assertTrue(prefsRepo.preferences.first().isDarkTheme)
    }

    @Test
    fun `manifest declares internet permission and gemini repository configures tutors and lab`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            android.content.pm.PackageManager.GET_PERMISSIONS
        )
        val permissions = pkgInfo.requestedPermissions?.toList().orEmpty()
        assertTrue(permissions.contains(android.Manifest.permission.INTERNET))
        assertTrue(permissions.contains(android.Manifest.permission.ACCESS_NETWORK_STATE))

        val aiRepo = FirebaseAiRepository(context)
        assertEquals("gemini-3.8-flash", aiRepo.modelId)

        val tutor = TutorEntity(
            name = "Sofía Vance",
            specialty = "Matemáticas",
            avatarInitials = "SV",
            accentHex = "#4D6BFF",
            academicPersonality = "Rigurosa",
            pedagogicalInstructions = "Guía paso a paso",
            subjectArea = "Matemáticas"
        )
        val tutorPrompt = FirebaseAiRepository.buildTutorSystemPrompt(tutor, "Intermedio")
        assertTrue(tutorPrompt.contains("Sofía Vance"))
        assertTrue(tutorPrompt.contains("Guía paso a paso"))
        assertTrue(tutorPrompt.contains("NO reveles la respuesta final de inmediato"))

        LabToolType.entries.forEach { tool ->
            val labPrompt = FirebaseAiRepository.buildLabSystemPrompt(tool, "Avanzado")
            assertTrue(labPrompt.contains(tool.title))
        }
    }

    @Test
    fun `reconstructed academy screen displays radial gauge bottom nav and modals`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nav_academy").performClick()
        composeRule.waitForIdle()

        // Barra superior en 3 zonas, cabecera, paginador, dial, botón '>' y navegación inferior en 3 círculos
        composeRule.onNodeWithTag("academy_streak_pill").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_rewards_pill").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_profile_pill").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_subject_header").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_preparation_gauge").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_preparation_percentage").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_continue_button").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_floating_tutor_button").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_floating_apps_button").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_nav_exams").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_nav_start").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_nav_apps").assertIsDisplayed()

        // Abrir racha diaria y cerrar
        composeRule.onNodeWithTag("academy_streak_pill").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_streak_modal").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Abrir recompensas y cerrar
        composeRule.onNodeWithTag("academy_rewards_pill").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_rewards_modal").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Abrir temas del segmento activo desde el botón circular '>'
        composeRule.onNodeWithTag("academy_continue_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_segment_topics_sheet").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Abrir Exámenes y crear un examen real en Room
        composeRule.onNodeWithTag("academy_nav_exams").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_exams_modal").assertIsDisplayed()
        composeRule.onNodeWithTag("exams_tab_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("exams_new_form_list")
            .performScrollToNode(hasTestTag("exam_title_input"))
        composeRule.onNodeWithTag("exam_title_input").performTextInput("Examen Final de Prueba")
        composeRule.onNodeWithTag("exams_new_form_list")
            .performScrollToNode(hasTestTag("save_exam_button"))
        composeRule.onNodeWithTag("save_exam_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Abrir Apps de aprendizaje y cerrar
        composeRule.onNodeWithTag("academy_nav_apps").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_apps_modal").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Abrir COMENZAR / Ayuda rápida
        composeRule.onNodeWithTag("academy_nav_start").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("academy_start_modal").assertIsDisplayed()
        composeRule.onNodeWithTag("academy_modal_close").performClick()
        composeRule.waitForIdle()

        // Botón flotante de Tutor abre chat contextual con Gemini directamente
        composeRule.onNodeWithTag("academy_floating_tutor_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodes(hasTestTag("tutor_chat_view")).fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("tutor_chat_view").assertIsDisplayed()
    }

    @Test
    fun `exams rewards and points persist cleanly across room and datastore`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LumenDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = LumenRepository(db)
        repo.ensureSeeded()

        val initialExams = repo.exams.first()
        assertTrue(initialExams.isNotEmpty())
        val firstExam = initialExams.first()
        repo.recordExamSimulacro(firstExam, 92)
        val updatedExam = repo.exams.first().first { it.id == firstExam.id }
        assertEquals(92, updatedExam.lastSimulacroScore)
        assertEquals(firstExam.simulacrosCount + 1, updatedExam.simulacrosCount)

        val prefsRepo = UserPreferencesRepository(context)
        prefsRepo.addPoints(40)
        prefsRepo.setAvatarKey("prism")
        val prefs = prefsRepo.preferences.first()
        assertTrue(prefs.pointsBalance >= 120)
        assertEquals("prism", prefs.avatarKey)

        db.close()
    }
}
