package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ActivityLogEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class HomeUiState(
    val greeting: String = "Bienvenido a LUMEN",
    val formattedDate: String = "",
    val userName: String = "Estudiante",
    val overallProgressPercent: Int = 0,
    val completedLessonsCount: Int = 0,
    val totalLessonsCount: Int = 0,
    val todayMinutes: Int = 0,
    val dailyGoalMinutes: Int = 60,
    val dueFlashcardsCount: Int = 0,
    val continueLesson: LessonEntity? = null,
    val continueCourse: CourseEntity? = null,
    val favoriteSubjects: List<SubjectEntity> = emptyList(),
    val pendingTasks: List<PlannerTaskEntity> = emptyList(),
    val quickTutors: List<TutorEntity> = emptyList(),
    val recentActivity: List<ActivityLogEntity> = emptyList(),
    val streakDays: Int = 1,
    val weeklyStudyMask: Int = 0,
    val isLoading: Boolean = true
)

private data class HomePartA(
    val prefs: UserPreferences,
    val subjects: List<SubjectEntity>,
    val courses: List<CourseEntity>,
    val lessons: List<LessonEntity>,
    val tutors: List<TutorEntity>
)

class HomeViewModel(
    private val repository: LumenRepository,
    preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    private val partAFlow = combine(
        preferencesRepository.preferences,
        repository.subjects,
        repository.courses,
        repository.lessons,
        repository.tutors
    ) { prefs, subjects, courses, lessons, tutors ->
        HomePartA(prefs, subjects, courses, lessons, tutors)
    }

    val uiState: StateFlow<HomeUiState> = combine(
        partAFlow,
        repository.tasks,
        repository.studySessions,
        repository.flashcards,
        repository.recentActivity
    ) { partA, tasks, sessions, flashcards, logs ->
        val today = LocalDate.now()
        val todayEpoch = today.toEpochDay()
        val hour = LocalTime.now().hour
        val greeting = when {
            hour < 12 -> "Buenos días"
            hour < 19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        val locale = Locale("es", "ES")
        val dateText = today.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale))
            .replaceFirstChar { it.titlecase(locale) }

        val completedLessons = partA.lessons.count { it.isCompleted }
        val totalLessons = partA.lessons.size
        val avgSubjectMastery = if (partA.subjects.isNotEmpty()) {
            partA.subjects.map { it.masteryLevel }.average().toInt()
        } else 0
        val lessonProgress = if (totalLessons > 0) (completedLessons * 100) / totalLessons else 0
        val overallProgress = ((avgSubjectMastery + lessonProgress) / 2).coerceIn(0, 100)

        val todayMinutes = sessions.filter { it.dateEpochDay == todayEpoch }.sumOf { it.durationMinutes }
        val dueCards = flashcards.count { it.nextReviewAt <= System.currentTimeMillis() }

        val nextLesson = partA.lessons
            .sortedWith(compareBy<LessonEntity> { it.isCompleted }.thenByDescending { it.currentStage }.thenBy { it.id })
            .firstOrNull()
        val nextCourse = nextLesson?.let { l -> partA.courses.find { it.id == l.courseId } }

        val sessionDays = sessions.filter { it.durationMinutes > 0 }.map { it.dateEpochDay }.toSet()
        var streak = 0
        var cursor = if (sessionDays.contains(todayEpoch)) todayEpoch else todayEpoch - 1L
        while (sessionDays.contains(cursor)) {
            streak++
            cursor--
        }
        val mondayEpoch = todayEpoch - (today.dayOfWeek.value - 1).toLong()
        var weekMask = 0
        for (idx in 0..6) {
            if (sessionDays.contains(mondayEpoch + idx)) {
                weekMask = weekMask or (1 shl idx)
            }
        }
        if (weekMask == 0 && completedLessons > 0) {
            weekMask = 1 shl (today.dayOfWeek.value - 1)
            if (streak == 0) streak = 1
        }

        HomeUiState(
            greeting = greeting,
            formattedDate = dateText,
            userName = partA.prefs.userName,
            overallProgressPercent = overallProgress,
            completedLessonsCount = completedLessons,
            totalLessonsCount = totalLessons,
            todayMinutes = todayMinutes,
            dailyGoalMinutes = partA.prefs.dailyStudyGoalMinutes,
            dueFlashcardsCount = dueCards,
            continueLesson = nextLesson,
            continueCourse = nextCourse,
            favoriteSubjects = partA.subjects.filter { it.isFavorite }.ifEmpty { partA.subjects.take(3) },
            pendingTasks = tasks.filter { !it.isCompleted }.take(4),
            quickTutors = partA.tutors.take(4),
            recentActivity = logs.take(6),
            streakDays = streak.coerceAtLeast(1),
            weeklyStudyMask = weekMask,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun toggleTask(task: PlannerTaskEntity) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(task)
        }
    }
}
