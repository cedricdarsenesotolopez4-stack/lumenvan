package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.Lumen3dPrismCore
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenGlassDialog
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.PlannerUiState
import com.example.ui.viewmodel.PlannerViewModel
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun PlannerScreen(
    state: PlannerUiState,
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var showTaskDialog by remember { mutableStateOf(false) }
    var showHabitDialog by remember { mutableStateOf(false) }
    var showSessionDialog by remember { mutableStateOf(false) }

    var timerRunning by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableIntStateOf(0) }
    var activeSubject by remember { mutableStateOf("Matemáticas") }

    LaunchedEffect(timerRunning) {
        while (timerRunning) {
            delay(1000L)
            elapsedSeconds++
        }
    }

    val today = LocalDate.now()
    val calendarDays = remember { (-2L..11L).map { today.plusDays(it) } }
    val locale = Locale("es", "ES")

    Scaffold(
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showTaskDialog = true },
                containerColor = lumenColors.electricBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("planner_add_task_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Añadir tarea u objetivo")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .testTag("planner_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Calendario horizontal futurista
                item {
                    LumenSectionHeader(
                        title = "Agenda de estudio",
                        subtitle = LocalDate.ofEpochDay(state.selectedEpochDay)
                            .month.getDisplayName(TextStyle.FULL, locale)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(calendarDays) { date ->
                            val epoch = date.toEpochDay()
                            val selected = epoch == state.selectedEpochDay
                            val countForDay = state.allTasks.count { it.dueDateEpochDay == epoch && !it.isCompleted }
                            val bgBrush = if (selected) {
                                Brush.verticalGradient(listOf(lumenColors.electricBlueBright, lumenColors.electricBlueDeep))
                            } else {
                                Brush.verticalGradient(
                                    listOf(MaterialTheme.colorScheme.surfaceContainer, MaterialTheme.colorScheme.surfaceContainerLow)
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(58.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(bgBrush)
                                    .border(
                                        1.dp,
                                        if (selected) Color.White.copy(alpha = 0.35f) else lumenColors.cardBorder.copy(alpha = 0.7f),
                                        RoundedCornerShape(18.dp)
                                    )
                                    .clickable { viewModel.selectDay(epoch) }
                                    .padding(vertical = 10.dp)
                            ) {
                                Text(
                                    text = date.dayOfWeek.getDisplayName(TextStyle.SHORT, locale).take(3).uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${date.dayOfMonth}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                                if (countForDay > 0) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(if (selected) Color.White else lumenColors.electricBlueBright)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Agenda del día seleccionado
                item {
                    LumenSectionHeader(
                        title = "Objetivos del día",
                        actionLabel = "+ Nueva",
                        onAction = { showTaskDialog = true }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (state.dayTasks.isEmpty()) {
                        LumenSurfaceCard {
                            Text(
                                "No hay tareas programadas para este día. Pulsa + para añadir una meta o sesión.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.dayTasks.forEach { task ->
                                val prioColor = when (task.priority) {
                                    "ALTA" -> MaterialTheme.colorScheme.error
                                    "MEDIA" -> lumenColors.electricBlueBright
                                    else -> lumenColors.violet
                                }
                                LumenSurfaceCard(borderColor = prioColor.copy(alpha = 0.35f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.toggleTask(task) }) {
                                            Icon(
                                                imageVector = if (task.isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                                contentDescription = "Completar tarea",
                                                tint = if (task.isCompleted) lumenColors.success else prioColor
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(task.title, style = MaterialTheme.typography.titleSmall)
                                            Text(
                                                "${task.dueTimeLabel} · ${task.category} · ${task.subjectName} · ${task.priority}".uppercase(),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = { viewModel.deleteTask(task) }) {
                                            Icon(Icons.Rounded.Delete, contentDescription = "Eliminar tarea", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Sesión de foco en Liquid Glass con Prisma 3D
                item {
                    val mins = elapsedSeconds / 60
                    val secs = elapsedSeconds % 60
                    val focusRatio = ((elapsedSeconds % 1500) * 100 / 1500).coerceAtLeast(if (timerRunning) 12 else 0)
                    LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                        LumenSectionHeader(
                            title = "Cronómetro de foco",
                            actionLabel = "Manual",
                            onAction = { showSessionDialog = true }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Lumen3dPrismCore(progressPercent = focusRatio, modifier = Modifier.size(66.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "%02d:%02d".format(mins, secs),
                                        style = MaterialTheme.typography.displaySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "MATERIA: ${activeSubject.uppercase()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = lumenColors.electricBlueBright
                                    )
                                }
                            }
                            Column(
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(onClick = { timerRunning = !timerRunning }) {
                                    Icon(
                                        imageVector = if (timerRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (timerRunning) "Pausar" else "Iniciar")
                                }
                                Button(
                                    onClick = {
                                        val recorded = (elapsedSeconds / 60).coerceAtLeast(1)
                                        timerRunning = false
                                        elapsedSeconds = 0
                                        viewModel.logStudySession(activeSubject, recorded, "Sesión cronometrada en LUMEN")
                                    },
                                    enabled = elapsedSeconds > 0
                                ) {
                                    Icon(Icons.Rounded.Save, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Guardar")
                                }
                            }
                        }
                    }
                }

                // 4. Progreso semanal (Canvas azul eléctrico / violeta)
                item {
                    LumenSurfaceCard {
                        LumenSectionHeader(
                            title = "Progreso semanal",
                            subtitle = "${state.totalWeekMinutes} minutos en los últimos 7 días"
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        val maxMin = (state.weeklyMinutes.maxOfOrNull { it.minutes } ?: 60).coerceAtLeast(30)
                        val barTop = lumenColors.electricBlueBright
                        val barBottom = lumenColors.violet
                        val track = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(112.dp)
                        ) {
                            val count = state.weeklyMinutes.size.coerceAtLeast(1)
                            val slotW = size.width / count
                            val barW = slotW * 0.48f
                            state.weeklyMinutes.forEachIndexed { idx, pt ->
                                val left = idx * slotW + (slotW - barW) / 2f
                                drawRoundRect(
                                    color = track,
                                    topLeft = Offset(left, 0f),
                                    size = Size(barW, size.height),
                                    cornerRadius = CornerRadius(12f, 12f)
                                )
                                val ratio = (pt.minutes.toFloat() / maxMin).coerceIn(0f, 1f)
                                val barH = size.height * ratio
                                if (barH > 0f) {
                                    drawRoundRect(
                                        brush = Brush.verticalGradient(listOf(barTop, barBottom)),
                                        topLeft = Offset(left, size.height - barH),
                                        size = Size(barW, barH),
                                        cornerRadius = CornerRadius(12f, 12f)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            state.weeklyMinutes.forEach { pt ->
                                Text("${pt.label}\n${pt.minutes}m", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                // 5. Seguimiento de hábitos
                item {
                    LumenSectionHeader(
                        title = "Hábitos de estudio",
                        actionLabel = "+ Hábito",
                        onAction = { showHabitDialog = true }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    val todayEpoch = today.toEpochDay()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        state.habits.forEach { habit ->
                            val doneToday = habit.lastCompletedEpochDay == todayEpoch
                            LumenSurfaceCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { viewModel.toggleHabitToday(habit) }) {
                                        Icon(
                                            imageVector = if (doneToday) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                            contentDescription = "Marcar hábito hoy",
                                            tint = if (doneToday) lumenColors.success else lumenColors.electricBlueBright
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(habit.title, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            "META: ${habit.targetPerWeek} DÍAS/SEM",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    LumenBadge(
                                        text = "${habit.currentStreak} d",
                                        containerColor = lumenColors.blueContainer,
                                        contentColor = lumenColors.electricBlueBright
                                    )
                                    IconButton(onClick = { viewModel.deleteHabit(habit) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Eliminar hábito", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }

                // 6. Historial de sesiones
                item {
                    LumenSectionHeader(title = "Sesiones recientes")
                    Spacer(modifier = Modifier.height(8.dp))
                    LumenSurfaceCard {
                        if (state.sessions.isEmpty()) {
                            Text("Aún no has registrado sesiones de estudio.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            state.sessions.take(5).forEach { s ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(s.subjectName, style = MaterialTheme.typography.titleSmall)
                                        if (s.focusNotes.isNotBlank()) {
                                            Text(s.focusNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    LumenMonospaceTag(text = "${s.durationMinutes} MIN")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTaskDialog) {
        CreateTaskDialog(
            onDismiss = { showTaskDialog = false },
            onConfirm = { title, desc, time, priority, category, subject ->
                viewModel.addTask(title, desc, state.selectedEpochDay, time, priority, category, subject)
                showTaskDialog = false
            }
        )
    }

    if (showHabitDialog) {
        SimpleTwoFieldDialog(
            dialogTitle = "Nuevo hábito de estudio",
            field1Label = "Nombre del hábito",
            field2Label = "Días objetivo por semana (1-7)",
            onDismiss = { showHabitDialog = false },
            onConfirm = { title, targetStr ->
                viewModel.addHabit(title, targetStr.toIntOrNull() ?: 5)
                showHabitDialog = false
            }
        )
    }

    if (showSessionDialog) {
        LogStudySessionDialog(
            onDismiss = { showSessionDialog = false },
            onConfirm = { subj, mins, notes ->
                activeSubject = subj
                viewModel.logStudySession(subj, mins, notes)
                showSessionDialog = false
            }
        )
    }
}

@Composable
private fun CreateTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("18:00") }
    var priority by remember { mutableStateOf("MEDIA") }
    var category by remember { mutableStateOf("Estudio") }
    var subject by remember { mutableStateOf("Matemáticas") }

    LumenGlassDialog(
        title = "Nueva tarea / objetivo",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(title, desc, time, priority, category, subject) },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("save_task_button")
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) {
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Título *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("task_title_input")
        )
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Materia") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Hora (HH:mm)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ALTA", "MEDIA", "BAJA").forEach { p ->
                FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Estudio", "Objetivo", "Repaso").forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Notas") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun LogStudySessionDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, Int, String) -> Unit
) {
    var subject by remember { mutableStateOf("Matemáticas") }
    var minutes by remember { mutableStateOf("30") }
    var notes by remember { mutableStateOf("") }

    LumenGlassDialog(
        title = "Registrar sesión de estudio",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(subject, minutes.toIntOrNull() ?: 30, notes) },
                enabled = (minutes.toIntOrNull() ?: 0) > 0
            ) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) {
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Materia") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = minutes,
            onValueChange = { minutes = it.filter { c -> c.isDigit() } },
            label = { Text("Duración (minutos)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Resumen de lo estudiado") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
    }
}
