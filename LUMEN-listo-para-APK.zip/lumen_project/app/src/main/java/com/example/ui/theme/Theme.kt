package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class LumenExtendedColors(
    val gold: Color, // Mapeado al acento protagonista azul eléctrico brillante para compatibilidad semántica
    val onGold: Color,
    val goldContainer: Color,
    val electricBlue: Color,
    val electricBlueBright: Color,
    val electricBlueDeep: Color,
    val violet: Color,
    val violetContainer: Color,
    val blue: Color,
    val blueContainer: Color,
    val success: Color,
    val warning: Color,
    val cardBorder: Color,
    val elevatedSurface: Color,
    val glassSurface: Color,
    val glassEdgeTop: Color,
    val glassEdgeBottom: Color,
    val academyBg: Color,
    val academyBlackSecondary: Color,
    val academyGraphite: Color,
    val academyDarkGray: Color,
    val academyMediumGray: Color,
    val academyWhite: Color,
    val academyElectricBlue: Color,
    val academyLuminousBlue: Color,
    val academyViolet: Color,
    val academyDeepViolet: Color,
    val isDark: Boolean
)

val LocalLumenColors = staticCompositionLocalOf {
    LumenExtendedColors(
        gold = ElectricBlue,
        onGold = WarmWhiteText,
        goldContainer = ElectricBlueContainer,
        electricBlue = ElectricBlue,
        electricBlueBright = ElectricBlueBright,
        electricBlueDeep = ElectricBlueDeep,
        violet = LuminousViolet,
        violetContainer = VioletContainerDark,
        blue = ElectricBlueBright,
        blueContainer = ElectricBlueContainer,
        success = EmeraldSuccess,
        warning = AmberWarning,
        cardBorder = GraphiteOutline,
        elevatedSurface = GraphiteElevated,
        glassSurface = GlassSurfaceDark,
        glassEdgeTop = GlassTopSpecular,
        glassEdgeBottom = GlassBottomRim,
        academyBg = AcademyBgBlack,
        academyBlackSecondary = AcademyBlackSecondary,
        academyGraphite = AcademyGraphite,
        academyDarkGray = AcademyDarkGray,
        academyMediumGray = AcademyMediumGray,
        academyWhite = AcademyWhite,
        academyElectricBlue = AcademyElectricBlue,
        academyLuminousBlue = AcademyLuminousBlue,
        academyViolet = AcademyViolet,
        academyDeepViolet = AcademyDeepViolet,
        isDark = true
    )
}

private val LumenDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = WarmWhiteText,
    primaryContainer = ElectricBlueContainer,
    onPrimaryContainer = ElectricBlueBright,
    secondary = LuminousViolet,
    onSecondary = WarmWhiteText,
    secondaryContainer = VioletContainerDark,
    onSecondaryContainer = Color(0xFFDDD5FF),
    tertiary = ElectricBlueBright,
    onTertiary = ObsidianVoid,
    tertiaryContainer = ElectricBlueContainer,
    onTertiaryContainer = Color(0xFFD6E0FF),
    background = ObsidianVoid,
    onBackground = WarmWhiteText,
    surface = DeepSpaceBlack,
    onSurface = WarmWhiteText,
    surfaceVariant = GraphiteSurface,
    onSurfaceVariant = MutedCoolSlate,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = DeepSpaceBlack,
    surfaceContainer = GraphiteDark,
    surfaceContainerHigh = GraphiteSurface,
    surfaceContainerHighest = GraphiteElevated,
    outline = GraphiteOutline,
    outlineVariant = Color(0xFF1A2033),
    error = CrimsonError,
    onError = WarmWhiteText
)

private val LumenLightColorScheme = lightColorScheme(
    primary = ElectricBlueLight,
    onPrimary = Color.White,
    primaryContainer = BlueContainerLight,
    onPrimaryContainer = Color(0xFF0A1B66),
    secondary = VioletLight,
    onSecondary = Color.White,
    secondaryContainer = VioletContainerLight,
    onSecondaryContainer = Color(0xFF1E106B),
    tertiary = ElectricBlue,
    onTertiary = Color.White,
    tertiaryContainer = BlueContainerLight,
    onTertiaryContainer = Color(0xFF0A2454),
    background = ParchmentLight,
    onBackground = InkDarkText,
    surface = ParchmentLight,
    onSurface = InkDarkText,
    surfaceVariant = SoftWarmSurfaceLight,
    onSurfaceVariant = SlateSecondaryLight,
    surfaceContainerLowest = IvoryCardLight,
    surfaceContainerLow = Color(0xFFFAFBFD),
    surfaceContainer = IvoryCardLight,
    surfaceContainerHigh = SoftWarmSurfaceLight,
    surfaceContainerHighest = Color(0xFFDCE1F0),
    outline = OutlineLight,
    outlineVariant = Color(0xFFE3E7F2),
    error = Color(0xFFD42C44),
    onError = Color.White
)

val LumenShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun LumenTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LumenDarkColorScheme else LumenLightColorScheme
    val extendedColors = if (darkTheme) {
        LumenExtendedColors(
            gold = ElectricBlue,
            onGold = WarmWhiteText,
            goldContainer = ElectricBlueContainer,
            electricBlue = ElectricBlue,
            electricBlueBright = ElectricBlueBright,
            electricBlueDeep = ElectricBlueDeep,
            violet = LuminousViolet,
            violetContainer = VioletContainerDark,
            blue = ElectricBlueBright,
            blueContainer = ElectricBlueContainer,
            success = EmeraldSuccess,
            warning = AmberWarning,
            cardBorder = GraphiteOutline,
            elevatedSurface = GraphiteElevated,
            glassSurface = GlassSurfaceDark,
            glassEdgeTop = GlassTopSpecular,
            glassEdgeBottom = GlassBottomRim,
            academyBg = AcademyBgBlack,
            academyBlackSecondary = AcademyBlackSecondary,
            academyGraphite = AcademyGraphite,
            academyDarkGray = AcademyDarkGray,
            academyMediumGray = AcademyMediumGray,
            academyWhite = AcademyWhite,
            academyElectricBlue = AcademyElectricBlue,
            academyLuminousBlue = AcademyLuminousBlue,
            academyViolet = AcademyViolet,
            academyDeepViolet = AcademyDeepViolet,
            isDark = true
        )
    } else {
        LumenExtendedColors(
            gold = ElectricBlueLight,
            onGold = Color.White,
            goldContainer = BlueContainerLight,
            electricBlue = ElectricBlueLight,
            electricBlueBright = ElectricBlue,
            electricBlueDeep = Color(0xFF233BB8),
            violet = VioletLight,
            violetContainer = VioletContainerLight,
            blue = ElectricBlueLight,
            blueContainer = BlueContainerLight,
            success = Color(0xFF178B5E),
            warning = Color(0xFFC27912),
            cardBorder = OutlineLight,
            elevatedSurface = SoftWarmSurfaceLight,
            glassSurface = Color(0xD9FFFFFF),
            glassEdgeTop = Color(0xFFFFFFFF),
            glassEdgeBottom = Color(0x339AA5C4),
            academyBg = ParchmentLight,
            academyBlackSecondary = IvoryCardLight,
            academyGraphite = SoftWarmSurfaceLight,
            academyDarkGray = OutlineLight,
            academyMediumGray = SlateSecondaryLight,
            academyWhite = InkDarkText,
            academyElectricBlue = AcademyElectricBlue,
            academyLuminousBlue = AcademyLuminousBlue,
            academyViolet = AcademyViolet,
            academyDeepViolet = VioletContainerLight,
            isDark = false
        )
    }

    CompositionLocalProvider(LocalLumenColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = LumenTypography,
            shapes = LumenShapes,
            content = content
        )
    }
}
