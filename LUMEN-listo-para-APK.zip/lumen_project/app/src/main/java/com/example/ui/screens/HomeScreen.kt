package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.TutorEntity
import com.example.ui.components.Lumen3dOrbitalNode
import com.example.ui.components.Lumen3dPrismCore
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenCounterPill
import com.example.ui.components.LumenElectricButton
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenStreakPill
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.components.NodeVisualState
import com.example.ui.components.TutorAvatarBadge
import com.example.ui.components.hexToColor
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.HomeUiState

@Composable
fun HomeScreen(
    state: HomeUiState,
    onContinueLesson: (LessonEntity) -> Unit,
    onOpenAcademy: () -> Unit,
    onOpenTutor: (TutorEntity) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenLab: () -> Unit,
    onOpenPlanner: () -> Unit,
    onToggleTask: (PlannerTaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current

    if (state.isLoading) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = lumenColors.electricBlue)
        }
        return
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("home_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Panel de mando de Academia Privada con Prisma 3D y portada atmosférica
            item {
                LumenGlassPanel(
                    glowColor = lumenColors.electricBlue,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(148.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_academy),
                            contentDescription = "Observatorio académico LUMEN",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color(0x6604060B),
                                            Color(0xEB070A12)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                LumenMonospaceTag(text = state.formattedDate.ifBlank { "JORNADA DE ESTUDIO" })
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "${state.greeting}, ${state.userName}",
                                    style = MaterialTheme.typography.displaySmall,
                                    color = Color(0xFFF6F5F0),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Lumen3dPrismCore(progressPercent = state.overallProgressPercent)
                        }
                    }

                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "DOMINIO GENERAL DE LA ACADEMIA",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = lumenColors.electricBlueBright
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${state.completedLessonsCount} de ${state.totalLessonsCount} lecciones · ${state.todayMinutes}/${state.dailyGoalMinutes} min hoy",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            LumenCounterPill(
                                label = "GLOBAL",
                                value = "${state.overallProgressPercent}%"
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        val dailyRatio = (state.todayMinutes.toFloat() / state.dailyGoalMinutes.coerceAtLeast(1))
                            .coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { dailyRatio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = lumenColors.electricBlueBright,
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                        )
                    }
                }
            }

            // 2. Racha semanal luminosa (referencia visual #1)
            item {
                LumenStreakPill(
                    streakDays = state.streakDays,
                    weeklyActiveMask = state.weeklyStudyMask,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 3. Placas de telemetría grafito (contraste con paneles de vidrio)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LumenSurfaceCard(
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPlanner
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Schedule,
                                contentDescription = "Tiempo estudiado hoy",
                                tint = lumenColors.electricBlueBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "HOY",
                                style = MaterialTheme.typography.labelSmall,
                                color = lumenColors.electricBlueBright
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${state.todayMinutes} min",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Actividad registrada",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    LumenSurfaceCard(
                        modifier = Modifier.weight(1f),
                        onClick = onOpenLibrary
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Style,
                                contentDescription = "Repasos espaciados",
                                tint = lumenColors.violet,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "MEMORIA",
                                style = MaterialTheme.typography.labelSmall,
                                color = lumenColors.violet
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${state.dueFlashcardsCount} tarjetas",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Repaso pendiente",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 4. Spotlight "LO QUE SIGUE" con nodo 3D luminoso y botón grande azul eléctrico (referencia #2)
            state.continueLesson?.let { lesson ->
                item {
                    LumenSectionHeader(
                        title = "Continuar aprendiendo",
                        subtitle = state.continueCourse?.title ?: "Programa guiado",
                        actionLabel = "Ver academia",
                        onAction = onOpenAcademy
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LumenGlassPanel(
                        glowColor = lumenColors.electricBlue,
                        onClick = { onContinueLesson(lesson) },
                        modifier = Modifier.testTag("home_continue_lesson_card")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Lumen3dOrbitalNode(
                                state = NodeVisualState.ACTIVE,
                                onClick = { onContinueLesson(lesson) },
                                size = 84.dp,
                                floatingQuestionBubble = true
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                LumenMonospaceTag(text = "LO QUE SIGUE")
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = lesson.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Etapa ${lesson.currentStage + 1}/5 · ${lesson.durationMinutes} min · ${lesson.level}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = lumenColors.electricBlueBright
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lesson.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        LumenElectricButton(
                            text = if (lesson.currentStage > 0) "Reanudar lección" else "¡Comenzar ahora!",
                            icon = Icons.Rounded.PlayArrow,
                            onClick = { onContinueLesson(lesson) },
                            modifier = Modifier.testTag("home_continue_lesson_button")
                        )
                    }
                }
            }

            // 5. Recordatorio inteligente en vidrio
            if (state.dueFlashcardsCount > 0 || state.pendingTasks.isNotEmpty()) {
                item {
                    LumenGlassPanel(
                        glowColor = lumenColors.violet,
                        onClick = {
                            if (state.dueFlashcardsCount > 0) onOpenLibrary() else onOpenPlanner()
                        }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.NotificationsActive,
                                contentDescription = "Recordatorio importante",
                                tint = lumenColors.electricBlueBright,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ALERTA DE SESIÓN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = lumenColors.electricBlueBright
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${state.pendingTasks.size} objetivos pendientes y ${state.dueFlashcardsCount} flashcards listas para consolidar hoy.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // 6. Claustro rápido de tutores
            item {
                LumenSectionHeader(
                    title = "Tutores disponibles",
                    subtitle = "Sesión socrática con Gemini"
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(state.quickTutors, key = { it.id }) { tutor ->
                        val accent = hexToColor(tutor.accentHex, lumenColors.electricBlueBright)
                        LumenSurfaceCard(
                            modifier = Modifier
                                .width(178.dp)
                                .testTag("home_quick_tutor_${tutor.id}"),
                            borderColor = accent.copy(alpha = 0.42f),
                            onClick = { onOpenTutor(tutor) }
                        ) {
                            TutorAvatarBadge(initials = tutor.avatarInitials, accentColor = accent)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = tutor.name,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = tutor.specialty.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = accent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // 7. Materias prioritarias
            item {
                LumenSectionHeader(
                    title = "Materias prioritarias",
                    actionLabel = "Academia",
                    onAction = onOpenAcademy
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(state.favoriteSubjects, key = { it.id }) { subject ->
                        val subjectColor = hexToColor(subject.colorHex, lumenColors.electricBlueBright)
                        LumenGlassPanel(
                            modifier = Modifier.width(190.dp),
                            glowColor = subjectColor,
                            onClick = onOpenAcademy
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoStories,
                                    contentDescription = null,
                                    tint = subjectColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = subject.area.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = subjectColor,
                                    maxLines = 1
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = subject.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { subject.masteryLevel / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = subjectColor,
                                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "DOMINIO ${subject.masteryLevel}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 8. Objetivos pendientes
            item {
                LumenSectionHeader(
                    title = "Objetivos pendientes",
                    actionLabel = "Agenda",
                    onAction = onOpenPlanner
                )
                Spacer(modifier = Modifier.height(10.dp))
                if (state.pendingTasks.isEmpty()) {
                    LumenSurfaceCard(onClick = onOpenPlanner) {
                        Text(
                            text = "No tienes objetivos pendientes por ahora. Toca para programar tu próxima meta.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        state.pendingTasks.forEach { task ->
                            LumenSurfaceCard {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    IconButton(onClick = { onToggleTask(task) }) {
                                        Icon(
                                            imageVector = if (task.isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                            contentDescription = "Marcar tarea",
                                            tint = if (task.isCompleted) lumenColors.success else lumenColors.electricBlueBright
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = task.title,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "${task.subjectName} · ${task.dueTimeLabel} · ${task.priority}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 9. Portales rápidos a Laboratorio y Biblioteca
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LumenGlassPanel(
                        modifier = Modifier.weight(1f),
                        glowColor = lumenColors.violet,
                        onClick = onOpenLab
                    ) {
                        Icon(Icons.Rounded.Science, contentDescription = null, tint = lumenColors.violet)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Laboratorio", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Síntesis, mapas y tests con IA",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LumenGlassPanel(
                        modifier = Modifier.weight(1f),
                        glowColor = lumenColors.electricBlue,
                        onClick = onOpenLibrary
                    ) {
                        Icon(Icons.Rounded.MenuBook, contentDescription = null, tint = lumenColors.electricBlueBright)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Biblioteca", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Apuntes, flashcards y tests",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 10. Actividad reciente
            item {
                LumenSectionHeader(title = "Registro reciente")
                Spacer(modifier = Modifier.height(8.dp))
                LumenSurfaceCard {
                    if (state.recentActivity.isEmpty()) {
                        Text(
                            text = "Tu historial de estudio aparecerá aquí conforme avances.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        state.recentActivity.forEachIndexed { index, log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(lumenColors.blueContainer)
                                        .border(1.dp, lumenColors.electricBlue.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Bolt,
                                        contentDescription = null,
                                        tint = lumenColors.electricBlueBright,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(log.title, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "${log.section.uppercase()} · ${log.subtitle}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            if (index < state.recentActivity.lastIndex) {
                                Spacer(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.outlineVariant)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
