package com.example.domain

import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.SubjectEntity
import java.time.LocalDate

enum class RecommendationKind {
    RESUME_LESSON,
    PRACTICE_WEAK_AREA,
    REVIEW_FLASHCARDS,
    PREPARE_EXAM,
    TAKE_QUIZ,
    ASK_TUTOR
}

data class AcademyRecommendation(
    val id: String,
    val kind: RecommendationKind,
    val title: String,
    val subtitle: String,
    val badge: String,
    val targetLessonId: Long? = null,
    val targetSegmentIndex: Int? = null,
    val targetExamId: Long? = null
)

/**
 * Motor local de recomendaciones para el botón central "COMENZAR" y "Siguiente lección"
 * en Exámenes. Analiza lecciones en curso, áreas más débiles, tarjetas vencidas y exámenes próximos.
 */
object RecommendationUseCase {

    fun buildRecommendations(
        subject: SubjectEntity?,
        segments: List<GaugeSegmentModel>,
        lessons: List<LessonEntity>,
        flashcards: List<FlashcardEntity>,
        quizzes: List<QuizEntity>,
        exams: List<ExamEntity>
    ): List<AcademyRecommendation> {
        if (subject == null) return emptyList()
        val list = mutableListOf<AcademyRecommendation>()
        val now = System.currentTimeMillis()
        val todayEpoch = LocalDate.now().toEpochDay()

        // 1. Lección iniciada o primera disponible de esta materia
        val subjectSegmentLessonIds = segments.flatMap { it.lessons }.map { it.id }.toSet()
        val pendingLesson = lessons
            .filter { it.id in subjectSegmentLessonIds || it.title.contains(subject.name, ignoreCase = true) }
            .firstOrNull { !it.isCompleted }
            ?: lessons.firstOrNull { !it.isCompleted }

        if (pendingLesson != null) {
            list.add(
                AcademyRecommendation(
                    id = "lesson_${pendingLesson.id}",
                    kind = RecommendationKind.RESUME_LESSON,
                    title = pendingLesson.title,
                    subtitle = if (pendingLesson.currentStage > 0) {
                        "Continúa en etapa ${pendingLesson.currentStage + 1}/5 · ${pendingLesson.durationMinutes} min"
                    } else {
                        "Lección guiada · ${pendingLesson.durationMinutes} min"
                    },
                    badge = "SIGUIENTE LECCIÓN",
                    targetLessonId = pendingLesson.id
                )
            )
        }

        // 2. Examen más cercano para esta materia o global
        val upcomingExam = exams
            .filter { it.examDateEpochDay >= todayEpoch }
            .sortedBy { it.examDateEpochDay }
            .firstOrNull { it.subjectId == subject.id }
            ?: exams.filter { it.examDateEpochDay >= todayEpoch }.minByOrNull { it.examDateEpochDay }

        if (upcomingExam != null) {
            val daysLeft = (upcomingExam.examDateEpochDay - todayEpoch).coerceAtLeast(0)
            list.add(
                AcademyRecommendation(
                    id = "exam_${upcomingExam.id}",
                    kind = RecommendationKind.PREPARE_EXAM,
                    title = upcomingExam.title,
                    subtitle = "Faltan $daysLeft días · Preparación actual ${upcomingExam.readinessPercent}% (meta ${upcomingExam.targetPercent}%)",
                    badge = "PLAN DE EXAMEN",
                    targetExamId = upcomingExam.id
                )
            )
        }

        // 3. Área temática con menor porcentaje de dominio
        val weakestIdx = segments.indices.minByOrNull { segments[it].readinessPercent }
        if (weakestIdx != null) {
            val weakest = segments[weakestIdx]
            list.add(
                AcademyRecommendation(
                    id = "weak_${weakest.unitId}",
                    kind = RecommendationKind.PRACTICE_WEAK_AREA,
                    title = "Reforzar ${weakest.title}",
                    subtitle = "Área al ${weakest.readinessPercent}% · ${weakest.topics.size} temas por consolidar",
                    badge = "BRECHA DETECTADA",
                    targetSegmentIndex = weakestIdx
                )
            )
        }

        // 4. Tarjetas pendientes de repetición espaciada
        val dueCards = flashcards.filter {
            it.subjectName.equals(subject.name, ignoreCase = true) && it.nextReviewAt <= now
        }
        if (dueCards.isNotEmpty()) {
            list.add(
                AcademyRecommendation(
                    id = "flashcards_${subject.id}",
                    kind = RecommendationKind.REVIEW_FLASHCARDS,
                    title = "Repasar ${dueCards.size} tarjetas de ${subject.name}",
                    subtitle = "Recuperación activa espaciada lista para hoy",
                    badge = "REPASO ACTIVO"
                )
            )
        }

        // 5. Cuestionario de práctica
        val quiz = quizzes.firstOrNull { it.subjectName.equals(subject.name, ignoreCase = true) }
            ?: quizzes.firstOrNull()
        if (quiz != null) {
            list.add(
                AcademyRecommendation(
                    id = "quiz_${quiz.id}",
                    kind = RecommendationKind.TAKE_QUIZ,
                    title = quiz.title,
                    subtitle = "Mejor marca: ${quiz.bestScorePercent}% · ${quiz.attemptsCount} intento(s)",
                    badge = "EVALUACIÓN"
                )
            )
        }

        // 6. Sesión contextual con Tutor Gemini
        list.add(
            AcademyRecommendation(
                id = "tutor_${subject.id}",
                kind = RecommendationKind.ASK_TUTOR,
                title = "Resolver dudas de ${subject.name} con tutor IA",
                subtitle = "Diagnóstico socrático y ejercicios graduados con Gemini",
                badge = "TUTOR GEMINI"
            )
        )

        return list
    }
}
