package com.example.data.local

import com.example.data.local.entity.ActivityLogEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.local.entity.UnitEntity
import java.time.LocalDate

object LumenSeedData {

    suspend fun seedIfEmpty(db: LumenDatabase) {
        val academyDao = db.academyDao()
        if (academyDao.countSubjects() > 0) {
            ensureAcademyCatalogAndExams(db)
            return
        }

        val now = System.currentTimeMillis()
        val todayEpoch = LocalDate.now().toEpochDay()

        // 1. Materias iniciales (diversas áreas del conocimiento)
        val mathId = academyDao.insertSubject(
            SubjectEntity(
                name = "Matemáticas",
                area = "Ciencias Exactas",
                description = "Álgebra lineal, cálculo diferencial, teoría de números y demostración rigurosa.",
                iconKey = "functions",
                colorHex = "#D4AF37",
                masteryLevel = 64,
                isFavorite = true
            )
        )
        val physicsId = academyDao.insertSubject(
            SubjectEntity(
                name = "Física",
                area = "Ciencias Exactas",
                description = "Mecánica clásica, termodinámica, ondas y fundamentos del electromagnetismo.",
                iconKey = "science",
                colorHex = "#4B8DF8",
                masteryLevel = 52,
                isFavorite = true
            )
        )
        val langId = academyDao.insertSubject(
            SubjectEntity(
                name = "Lengua y Literatura",
                area = "Humanidades",
                description = "Sintaxis avanzada, retórica argumentativa y análisis estilístico de obras clásicas.",
                iconKey = "menu_book",
                colorHex = "#8A7BFF",
                masteryLevel = 72,
                isFavorite = true
            )
        )
        val historyId = academyDao.insertSubject(
            SubjectEntity(
                name = "Historia",
                area = "Humanidades",
                description = "Procesos históricos, crítica documental y evolución de las civilizaciones.",
                iconKey = "account_balance",
                colorHex = "#E59B38",
                masteryLevel = 45,
                isFavorite = false
            )
        )
        val bioId = academyDao.insertSubject(
            SubjectEntity(
                name = "Biología",
                area = "Ciencias Naturales",
                description = "Biología celular, metabolismo energético, genética molecular y evolución.",
                iconKey = "biotech",
                colorHex = "#34C78A",
                masteryLevel = 40,
                isFavorite = false
            )
        )
        val philId = academyDao.insertSubject(
            SubjectEntity(
                name = "Filosofía",
                area = "Humanidades",
                description = "Epistemología, lógica proposicional, ética y tradición socrática.",
                iconKey = "psychology",
                colorHex = "#A98CFF",
                masteryLevel = 58,
                isFavorite = false
            )
        )
        academyDao.insertSubject(
            SubjectEntity(
                name = "Geografía",
                area = "Ciencias Sociales",
                description = "Cartografía, geomorfología, climatología y organización territorial.",
                iconKey = "public",
                colorHex = "#4CC3D9",
                masteryLevel = 35,
                isFavorite = false
            )
        )
        academyDao.insertSubject(
            SubjectEntity(
                name = "Idiomas",
                area = "Comunicación",
                description = "Inglés académico, latín clásico y estructuras comparadas de traducción.",
                iconKey = "translate",
                colorHex = "#E089B6",
                masteryLevel = 60,
                isFavorite = false
            )
        )
        academyDao.insertSubject(
            SubjectEntity(
                name = "Astronomía",
                area = "Ciencias Naturales",
                description = "Mecánica celeste, evolución estelar y métodos de observación del cosmos.",
                iconKey = "auto_awesome",
                colorHex = "#6EA8FE",
                masteryLevel = 30,
                isFavorite = false
            )
        )

        // 2. Cursos, Unidades, Temas y Lecciones interactivas
        val calcCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = mathId,
                title = "Fundamentos del Cálculo Diferencial",
                description = "Comprende límites, continuidad, derivadas y optimización desde la intuición geométrica hasta la demostración formal.",
                level = "Intermedio",
                coverKey = "math",
                estimatedHours = 12
            )
        )
        val calcUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = calcCourseId,
                title = "Unidad I · Límites e Infinitesimales",
                summary = "Aproximación local, comportamiento asintótico y definición épsilon-delta.",
                orderIndex = 1
            )
        )
        val calcUnit2 = academyDao.insertUnit(
            UnitEntity(
                courseId = calcCourseId,
                title = "Unidad II · La Derivada y Razón de Cambio",
                summary = "Rectas tangentes, reglas de derivación y problemas de optimización.",
                orderIndex = 2
            )
        )
        academyDao.insertTopic(TopicEntity(unitId = calcUnit1, title = "Noción intuitiva de límite", learningObjective = "Interpretar tendencias laterales en gráficas.", masteryPercent = 100, isCompleted = true, orderIndex = 1))
        academyDao.insertTopic(TopicEntity(unitId = calcUnit1, title = "Continuidad en un punto", learningObjective = "Verificar las tres condiciones de continuidad.", masteryPercent = 60, isCompleted = false, orderIndex = 2))
        academyDao.insertTopic(TopicEntity(unitId = calcUnit2, title = "Cociente incremental", learningObjective = "Relacionar secantes con la recta tangente.", masteryPercent = 25, isCompleted = false, orderIndex = 1))

        academyDao.insertLesson(
            LessonEntity(
                courseId = calcCourseId,
                unitId = calcUnit1,
                title = "De la secante a la tangente: el límite",
                subtitle = "Cómo capturar el cambio instantáneo mediante aproximaciones sucesivas",
                level = "Intermedio",
                durationMinutes = 18,
                explanation = "El cálculo diferencial nace de una pregunta aparentemente paradójica: ¿cómo medir la velocidad en un instante preciso si en un instante el tiempo transcurrido es cero?\n\nPara resolverlo, observamos la razón de cambio promedio entre dos puntos cercanos x y x + h. Conforme h se acerca a cero sin llegar a ser exactamente cero, las rectas secantes giran suavemente hasta coincidir con la recta tangente.\n\nEl límite no pregunta cuánto vale la función exactamente en el punto, sino hacia qué valor se orienta su vecindad inmediata.",
                definitionsRaw = "Límite lateral::Valor al que se aproxima f(x) cuando x tiende a 'a' únicamente por la izquierda o por la derecha.|||Indeterminación 0/0::Expresión algebraica que requiere simplificación o factorización para revelar el comportamiento real del límite.|||Continuidad::Propiedad de una función sin saltos ni huecos donde lim(x→a) f(x) = f(a).",
                examplesRaw = "Ejemplo 1 — Factorización:\nEvaluar lim(x→2) (x² - 4)/(x - 2).\nSi sustituimos x = 2 aparece 0/0. Factorizando el numerador como (x - 2)(x + 2) y cancelando (x - 2) para x ≠ 2, obtenemos lim(x→2) (x + 2) = 4.|||Ejemplo 2 — Velocidad instantánea:\nSi s(t) = 5t², la velocidad media en [1, 1+h] es [5(1+h)² - 5]/h = 10 + 5h. Al tender h → 0, la velocidad instantánea en t = 1 es 10 m/s.",
                diagramType = "TANGENT",
                comprehensionQuestion = "¿Por qué puede existir lim(x→a) f(x) aunque f(a) no esté definida?",
                comprehensionOptionsRaw = "Porque el límite solo analiza valores cercanos a 'a', sin exigir evaluar en 'a'|||Porque toda función racional es continua en todo su dominio|||Porque el denominador se ignora en cualquier ecuación",
                comprehensionAnswerIndex = 0,
                practicalActivity = "Toma f(x) = (x² - 9)/(x - 3). Calcula mentalmente o en papel los valores de f(2.9), f(2.99) y f(3.01). Observa hacia qué número entero converge la secuencia y anótalo en tu cuaderno de Biblioteca.",
                evaluationQuestion = "Calcula el valor exacto de lim(x→3) (x² - 9)/(x - 3):",
                evaluationOptionsRaw = "3|||6|||9|||No existe",
                evaluationAnswerIndex = 1,
                currentStage = 2,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )
        academyDao.insertLesson(
            LessonEntity(
                courseId = calcCourseId,
                unitId = calcUnit2,
                title = "Regla de la cadena e interpretación geométrica",
                subtitle = "Composición de tasas de cambio en sistemas encadenados",
                level = "Intermedio",
                durationMinutes = 22,
                explanation = "Cuando una magnitud depende de una variable intermedia y esta a su vez depende de otra independiente, las tasas de cambio se multiplican.\n\nSi y = f(u) y u = g(x), entonces dy/dx = (dy/du)·(du/dx). Piensa en dos engranajes conectados: si el primero gira al doble que el segundo y el segundo al triple que el tercero, el primero gira seis veces más rápido que el tercero.",
                definitionsRaw = "Función compuesta::Aplicación sucesiva de dos funciones f(g(x)) donde la salida de g alimenta a f.|||Tasa acoplada::Producto de derivadas que describe cómo una variación mínima se propaga a través de capas.",
                examplesRaw = "Ejemplo — Derivar h(x) = (3x + 1)⁴:\nSea u = 3x + 1. Entonces h'(x) = 4u³ · u' = 4(3x + 1)³ · 3 = 12(3x + 1)³.",
                diagramType = "WAVE",
                comprehensionQuestion = "En la regla de la cadena para f(g(x)), ¿qué factor multiplica a f'(g(x))?",
                comprehensionOptionsRaw = "g(x)|||g'(x)|||f(x)",
                comprehensionAnswerIndex = 1,
                practicalActivity = "Formula una función compuesta sencilla de la física (por ejemplo, el área de un círculo cuyo radio crece con el tiempo r(t) = 2t) y determina dA/dt.",
                evaluationQuestion = "¿Cuál es la derivada de f(x) = (2x + 5)³?",
                evaluationOptionsRaw = "3(2x + 5)²|||6(2x + 5)²|||2(2x + 5)³|||6(2x + 5)",
                evaluationAnswerIndex = 1,
                currentStage = 0,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )

        // Curso de Física
        val physCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = physicsId,
                title = "Mecánica Ondulatoria y Oscilaciones",
                description = "Del movimiento armónico simple a la interferencia de ondas y el espectro acústico.",
                level = "Intermedio",
                coverKey = "science",
                estimatedHours = 10
            )
        )
        val physUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = physCourseId,
                title = "Unidad I · Movimiento Armónico Simple",
                summary = "Fuerza restauradora, frecuencia angular y conservación de energía mecánica.",
                orderIndex = 1
            )
        )
        academyDao.insertTopic(TopicEntity(unitId = physUnit1, title = "Ley de Hooke y frecuencia natural", learningObjective = "Relacionar rigidez k y masa m con el periodo T.", masteryPercent = 80, isCompleted = true, orderIndex = 1))
        academyDao.insertLesson(
            LessonEntity(
                courseId = physCourseId,
                unitId = physUnit1,
                title = "Osciladores armónicos y energía",
                subtitle = "El intercambio rítmico entre energía cinética y potencial elástica",
                level = "Intermedio",
                durationMinutes = 16,
                explanation = "Todo sistema estable perturbado levemente respecto a su equilibrio experimenta una fuerza restauradora proporcional al desplazamiento: F = -kx.\n\nMientras la masa cruza el punto de equilibrio, su energía potencial es nula y su velocidad es máxima. En los extremos, se detiene un instante para almacenar toda la energía en forma potencial elástica: E = ½kA².",
                definitionsRaw = "Amplitud (A)::Desplazamiento máximo desde la posición de equilibrio.|||Periodo (T)::Tiempo necesario para completar un ciclo completo de oscilación, T = 2π√(m/k).",
                examplesRaw = "Un péndulo de reloj o una masa de 0.5 kg unida a un resorte de k = 50 N/m tiene frecuencia angular ω = √(50/0.5) = 10 rad/s.",
                diagramType = "WAVE",
                comprehensionQuestion = "Si cuadruplicamos la masa m manteniendo constante k, ¿qué ocurre con el periodo T?",
                comprehensionOptionsRaw = "Se duplica|||Se reduce a la mitad|||Permanece igual",
                comprehensionAnswerIndex = 0,
                practicalActivity = "Observa cómo la energía total E = K + U permanece constante dibujando dos curvas complementarias en tu libreta.",
                evaluationQuestion = "En el punto de equilibrio (x = 0) de un oscilador armónico sin fricción:",
                evaluationOptionsRaw = "La aceleración es máxima|||La energía cinética es máxima|||La velocidad es cero|||La fuerza restauradora es máxima",
                evaluationAnswerIndex = 1,
                currentStage = 4,
                isCompleted = true,
                isUnlocked = true,
                scorePercent = 100
            )
        )

        // Curso de Humanidades / Lengua & Filosofía
        val langCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = langId,
                title = "Retórica, Argumentación y Comentario Crítico",
                description = "Estructura del discurso persuasivo, figuras de pensamiento y análisis de textos literarios.",
                level = "Avanzado",
                coverKey = "humanities",
                estimatedHours = 9
            )
        )
        val langUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = langCourseId,
                title = "Unidad I · Arquitectura del Argumento",
                summary = "Tesis, premisas, evidencias y refutación elegante.",
                orderIndex = 1
            )
        )
        academyDao.insertTopic(TopicEntity(unitId = langUnit1, title = "Ethos, Pathos y Logos", learningObjective = "Equilibrar credibilidad, emoción y rigor lógico.", masteryPercent = 90, isCompleted = true, orderIndex = 1))
        academyDao.insertLesson(
            LessonEntity(
                courseId = langCourseId,
                unitId = langUnit1,
                title = "Los tres pilares de la persuasión clásica",
                subtitle = "Análisis retórico desde Aristóteles hasta el ensayo contemporáneo",
                level = "Avanzado",
                durationMinutes = 15,
                explanation = "Persuadir no equivale a manipular. En la retórica clásica, un discurso sólido se sostiene sobre tres pilares complementarios:\n\n• Ethos: la autoridad moral, serenidad y competencia del emisor.\n• Logos: la coherencia interna, los datos verificables y los nexos causales.\n• Pathos: la resonancia emocional que conecta una idea abstracta con la experiencia humana.",
                definitionsRaw = "Entimema::Silogismo retórico donde una premisa se sobreentiende porque el lector la comparte.|||Concesión::Estrategia en la que se reconoce un punto válido del adversario para fortalecer la propia tesis.",
                examplesRaw = "En un ensayo histórico, citar fuentes primarias construye Logos y Ethos simultáneamente; narrar el testimonio de un testigo introduce Pathos sin perder rigor.",
                diagramType = "CELL",
                comprehensionQuestion = "¿Cuál de los tres pilares corresponde a la estructura lógica y evidencia del argumento?",
                comprehensionOptionsRaw = "Ethos|||Pathos|||Logos",
                comprehensionAnswerIndex = 2,
                practicalActivity = "Redacta un párrafo de cinco líneas defendiendo la importancia de leer fuentes originales aplicando al menos una concesión retórica.",
                evaluationQuestion = "¿Qué función cumple una concesión argumentativa bien ejecutada?",
                evaluationOptionsRaw = "Debilita irremediablemente la tesis central|||Demuestra honestidad intelectual y anticipa objeciones|||Sustituye la necesidad de evidencias",
                evaluationAnswerIndex = 1,
                currentStage = 1,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )

        // Curso de Historia y Filosofía
        val philCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = philId,
                title = "Lógica y Teoría del Conocimiento",
                description = "Validez deductiva, falacias informales y criterios de verdad científica.",
                level = "Inicial",
                coverKey = "humanities",
                estimatedHours = 8
            )
        )
        val philUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = philCourseId,
                title = "Unidad I · Verdad y Validez",
                summary = "Distinción entre forma lógica válida y veracidad empírica de las premisas.",
                orderIndex = 1
            )
        )
        academyDao.insertLesson(
            LessonEntity(
                courseId = philCourseId,
                unitId = philUnit1,
                title = "El método socrático y la detección de falacias",
                subtitle = "Cómo examinar supuestos ocultos mediante preguntas precisas",
                level = "Inicial",
                durationMinutes = 14,
                explanation = "La mayéutica socrática parte de una convicción humilde: antes de afirmar que sabemos algo, conviene someter nuestras definiciones a prueba de contradicción.\n\nUn argumento es válido cuando es imposible que sus premisas sean verdaderas y su conclusión falsa, independientemente del contenido emocional de la afirmación.",
                definitionsRaw = "Modus Ponens::Si P implica Q, y P es verdadero, entonces Q es necesariamente verdadero.|||Falacia Ad Hominem::Atacar a la persona que emite el argumento en lugar de examinar sus razones.",
                examplesRaw = "Decir 'Tu cálculo está mal porque llegaste tarde' es una falacia ad hominem: la puntualidad no altera la aritmética.",
                diagramType = "TANGENT",
                comprehensionQuestion = "¿Puede un argumento ser lógicamente válido pero tener una conclusión falsa?",
                comprehensionOptionsRaw = "Sí, si al menos una de sus premisas es falsa|||No, validez y verdad son exactamente lo mismo|||Solo en matemáticas puras",
                comprehensionAnswerIndex = 0,
                practicalActivity = "Identifica dos afirmaciones cotidianas de las noticias y traduce su estructura a 'Si P entonces Q'.",
                evaluationQuestion = "¿Qué caracteriza al razonamiento deductivo válido?",
                evaluationOptionsRaw = "La conclusión es probable pero incierta|||La verdad de las premisas garantiza la verdad de la conclusión|||Se basa únicamente en la autoridad del autor",
                evaluationAnswerIndex = 1,
                currentStage = 0,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )

        // Curso de Biología
        val bioCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = bioId,
                title = "Arquitectura Celular y Genética",
                description = "Organelos eucariotas, transcripción del ADN y regulación metabólica.",
                level = "Inicial",
                coverKey = "science",
                estimatedHours = 10
            )
        )
        val bioUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = bioCourseId,
                title = "Unidad I · La Célula como Sistema",
                summary = "Membranas selectivas, mitocondrias y flujo de información genética.",
                orderIndex = 1
            )
        )
        academyDao.insertLesson(
            LessonEntity(
                courseId = bioCourseId,
                unitId = bioUnit1,
                title = "Del ADN a la proteína: el dogma central",
                subtitle = "Cómo las células leen instrucciones moleculares con precisión",
                level = "Inicial",
                durationMinutes = 17,
                explanation = "La información hereditaria reside en el ADN dentro del núcleo, pero las proteínas se ensamblan en los ribosomas del citoplasma.\n\nEl ARN mensajero actúa como un transcripto fiel que copia un gen específico y lo lleva hacia los ribosomas, donde cada triplete de bases (codón) especifica un aminoácido.",
                definitionsRaw = "Transcripción::Síntesis de ARN mensajero a partir de un molde de ADN catalizada por la ARN polimerasa.|||Codón::Secuencia de tres nucleótidos en el ARNm que codifica un aminoácido o señal de parada.",
                examplesRaw = "El codón AUG inicia la traducción e introduce metionina en organismos eucariotas.",
                diagramType = "CELL",
                comprehensionQuestion = "¿Qué molécula transporta la copia de la secuencia genética desde el núcleo hasta el ribosoma?",
                comprehensionOptionsRaw = "ARN mensajero (ARNm)|||ADN polimerasa|||ATP sintasa",
                comprehensionAnswerIndex = 0,
                practicalActivity = "Transcribe la cadena molde de ADN 3'-TAC GGA-5' a su secuencia complementaria de ARNm 5'-AUG CCU-3'.",
                evaluationQuestion = "¿En qué orgánulo o estructura celular ocurre la traducción del ARNm a proteína?",
                evaluationOptionsRaw = "Aparato de Golgi|||Ribosoma|||Lisosoma|||Peroxisoma",
                evaluationAnswerIndex = 1,
                currentStage = 0,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )

        // Curso de Historia
        val histCourseId = academyDao.insertCourse(
            CourseEntity(
                subjectId = historyId,
                title = "Método Histórico y Mundo Moderno",
                description = "Del Renacimiento y la imprenta a las revoluciones científicas y políticas.",
                level = "Intermedio",
                coverKey = "humanities",
                estimatedHours = 11
            )
        )
        val histUnit1 = academyDao.insertUnit(
            UnitEntity(
                courseId = histCourseId,
                title = "Unidad I · Crítica de Fuentes y Humanismo",
                summary = "Cómo distinguir hechos documentados, sesgos y contexto de época.",
                orderIndex = 1
            )
        )
        academyDao.insertLesson(
            LessonEntity(
                courseId = histCourseId,
                unitId = histUnit1,
                title = "La imprenta y la revolución del conocimiento",
                subtitle = "Impacto de la reproducción textual en la ciencia y la cultura europea",
                level = "Intermedio",
                durationMinutes = 16,
                explanation = "Antes de 1450, copiar un tratado requería meses de trabajo manuscrito y cada copia introducía errores acumulativos. La imprenta de tipos móviles de Gutenberg estandarizó tablas astronómicas, mapas y traducciones.\n\nAl abaratar el libro y multiplicar el acceso a textos comparados, los investigadores pudieron verificar observaciones a distancia y corregir errores antiguos.",
                definitionsRaw = "Fuente primaria::Documento, objeto o testimonio producido directamente en el periodo histórico estudiado.|||Anacronismo::Error metodológico consistente en juzgar o situar hechos de una época con categorías de otra distinta.",
                examplesRaw = "Una carta de Galileo de 1610 es fuente primaria; un libro publicado en 2020 sobre Galileo es fuente secundaria.",
                diagramType = "TIMELINE",
                comprehensionQuestion = "¿Por qué fue decisiva la estandarización de diagramas y tablas impresas para la ciencia?",
                comprehensionOptionsRaw = "Permitió comparar y verificar exactamente los mismos datos en distintos países|||Eliminó el uso del latín en un solo año|||Sustituyó la observación astronómica",
                comprehensionAnswerIndex = 0,
                practicalActivity = "Clasifica tres documentos sobre un mismo evento en fuentes primarias y secundarias anotando la posible intención de su autor.",
                evaluationQuestion = "¿Cuál de los siguientes ejemplos constituye una fuente primaria?",
                evaluationOptionsRaw = "Un documental actual sobre Roma|||Una inscripción epigráfica romana del siglo I|||Un manual escolar contemporáneo",
                evaluationAnswerIndex = 1,
                currentStage = 0,
                isCompleted = false,
                isUnlocked = true,
                scorePercent = 0
            )
        )

        // 3. Los 8 Tutores Inteligentes iniciales
        val tutorDao = db.tutorDao()
        val tutorMathId = tutorDao.insertTutor(
            TutorEntity(
                name = "Sofía Vance",
                specialty = "Matemáticas",
                avatarInitials = "SV",
                accentHex = "#D4AF37",
                academicPersonality = "Rigurosa, paciente y amante de la claridad geométrica. Nunca da un resultado final sin construir antes la intuición.",
                pedagogicalInstructions = "Identifica qué sabe el estudiante, guía paso a paso con preguntas breves, propón ejercicios graduales, detecta errores conceptuales reales y explica el porqué de cada error.",
                subjectArea = "Matemáticas"
            )
        )
        val tutorLangId = tutorDao.insertTutor(
            TutorEntity(
                name = "Mateo Cervantes",
                specialty = "Lengua y Literatura",
                avatarInitials = "MC",
                accentHex = "#8A7BFF",
                academicPersonality = "Erudito, expresivo y atento al matiz estilístico. Valora la precisión léxica y la lectura atenta.",
                pedagogicalInstructions = "Evalúa la intención comunicativa, analiza sintaxis y recursos literarios sobre fragmentos concretos, propone reescrituras guiadas y explica cada corrección.",
                subjectArea = "Lengua y Literatura"
            )
        )
        tutorDao.insertTutor(
            TutorEntity(
                name = "Elena Humboldt",
                specialty = "Geografía",
                avatarInitials = "EH",
                accentHex = "#4CC3D9",
                academicPersonality = "Exploradora analítica que conecta el relieve, el clima y los asentamientos humanos.",
                pedagogicalInstructions = "Ubica espacialmente los fenómenos, relaciona factores físicos y humanos, plantea lectura de mapas y comprueba la comprensión causal.",
                subjectArea = "Geografía"
            )
        )
        tutorDao.insertTutor(
            TutorEntity(
                name = "Marco Aurelio",
                specialty = "Historia",
                avatarInitials = "MA",
                accentHex = "#E59B38",
                academicPersonality = "Sereno y crítico con las fuentes. Enseña a pensar en procesos de larga duración.",
                pedagogicalInstructions = "Sitúa cronológicamente, distingue causas estructurales de detonantes, contrasta fuentes primarias y evita memorización mecánica.",
                subjectArea = "Historia"
            )
        )
        tutorDao.insertTutor(
            TutorEntity(
                name = "Clara Mendel",
                specialty = "Ciencias Naturales",
                avatarInitials = "CM",
                accentHex = "#34C78A",
                academicPersonality = "Metódica y experimental. Conecta la escala molecular con la vida cotidiana.",
                pedagogicalInstructions = "Formula hipótesis junto al estudiante, explica procesos biológicos y químicos con analogías precisas y valida el método científico.",
                subjectArea = "Biología"
            )
        )
        val tutorPhysId = tutorDao.insertTutor(
            TutorEntity(
                name = "Nicolás Maxwell",
                specialty = "Física",
                avatarInitials = "NM",
                accentHex = "#4B8DF8",
                academicPersonality = "Inquisitivo y amante de los experimentos mentales. Exige coherencia dimensional.",
                pedagogicalInstructions = "Pide identificar magnitudes y unidades antes de sustituir números, analiza leyes fundamentales y guía la resolución sin revelar la solución directa.",
                subjectArea = "Física"
            )
        )
        tutorDao.insertTutor(
            TutorEntity(
                name = "Hipatia de Alejandría",
                specialty = "Filosofía",
                avatarInitials = "HA",
                accentHex = "#A98CFF",
                academicPersonality = "Dialéctica, socrática y luminosa. Desarma falacias con cortesía intelectual.",
                pedagogicalInstructions = "Cuestiona presupuestos, ayuda a estructurar premisas y conclusiones, señala contradicciones con rigor y fomenta criterio propio.",
                subjectArea = "Filosofía"
            )
        )
        tutorDao.insertTutor(
            TutorEntity(
                name = "Adrián Polyglot",
                specialty = "Idiomas",
                avatarInitials = "AP",
                accentHex = "#E089B6",
                academicPersonality = "Dinámico y culturalmente atento. Corrige con tacto y ofrece matices idiomáticos reales.",
                pedagogicalInstructions = "Combina práctica conversacional graduada, contraste gramatical con el español, corrección explícita de errores y vocabulario en contexto.",
                subjectArea = "Idiomas"
            )
        )

        // Conversación inicial de ejemplo
        val conv1Id = tutorDao.insertConversation(
            ConversationEntity(
                tutorId = tutorMathId,
                title = "Intuición de límites y continuidad",
                studentLevel = "Intermedio",
                lastMessagePreview = "Observa qué sucede con (x² - 4)/(x - 2) cuando x se acerca a 2...",
                updatedAt = now - 3600_000L,
                createdAt = now - 7200_000L
            )
        )
        tutorDao.insertMessage(
            MessageEntity(
                conversationId = conv1Id,
                role = "user",
                content = "Sofía, entiendo que en x=2 no podemos dividir entre cero, pero ¿por qué el límite sí vale 4?",
                timestamp = now - 7000_000L
            )
        )
        tutorDao.insertMessage(
            MessageEntity(
                conversationId = conv1Id,
                role = "tutor",
                content = "Excelente pregunta. El secreto está en distinguir dos cosas distintas: el valor exacto en x = 2 (que no existe) y el comportamiento en los puntos vecinos muy cercanos a 2.\n\nAntes de decírtelo completo, prueba esto: si x = 1.99, ¿cuánto da (x² - 4)/(x - 2)? ¿Qué pasa si factorizas x² - 4 antes de simplificar?",
                isPlaceholderNotice = true,
                timestamp = now - 6900_000L
            )
        )

        val conv2Id = tutorDao.insertConversation(
            ConversationEntity(
                tutorId = tutorPhysId,
                title = "Energía en osciladores armónicos",
                studentLevel = "Intermedio",
                lastMessagePreview = "¿En qué punto del recorrido se igualan la energía cinética y la potencial?",
                updatedAt = now - 86400_000L,
                createdAt = now - 90000_000L
            )
        )
        tutorDao.insertMessage(
            MessageEntity(
                conversationId = conv2Id,
                role = "user",
                content = "¿Dónde tiene la mitad de energía cinética y la mitad potencial un resorte?",
                timestamp = now - 89000_000L
            )
        )
        tutorDao.insertMessage(
            MessageEntity(
                conversationId = conv2Id,
                role = "tutor",
                content = "Planteemos primero la conservación de energía: E_total = ½kA². Si queremos que la energía potencial ½kx² sea la mitad de ½kA², ¿qué relación queda entre x y A?",
                isPlaceholderNotice = true,
                timestamp = now - 88500_000L
            )
        )

        // 4. Biblioteca personal: Apuntes, Flashcards y Cuestionarios
        val libDao = db.libraryDao()
        libDao.insertNote(
            NoteEntity(
                title = "Teorema Fundamental del Cálculo — Síntesis",
                content = "Conecta dos operaciones aparentemente opuestas: derivación e integración.\n\n1. Primera parte: la derivada de la función área A(x) = ∫[a,x] f(t)dt es exactamente f(x).\n2. Segunda parte (Regla de Barrow): ∫[a,b] f(x)dx = F(b) - F(a), donde F' = f.\n\nIdea clave: sumar acumulaciones infinitesimales equivale a evaluar los extremos de la antiderivada.",
                folder = "Cálculo y Análisis",
                tagsCsv = "cálculo,teoremas,derivadas",
                category = "Resumen",
                referenceSource = "Spivak, Calculus · Cap. 14",
                subjectName = "Matemáticas",
                isFavorite = true,
                createdAt = now - 172800_000L,
                updatedAt = now - 3600_000L
            )
        )
        libDao.insertNote(
            NoteEntity(
                title = "Definición de Entropía (Termodinámica)",
                content = "Magnitud física que mide el número de microestados compatibles con un macroestado dado (S = k_B ln Ω) y determina el sentido espontáneo de los procesos irreversibles en sistemas aislados.",
                folder = "Física Clásica",
                tagsCsv = "termodinámica,entropía,leyes",
                category = "Definición",
                referenceSource = "Feynman Lectures, Vol. I",
                subjectName = "Física",
                isFavorite = true,
                createdAt = now - 250000_000L,
                updatedAt = now - 86400_000L
            )
        )
        libDao.insertNote(
            NoteEntity(
                title = "Estructura del Comentario Filosófico",
                content = "Guía personal en 4 pasos:\n1. Contextualización breve del autor y problema.\n2. Identificación precisa de la tesis central y términos clave.\n3. Reconstrucción de premisas y argumentos secundarios.\n4. Valoración crítica fundamentada sin anacronismos.",
                folder = "Metodología",
                tagsCsv = "ensayo,argumentación,método",
                category = "Apunte",
                referenceSource = "Notas de estudio LUMEN",
                subjectName = "Filosofía",
                isFavorite = false,
                createdAt = now - 400000_000L,
                updatedAt = now - 172800_000L
            )
        )

        libDao.insertFlashcard(
            FlashcardEntity(
                subjectName = "Matemáticas",
                front = "¿Qué tres condiciones garantizan la continuidad de f(x) en x = a?",
                back = "1) f(a) existe.\n2) Existe lim(x→a) f(x).\n3) lim(x→a) f(x) = f(a).",
                masteryLevel = 3,
                intervalDays = 4,
                repetitions = 2,
                nextReviewAt = now - 1000L // Lista para repasar hoy
            )
        )
        libDao.insertFlashcard(
            FlashcardEntity(
                subjectName = "Física",
                front = "¿Cuál es la fórmula del periodo de un oscilador masa-resorte ideal?",
                back = "T = 2π · √(m / k), independiente de la amplitud.",
                masteryLevel = 2,
                intervalDays = 2,
                repetitions = 1,
                nextReviewAt = now - 1000L
            )
        )
        libDao.insertFlashcard(
            FlashcardEntity(
                subjectName = "Biología",
                front = "¿Qué enzima sintetiza ARN mensajero leyendo el molde de ADN?",
                back = "La ARN polimerasa durante la etapa de transcripción.",
                masteryLevel = 1,
                intervalDays = 1,
                repetitions = 1,
                nextReviewAt = now - 1000L
            )
        )
        libDao.insertFlashcard(
            FlashcardEntity(
                subjectName = "Historia",
                front = "¿Qué diferencia una fuente primaria de una secundaria?",
                back = "La primaria fue creada en el periodo investigado; la secundaria analiza e interpreta fuentes previas con posterioridad.",
                masteryLevel = 4,
                intervalDays = 7,
                repetitions = 3,
                nextReviewAt = now + 86400_000L * 2
            )
        )

        val quiz1Id = libDao.insertQuiz(
            QuizEntity(
                title = "Diagnóstico de Cálculo y Física",
                subjectName = "Matemáticas",
                description = "Preguntas mixtas de opción múltiple, verdadero/falso y respuesta abierta.",
                bestScorePercent = 85,
                attemptsCount = 1
            )
        )
        libDao.insertQuizQuestion(
            QuizQuestionEntity(
                quizId = quiz1Id,
                questionType = "MULTIPLE",
                prompt = "¿Cuál es la derivada de f(x) = 3x² - 5x + 7?",
                optionsRaw = "6x - 5|||3x - 5|||6x² - 5|||6x + 7",
                correctAnswer = "6x - 5",
                explanation = "Aplicando la regla de la potencia término a término: d/dx(3x²)=6x, d/dx(-5x)=-5 y d/dx(7)=0."
            )
        )
        libDao.insertQuizQuestion(
            QuizQuestionEntity(
                quizId = quiz1Id,
                questionType = "TRUE_FALSE",
                prompt = "En un movimiento armónico simple sin fricción, la frecuencia depende directamente de la amplitud.",
                optionsRaw = "Verdadero|||Falso",
                correctAnswer = "Falso",
                explanation = "El oscilador armónico es isócrono: su periodo y frecuencia dependen solo de la masa y la constante elástica."
            )
        )
        libDao.insertQuizQuestion(
            QuizQuestionEntity(
                quizId = quiz1Id,
                questionType = "OPEN",
                prompt = "Explica brevemente qué representa geométricamente la derivada en un punto x₀.",
                optionsRaw = "",
                correctAnswer = "pendiente de la recta tangente",
                explanation = "Representa la pendiente de la recta tangente a la curva en (x₀, f(x₀)), es decir, la razón de cambio instantánea."
            )
        )

        // 5. Planificador: Tareas, Sesiones, Hábitos y Actividad Reciente
        val plannerDao = db.plannerDao()
        plannerDao.insertTask(
            PlannerTaskEntity(
                title = "Completar lección de límites laterales",
                description = "Resolver los ejemplos de factorización y la evaluación final.",
                dueDateEpochDay = todayEpoch,
                dueTimeLabel = "17:30",
                priority = "ALTA",
                category = "Estudio",
                subjectName = "Matemáticas",
                isCompleted = false
            )
        )
        plannerDao.insertTask(
            PlannerTaskEntity(
                title = "Repasar 3 tarjetas espaciadas pendientes",
                description = "Sesión breve de recuperación activa en Biblioteca.",
                dueDateEpochDay = todayEpoch,
                dueTimeLabel = "19:00",
                priority = "MEDIA",
                category = "Repaso",
                subjectName = "Física",
                isCompleted = false
            )
        )
        plannerDao.insertTask(
            PlannerTaskEntity(
                title = "Esquema comparativo: Fuentes del siglo XVII",
                description = "Organizar argumentos para el ensayo de Historia Moderna.",
                dueDateEpochDay = todayEpoch + 1,
                dueTimeLabel = "11:00",
                priority = "MEDIA",
                category = "Proyecto",
                subjectName = "Historia",
                isCompleted = false
            )
        )
        plannerDao.insertTask(
            PlannerTaskEntity(
                title = "Leer capítulo sobre ethos y logos",
                description = "Subrayar ejemplos retóricos y extraer definiciones clave.",
                dueDateEpochDay = todayEpoch - 1,
                dueTimeLabel = "16:00",
                priority = "BAJA",
                category = "Objetivo",
                subjectName = "Lengua y Literatura",
                isCompleted = true
            )
        )

        plannerDao.insertStudySession(
            StudySessionEntity(
                subjectName = "Matemáticas",
                durationMinutes = 45,
                focusNotes = "Ejercicios de factorización en indeterminaciones 0/0",
                dateEpochDay = todayEpoch,
                timestamp = now - 5400_000L
            )
        )
        plannerDao.insertStudySession(
            StudySessionEntity(
                subjectName = "Física",
                durationMinutes = 35,
                focusNotes = "Conservación de energía en movimiento armónico simple",
                dateEpochDay = todayEpoch - 1,
                timestamp = now - 86400_000L
            )
        )
        plannerDao.insertStudySession(
            StudySessionEntity(
                subjectName = "Lengua y Literatura",
                durationMinutes = 30,
                focusNotes = "Análisis retórico de un ensayo clásico",
                dateEpochDay = todayEpoch - 2,
                timestamp = now - 172800_000L
            )
        )

        plannerDao.insertHabit(
            HabitEntity(
                title = "Lectura profunda diaria (25 min)",
                targetPerWeek = 6,
                currentStreak = 4,
                lastCompletedEpochDay = todayEpoch - 1,
                completedDaysMask = 0b01111
            )
        )
        plannerDao.insertHabit(
            HabitEntity(
                title = "Repaso activo con Flashcards",
                targetPerWeek = 5,
                currentStreak = 3,
                lastCompletedEpochDay = todayEpoch - 1,
                completedDaysMask = 0b00111
            )
        )
        plannerDao.insertHabit(
            HabitEntity(
                title = "Síntesis escrita en Biblioteca",
                targetPerWeek = 4,
                currentStreak = 2,
                lastCompletedEpochDay = todayEpoch - 1,
                completedDaysMask = 0b00011
            )
        )

        plannerDao.insertActivityLog(
            ActivityLogEntity(
                title = "Lección completada: Osciladores armónicos",
                subtitle = "Física · Evaluación superada (100%)",
                section = "Lecciones",
                timestamp = now - 3600_000L
            )
        )
        plannerDao.insertActivityLog(
            ActivityLogEntity(
                title = "Tutoría con Sofía Vance",
                subtitle = "Matemáticas · Intuición de límites y continuidad",
                section = "Tutores",
                timestamp = now - 7200_000L
            )
        )
        plannerDao.insertActivityLog(
            ActivityLogEntity(
                title = "Apunte guardado en Biblioteca",
                subtitle = "Teorema Fundamental del Cálculo — Síntesis",
                section = "Biblioteca",
                timestamp = now - 18000_000L
            )
        )

        ensureAcademyCatalogAndExams(db)
    }

    suspend fun ensureAcademyCatalogAndExams(db: LumenDatabase) {
        val academyDao = db.academyDao()
        val libDao = db.libraryDao()
        val todayEpoch = LocalDate.now().toEpochDay()

        val existingSubjects = academyDao.getAllSubjectsOnce().toMutableList()
        val extraSubjects = listOf(
            SubjectEntity(
                name = "Química",
                area = "Ciencias Naturales",
                description = "Estructura atómica, enlaces moleculares, estequiometría, equilibrio y síntesis orgánica.",
                iconKey = "science",
                colorHex = "#394BFA",
                masteryLevel = 0,
                isFavorite = false
            ),
            SubjectEntity(
                name = "Arte",
                area = "Humanidades y Artes",
                description = "Historia visual, composición, teoría del color, arquitectura y análisis iconográfico.",
                iconKey = "palette",
                colorHex = "#7027F5",
                masteryLevel = 0,
                isFavorite = false
            ),
            SubjectEntity(
                name = "Ciencias Naturales",
                area = "Ciencias Naturales",
                description = "Ecosistemas, sistemas vivos, materia, energía y método experimental integrado.",
                iconKey = "biotech",
                colorHex = "#2AD496",
                masteryLevel = 0,
                isFavorite = false
            )
        )

        extraSubjects.forEach { candidate ->
            if (existingSubjects.none { it.name.equals(candidate.name, ignoreCase = true) }) {
                val id = academyDao.insertSubject(candidate)
                existingSubjects.add(candidate.copy(id = id))
            }
        }

        // Asegurar al menos 5 áreas/unidades temáticas por materia para el dial radial de Preparación
        val areaTemplates: Map<String, List<Pair<String, List<String>>>> = mapOf(
            "Matemáticas" to listOf(
                "Número" to listOf("Conjuntos numéricos y densidad", "Exponentes, radicales y logaritmos"),
                "Álgebra" to listOf("Factorización y polinomios", "Sistemas de ecuaciones lineales"),
                "Variación" to listOf("Funciones y tasas de variación", "Límites y derivación básica"),
                "Geometría" to listOf("Razones trigonométricas", "Vectores y geometría analítica"),
                "Estadística" to listOf("Medidas de dispersión y posición", "Probabilidad condicional y Bayes")
            ),
            "Física" to listOf(
                "Mecánica" to listOf("Cinemática y leyes de Newton", "Trabajo, energía y cantidad de movimiento"),
                "Ondas" to listOf("Ondas mecánicas y resonancia", "Acústica e interferencia"),
                "Termodinámica" to listOf("Leyes térmicas y entropía", "Gases ideales y ciclos térmicos"),
                "Electromagnetismo" to listOf("Campo eléctrico y ley de Gauss", "Inducción de Faraday"),
                "Física Moderna" to listOf("Efecto fotoeléctrico", "Principios de relatividad especial")
            ),
            "Lengua y Literatura" to listOf(
                "Sintaxis" to listOf("Oración compuesta y subordinación", "Cohesión y conectores discursivos"),
                "Retórica" to listOf("Ethos, pathos y logos", "Figuras de pensamiento y estilo"),
                "Literatura" to listOf("Movimientos literarios y canon", "Análisis narratológico y poético"),
                "Semántica" to listOf("Precisión léxica y pragmática", "Campo semántico e inferencias"),
                "Redacción" to listOf("Estructura del ensayo académico", "Síntesis crítica y citación")
            ),
            "Historia" to listOf(
                "Fuentes" to listOf("Crítica de fuentes primarias", "Historiografía y método"),
                "Antigüedad" to listOf("Mundo clásico mediterráneo", "Instituciones y derecho antiguo"),
                "Edad Moderna" to listOf("Renacimiento e imprenta", "Revoluciones científicas y políticas"),
                "Siglo XIX-XX" to listOf("Industrialización y conflictos", "Orden geopolítico contemporáneo"),
                "Análisis" to listOf("Causalidad múltiple y procesos", "Ensayo histórico comparado")
            ),
            "Química" to listOf(
                "Átomo" to listOf("Configuración electrónica y orbitales", "Propiedades periódicas"),
                "Enlace" to listOf("Enlace iónico, covalente y polaridad", "Geometría molecular VSEPR"),
                "Reacciones" to listOf("Estequiometría y reactivo limitante", "Cinética química"),
                "Equilibrio" to listOf("Equilibrio ácido-base y pH", "Óxido-reducción y electroquímica"),
                "Orgánica" to listOf("Grupos funcionales e isomería", "Mecanismos fundamentales")
            ),
            "Geografía" to listOf(
                "Cartografía" to listOf("Escalas, proyecciones y SIG", "Lectura topográfica"),
                "Relieve" to listOf("Tectónica de placas y geomorfología", "Cuencas hidrográficas"),
                "Clima" to listOf("Dinámica atmosférica y biomas", "Cambio climático y anomalías"),
                "Población" to listOf("Demografía y urbanización", "Migraciones y redes globales"),
                "Territorio" to listOf("Geopolítica de recursos", "Desarrollo regional sostenible")
            ),
            "Filosofía" to listOf(
                "Lógica" to listOf("Validez deductiva y tablas", "Detección de falacias informales"),
                "Epistemología" to listOf("Criterios de demarcación científica", "Escepticismo y justificación"),
                "Ética" to listOf("Ética de la virtud y deontología", "Dilemas morales contemporáneos"),
                "Metafísica" to listOf("Ontología y causalidad", "Filosofía de la mente"),
                "Política" to listOf("Contrato social y justicia", "Esfera pública y deliberación")
            ),
            "Astronomía" to listOf(
                "Órbitas" to listOf("Leyes de Kepler y gravitación", "Coordenadas celestes"),
                "Sistema Solar" to listOf("Planetas rocosos y gigantes", "Cuerpos menores y dinámica"),
                "Estrellas" to listOf("Diagrama H-R y fusión nuclear", "Supernovas y remanentes"),
                "Galaxias" to listOf("Estructura espiral y materia oscura", "Exoplanetas y detección"),
                "Cosmología" to listOf("Expansión cósmica y CMB", "Instrumentación telescópica")
            ),
            "Arte" to listOf(
                "Composición" to listOf("Simetría, proporción áurea y ritmo", "Luz, claroscuro y perspectiva"),
                "Color" to listOf("Teoría cromática y contraste", "Paletas y atmósferas visuales"),
                "Iconografía" to listOf("Lectura simbólica clásica", "Estilo y contexto histórico"),
                "Arquitectura" to listOf("Órdenes clásicos y estructura", "Modernismo y espacio"),
                "Contemporáneo" to listOf("Vanguardias del siglo XX", "Crítica curatorial")
            ),
            "Idiomas" to listOf(
                "Gramática" to listOf("Tiempos verbales y aspecto", "Estructuras condicionales"),
                "Vocabulario" to listOf("Registro académico y colocaciones", "Raíces grecolatinas"),
                "Lectura" to listOf("Comprensión de ensayos complejos", "Inferencia pragmática"),
                "Escucha" to listOf("Fonética y ritmo prosódico", "Comprensión de conferencias"),
                "Expresión" to listOf("Síntesis oral estructurada", "Traducción matizada")
            )
        )

        val defaultSegments = listOf(
            "Fundamentos" to listOf("Conceptos nucleares", "Terminología esencial"),
            "Análisis" to listOf("Interpretación de casos", "Relaciones causales"),
            "Práctica" to listOf("Resolución guiada de problemas", "Aplicación en contexto"),
            "Síntesis" to listOf("Mapas y conexiones clave", "Integración interdisciplinar"),
            "Dominio" to listOf("Evaluación cronometrada", "Transferencia avanzada")
        )

        val allCourses = academyDao.getAllCoursesOnce().toMutableList()
        val allUnits = academyDao.getAllUnitsOnce().toMutableList()
        val allTopics = academyDao.getAllTopicsOnce().toMutableList()

        existingSubjects.forEach { subject ->
            val subjectCourses = allCourses.filter { it.subjectId == subject.id }
            val primaryCourse = subjectCourses.firstOrNull() ?: run {
                val newCourse = CourseEntity(
                    subjectId = subject.id,
                    title = "Programa Integral de ${subject.name}",
                    description = subject.description.ifBlank { "Ruta estructurada por áreas para preparación continua." },
                    level = "Intermedio",
                    coverKey = when (subject.area) {
                        "Ciencias Exactas" -> "math"
                        "Ciencias Naturales" -> "science"
                        else -> "humanities"
                    },
                    estimatedHours = 10
                )
                val cid = academyDao.insertCourse(newCourse)
                newCourse.copy(id = cid).also { allCourses.add(it) }
            }

            val subjectUnits = allUnits.filter { u -> subjectCourses.any { it.id == u.courseId } || u.courseId == primaryCourse.id }
            val blueprint = areaTemplates[subject.name] ?: defaultSegments
            if (subjectUnits.size < 5) {
                val existingTitles = subjectUnits.map { it.title.lowercase() }.toSet()
                var order = subjectUnits.size + 1
                blueprint.forEach { (segmentName, topicsList) ->
                    if (existingTitles.none { it.contains(segmentName.lowercase()) } && order <= 5) {
                        val unitId = academyDao.insertUnit(
                            UnitEntity(
                                courseId = primaryCourse.id,
                                title = segmentName,
                                summary = "Área modular de preparación: $segmentName en ${subject.name}.",
                                orderIndex = order
                            )
                        )
                        allUnits.add(UnitEntity(id = unitId, courseId = primaryCourse.id, title = segmentName, summary = "", orderIndex = order))
                        topicsList.forEachIndexed { idx, topicTitle ->
                            val tid = academyDao.insertTopic(
                                TopicEntity(
                                    unitId = unitId,
                                    title = topicTitle,
                                    learningObjective = "Comprender y aplicar $topicTitle.",
                                    masteryPercent = 0,
                                    isCompleted = false,
                                    orderIndex = idx + 1
                                )
                            )
                            allTopics.add(TopicEntity(id = tid, unitId = unitId, title = topicTitle, learningObjective = "", masteryPercent = 0, isCompleted = false, orderIndex = idx + 1))
                        }
                        order++
                    }
                }
            }
        }

        if (academyDao.countExams() == 0) {
            val mathSubject = existingSubjects.find { it.name == "Matemáticas" } ?: existingSubjects.firstOrNull()
            val physSubject = existingSubjects.find { it.name == "Física" }
            val notes = libDao.getAllNotesOnce()
            val mathNoteId = notes.firstOrNull { it.subjectName == "Matemáticas" }?.id?.toString().orEmpty()
            if (mathSubject != null) {
                academyDao.insertExam(
                    ExamEntity(
                        subjectId = mathSubject.id,
                        subjectName = mathSubject.name,
                        title = "Parcial de Cálculo y Límites",
                        examDateEpochDay = todayEpoch + 14,
                        syllabusTopicsCsv = "Número,Álgebra,Variación,Continuidad",
                        objectives = "Resolver indeterminaciones 0/0 y demostrar continuidad por definición.",
                        initialLevel = "Intermedio",
                        linkedNotebookIdsCsv = mathNoteId,
                        targetPercent = 85,
                        readinessPercent = 32,
                        lastSimulacroScore = 78,
                        simulacrosCount = 1
                    )
                )
            }
            if (physSubject != null) {
                academyDao.insertExam(
                    ExamEntity(
                        subjectId = physSubject.id,
                        subjectName = physSubject.name,
                        title = "Evaluación de Oscilaciones y Energía",
                        examDateEpochDay = todayEpoch + 28,
                        syllabusTopicsCsv = "Ley de Hooke,Movimiento Armónico,Ondas",
                        objectives = "Dominar conservación de energía mecánica y cálculo de periodo.",
                        initialLevel = "Intermedio",
                        targetPercent = 80,
                        readinessPercent = 44
                    )
                )
            }
        }

        if (academyDao.countRewardEvents() == 0) {
            academyDao.insertRewardEvent(
                RewardEventEntity(
                    title = "Bono inicial de estudiante LUMEN",
                    pointsDelta = 100,
                    category = "Academia"
                )
            )
            academyDao.insertRewardEvent(
                RewardEventEntity(
                    title = "Lección completada: Osciladores armónicos",
                    pointsDelta = 20,
                    category = "Lecciones"
                )
            )
        }
    }
}
