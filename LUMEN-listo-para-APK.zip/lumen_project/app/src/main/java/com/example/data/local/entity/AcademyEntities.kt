package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val area: String,
    val description: String,
    val iconKey: String,
    val colorHex: String,
    val masteryLevel: Int = 0,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "courses",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val title: String,
    val description: String,
    val level: String,
    val coverKey: String,
    val estimatedHours: Int = 8,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "units",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId")]
)
data class UnitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    val title: String,
    val summary: String,
    val orderIndex: Int = 0
)

@Entity(
    tableName = "topics",
    foreignKeys = [
        ForeignKey(
            entity = UnitEntity::class,
            parentColumns = ["id"],
            childColumns = ["unitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("unitId")]
)
data class TopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val unitId: Long,
    val title: String,
    val learningObjective: String,
    val masteryPercent: Int = 0,
    val isCompleted: Boolean = false,
    val orderIndex: Int = 0
)

@Entity(
    tableName = "lessons",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId"), Index("unitId")]
)
data class LessonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    val unitId: Long,
    val title: String,
    val subtitle: String,
    val level: String,
    val durationMinutes: Int,
    val explanation: String,
    val definitionsRaw: String,
    val examplesRaw: String,
    val diagramType: String,
    val comprehensionQuestion: String,
    val comprehensionOptionsRaw: String,
    val comprehensionAnswerIndex: Int,
    val practicalActivity: String,
    val evaluationQuestion: String,
    val evaluationOptionsRaw: String,
    val evaluationAnswerIndex: Int,
    val currentStage: Int = 0,
    val isCompleted: Boolean = false,
    val isUnlocked: Boolean = true,
    val scorePercent: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "exams",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class ExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val title: String,
    val examDateEpochDay: Long,
    val syllabusTopicsCsv: String = "",
    val selectedUnitIdsCsv: String = "",
    val objectives: String = "",
    val initialLevel: String = "Intermedio",
    val linkedNotebookIdsCsv: String = "",
    val targetPercent: Int = 85,
    val readinessPercent: Int = 0,
    val lastSimulacroScore: Int? = null,
    val simulacrosCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reward_events")
data class RewardEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val pointsDelta: Int,
    val category: String,
    val createdAt: Long = System.currentTimeMillis()
)

