package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiConnectionMode
import com.example.data.ai.AiRepository
import com.example.data.ai.AiStreamEvent
import com.example.data.ai.LabToolType
import com.example.data.local.entity.LabEntryEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.timeout
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

data class LabUiState(
    val selectedTool: LabToolType = LabToolType.QUIZ_GENERATOR,
    val streamingOutput: String = "",
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val lastFailedInput: Pair<String, String>? = null,
    val savedBannerMessage: String? = null,
    val entries: List<LabEntryEntity> = emptyList(),
    val connectionMode: AiConnectionMode = AiConnectionMode.FIREBASE_CONNECTED,
    val aiNotice: String = ""
)

class LabViewModel(
    private val repository: LumenRepository,
    private val aiRepository: AiRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _selectedTool = MutableStateFlow(LabToolType.QUIZ_GENERATOR)
    private val _streamingOutput = MutableStateFlow("")
    private val _isGenerating = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _lastFailedInput = MutableStateFlow<Pair<String, String>?>(null)
    private val _savedBanner = MutableStateFlow<String?>(null)
    private val _refreshTick = MutableStateFlow(0)
    private var activeJob: Job? = null

    val uiState: StateFlow<LabUiState> = combine(
        _selectedTool,
        _streamingOutput,
        _isGenerating,
        combine(_errorMessage, _lastFailedInput) { e, f -> e to f },
        combine(_savedBanner, repository.labEntries, _refreshTick) { banner, entries, _ -> banner to entries }
    ) { tool, output, generating, errPair, pair ->
        LabUiState(
            selectedTool = tool,
            streamingOutput = output,
            isGenerating = generating,
            errorMessage = errPair.first,
            lastFailedInput = errPair.second,
            savedBannerMessage = pair.first,
            entries = pair.second,
            connectionMode = aiRepository.currentConnectionMode(),
            aiNotice = aiRepository.currentStatusDescription()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LabUiState(
            connectionMode = aiRepository.currentConnectionMode(),
            aiNotice = aiRepository.currentStatusDescription()
        )
    )

    fun refreshConnectionStatus() {
        _refreshTick.value++
    }

    fun selectTool(tool: LabToolType) {
        _selectedTool.value = tool
        _errorMessage.value = null
    }

    @OptIn(FlowPreview::class)
    fun generate(topicOrInput: String, observations: String = "") {
        val clean = topicOrInput.trim()
        if (clean.isBlank() || _isGenerating.value) return

        val tool = _selectedTool.value
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _isGenerating.value = true
            _errorMessage.value = null
            _lastFailedInput.value = null
            _savedBanner.value = null
            _streamingOutput.value = ""
            refreshConnectionStatus()

            try {
                val prefs = preferencesRepository.preferences.first()
                var finalOutput = ""
                aiRepository.streamLabGeneration(tool, clean, prefs.preferredLevel)
                    .timeout(60.seconds)
                    .collect { event ->
                        when (event) {
                            is AiStreamEvent.Chunk -> _streamingOutput.value = event.accumulatedText
                            is AiStreamEvent.Completed -> finalOutput = event.finalText
                        }
                    }
                if (finalOutput.isNotBlank()) {
                    repository.saveLabEntry(
                        LabEntryEntity(
                            toolName = tool.title,
                            inputTopic = clean,
                            generatedOutput = finalOutput,
                            observations = observations.trim()
                        )
                    )
                } else {
                    _errorMessage.value = "Gemini no devolvió resultados para este experimento."
                    _lastFailedInput.value = clean to observations
                }
            } catch (e: TimeoutCancellationException) {
                Log.e("LabViewModel", "Tiempo agotado en Laboratorio", e)
                _errorMessage.value = "Tiempo de espera agotado tras 60 segundos. Inténtalo de nuevo."
                _lastFailedInput.value = clean to observations
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("LabViewModel", "Error en Laboratorio con Gemini", e)
                _errorMessage.value = e.localizedMessage ?: "No se pudo completar la generación con Gemini."
                _lastFailedInput.value = clean to observations
            } finally {
                _isGenerating.value = false
                refreshConnectionStatus()
            }
        }
    }

    fun retryLastFailed() {
        val last = _lastFailedInput.value ?: return
        generate(last.first, last.second)
    }

    fun cancelGeneration() {
        activeJob?.cancel()
        _isGenerating.value = false
    }

    fun saveEntryToLibrary(entry: LabEntryEntity) {
        viewModelScope.launch {
            repository.saveLabResultToLibrary(entry)
            _savedBanner.value = "Guardado en Biblioteca (${entry.toolName})"
        }
    }

    fun updateObservations(entry: LabEntryEntity, observations: String) {
        viewModelScope.launch { repository.updateLabObservations(entry, observations) }
    }

    fun deleteEntry(entry: LabEntryEntity) {
        viewModelScope.launch { repository.deleteLabEntry(entry) }
    }

    fun clearBanner() {
        _savedBanner.value = null
    }
}
