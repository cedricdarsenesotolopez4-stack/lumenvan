package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ActivityLogEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class DailyMinutesPoint(
    val epochDay: Long,
    val label: String,
    val minutes: Int
)

data class PlannerUiState(
    val selectedEpochDay: Long = LocalDate.now().toEpochDay(),
    val allTasks: List<PlannerTaskEntity> = emptyList(),
    val dayTasks: List<PlannerTaskEntity> = emptyList(),
    val habits: List<HabitEntity> = emptyList(),
    val sessions: List<StudySessionEntity> = emptyList(),
    val weeklyMinutes: List<DailyMinutesPoint> = emptyList(),
    val totalWeekMinutes: Int = 0,
    val activityHistory: List<ActivityLogEntity> = emptyList()
)

class PlannerViewModel(private val repository: LumenRepository) : ViewModel() {

    private val _selectedDay = MutableStateFlow(LocalDate.now().toEpochDay())

    val uiState: StateFlow<PlannerUiState> = combine(
        _selectedDay,
        repository.tasks,
        repository.habits,
        repository.studySessions,
        repository.recentActivity
    ) { selectedDay, tasks, habits, sessions, logs ->
        val dayTasks = tasks.filter { it.dueDateEpochDay == selectedDay }
        val today = LocalDate.now()
        val weekDays = (6L downTo 0L).map { offset ->
            val date = today.minusDays(offset)
            val epoch = date.toEpochDay()
            val mins = sessions.filter { it.dateEpochDay == epoch }.sumOf { it.durationMinutes }
            val dayLabel = when (date.dayOfWeek.value) {
                1 -> "L"
                2 -> "M"
                3 -> "X"
                4 -> "J"
                5 -> "V"
                6 -> "S"
                else -> "D"
            }
            DailyMinutesPoint(epochDay = epoch, label = dayLabel, minutes = mins)
        }

        PlannerUiState(
            selectedEpochDay = selectedDay,
            allTasks = tasks,
            dayTasks = dayTasks,
            habits = habits,
            sessions = sessions,
            weeklyMinutes = weekDays,
            totalWeekMinutes = weekDays.sumOf { it.minutes },
            activityHistory = logs
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PlannerUiState()
    )

    fun selectDay(epochDay: Long) {
        _selectedDay.value = epochDay
    }

    fun addTask(
        title: String,
        description: String,
        dueDateEpochDay: Long,
        dueTimeLabel: String,
        priority: String,
        category: String,
        subjectName: String
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.saveTask(
                PlannerTaskEntity(
                    title = title.trim(),
                    description = description.trim(),
                    dueDateEpochDay = dueDateEpochDay,
                    dueTimeLabel = dueTimeLabel.ifBlank { "18:00" },
                    priority = priority,
                    category = category,
                    subjectName = subjectName.ifBlank { "General" }
                )
            )
        }
    }

    fun toggleTask(task: PlannerTaskEntity) {
        viewModelScope.launch { repository.toggleTaskCompleted(task) }
    }

    fun deleteTask(task: PlannerTaskEntity) {
        viewModelScope.launch { repository.deleteTask(task) }
    }

    fun logStudySession(subjectName: String, durationMinutes: Int, notes: String) {
        if (durationMinutes <= 0) return
        viewModelScope.launch {
            repository.logStudySession(
                subjectName = subjectName.ifBlank { "Estudio general" },
                minutes = durationMinutes,
                notes = notes.trim()
            )
        }
    }

    fun addHabit(title: String, targetPerWeek: Int) {
        if (title.isBlank()) return
        viewModelScope.launch { repository.addHabit(title.trim(), targetPerWeek) }
    }

    fun toggleHabitToday(habit: HabitEntity) {
        viewModelScope.launch { repository.toggleHabitToday(habit) }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch { repository.deleteHabit(habit) }
    }
}
