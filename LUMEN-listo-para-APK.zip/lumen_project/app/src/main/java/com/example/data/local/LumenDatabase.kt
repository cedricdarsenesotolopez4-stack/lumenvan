package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AcademyDao
import com.example.data.local.dao.LibraryDao
import com.example.data.local.dao.PlannerDao
import com.example.data.local.dao.TutorDao
import com.example.data.local.entity.ActivityLogEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.LabEntryEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.local.entity.UnitEntity

@Database(
    entities = [
        SubjectEntity::class,
        CourseEntity::class,
        UnitEntity::class,
        TopicEntity::class,
        LessonEntity::class,
        ExamEntity::class,
        RewardEventEntity::class,
        TutorEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        NoteEntity::class,
        FlashcardEntity::class,
        QuizEntity::class,
        QuizQuestionEntity::class,
        LabEntryEntity::class,
        PlannerTaskEntity::class,
        StudySessionEntity::class,
        HabitEntity::class,
        ActivityLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class LumenDatabase : RoomDatabase() {
    abstract fun academyDao(): AcademyDao
    abstract fun tutorDao(): TutorDao
    abstract fun libraryDao(): LibraryDao
    abstract fun plannerDao(): PlannerDao

    companion object {
        @Volatile
        private var INSTANCE: LumenDatabase? = null

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exams` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `subjectId` INTEGER NOT NULL,
                        `subjectName` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `examDateEpochDay` INTEGER NOT NULL,
                        `syllabusTopicsCsv` TEXT NOT NULL,
                        `selectedUnitIdsCsv` TEXT NOT NULL,
                        `objectives` TEXT NOT NULL,
                        `initialLevel` TEXT NOT NULL,
                        `linkedNotebookIdsCsv` TEXT NOT NULL,
                        `targetPercent` INTEGER NOT NULL,
                        `readinessPercent` INTEGER NOT NULL,
                        `lastSimulacroScore` INTEGER,
                        `simulacrosCount` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        FOREIGN KEY(`subjectId`) REFERENCES `subjects`(`id`) ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exams_subjectId` ON `exams` (`subjectId`)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `reward_events` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `title` TEXT NOT NULL,
                        `pointsDelta` INTEGER NOT NULL,
                        `category` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): LumenDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LumenDatabase::class.java,
                    "lumen_academy.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
