package com.example.ui.components.academy

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalLumenColors

@Composable
fun FloatingTutorButton(
    subjectName: String,
    onClick: () -> Unit,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val pillShape = RoundedCornerShape(999.dp)

    Row(
        modifier = modifier
            .heightIn(min = if (compact) 34.dp else 48.dp)
            .shadow(12.dp, pillShape, ambientColor = c.academyViolet.copy(alpha = 0.4f))
            .clip(pillShape)
            .background(
                Brush.horizontalGradient(
                    listOf(c.academyDeepViolet.copy(alpha = 0.9f), c.academyGraphite)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(c.academyViolet.copy(alpha = 0.7f), c.academyLuminousBlue.copy(alpha = 0.55f))
                ),
                shape = pillShape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = if (compact) 10.dp else 14.dp, vertical = if (compact) 5.dp else 10.dp)
            .testTag("academy_floating_tutor_button")
            .semantics { contentDescription = "Abrir tutor Gemini para $subjectName" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.AutoAwesome,
            contentDescription = null,
            tint = c.academyLuminousBlue,
            modifier = Modifier.size(if (compact) 15.dp else 18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "Tutor IA",
            style = MaterialTheme.typography.labelLarge.copy(
                fontSize = if (compact) 11.sp else 12.sp,
                fontWeight = FontWeight.SemiBold
            ),
            color = c.academyWhite
        )
    }
}

@Composable
fun ApplicationsButton(
    hasPendingItems: Boolean,
    onClick: () -> Unit,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val outerSize = if (compact) 36.dp else 50.dp
    val circleSize = if (compact) 34.dp else 48.dp

    Box(
        modifier = modifier
            .size(outerSize)
            .testTag("academy_floating_apps_button")
    ) {
        Box(
            modifier = Modifier
                .size(circleSize)
                .align(Alignment.Center)
                .shadow(10.dp, CircleShape)
                .clip(CircleShape)
                .background(c.academyGraphite)
                .border(1.dp, c.academyDarkGray, CircleShape)
                .clickable(onClick = onClick)
                .semantics { contentDescription = "Abrir aplicaciones de estudio" },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Apps,
                contentDescription = null,
                tint = c.academyWhite,
                modifier = Modifier.size(if (compact) 18.dp else 22.dp)
            )
        }
        if (hasPendingItems) {
            Box(
                modifier = Modifier
                    .size(if (compact) 9.dp else 11.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = (-1).dp, y = 1.dp)
                    .clip(CircleShape)
                    .background(c.academyElectricBlue)
                    .border(1.5.dp, c.academyBg, CircleShape)
            )
        }
    }
}

@Composable
fun AcademyBottomNavigation(
    onOpenExams: () -> Unit,
    onOpenStart: () -> Unit,
    onOpenApps: () -> Unit,
    compact: Boolean = false,
    ultraShort: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AcademyCircularNavButton(
            label = "EXÁMENES",
            icon = Icons.Rounded.School,
            isPrimary = false,
            compact = compact,
            ultraShort = ultraShort,
            testTag = "academy_nav_exams",
            onClick = onOpenExams
        )
        AcademyCircularNavButton(
            label = "COMENZAR",
            icon = Icons.Rounded.PlayArrow,
            isPrimary = true,
            compact = compact,
            ultraShort = ultraShort,
            testTag = "academy_nav_start",
            onClick = onOpenStart
        )
        AcademyCircularNavButton(
            label = "APPS",
            icon = Icons.Rounded.Apps,
            isPrimary = false,
            compact = compact,
            ultraShort = ultraShort,
            testTag = "academy_nav_apps",
            onClick = onOpenApps
        )
    }
}

@Composable
private fun AcademyCircularNavButton(
    label: String,
    icon: ImageVector,
    isPrimary: Boolean,
    compact: Boolean,
    ultraShort: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val c = LocalLumenColors.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.65f),
        label = "circleNavScale"
    )
    val circleSize = when {
        ultraShort && isPrimary -> 38.dp
        ultraShort -> 34.dp
        compact && isPrimary -> 50.dp
        compact -> 46.dp
        isPrimary -> 62.dp
        else -> 56.dp
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = if (ultraShort) 0.dp else if (compact) 1.dp else 4.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(circleSize)
                .shadow(
                    elevation = if (isPrimary) 16.dp else 8.dp,
                    shape = CircleShape,
                    ambientColor = if (isPrimary) c.academyElectricBlue else Color.Black,
                    spotColor = if (isPrimary) c.academyLuminousBlue else Color.Black
                )
                .clip(CircleShape)
                .background(
                    if (isPrimary) {
                        Brush.verticalGradient(
                            listOf(c.academyLuminousBlue, c.academyElectricBlue, Color(0xFF2838CC))
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(c.academyDarkGray, c.academyGraphite, c.academyBlackSecondary)
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = if (isPrimary) 0.45f else 0.16f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(
                    when {
                        ultraShort && isPrimary -> 20.dp
                        ultraShort -> 17.dp
                        isPrimary -> 28.dp
                        else -> 23.dp
                    }
                )
            )
        }
        Spacer(modifier = Modifier.height(if (ultraShort) 2.dp else 6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = if (ultraShort) 8.5.sp else 10.sp,
                lineHeight = if (ultraShort) 10.sp else 12.sp,
                fontWeight = if (isPrimary) FontWeight.Bold else FontWeight.Medium,
                letterSpacing = if (ultraShort) 0.7.sp else 1.1.sp
            ),
            color = if (isPrimary) c.academyWhite else c.academyMediumGray
        )
    }
}
