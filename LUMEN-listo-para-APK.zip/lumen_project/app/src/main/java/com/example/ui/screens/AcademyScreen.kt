package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.example.ui.components.LumenGlassDialog
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.example.data.ai.LabToolType
import com.example.data.local.entity.LessonEntity
import com.example.domain.PreparationCalculator
import com.example.domain.RecommendationKind
import com.example.ui.components.academy.AcademyBottomNavigation
import com.example.ui.components.academy.AcademyTopBar
import com.example.ui.components.academy.ActiveSegmentTopicsSheet
import com.example.ui.components.academy.ApplicationsButton
import com.example.ui.components.academy.AppsHubModal
import com.example.ui.components.academy.CreateSubjectDialog
import com.example.ui.components.academy.ExamsHubModal
import com.example.ui.components.academy.FloatingTutorButton
import com.example.ui.components.academy.PreparationGauge
import com.example.ui.components.academy.ProfileModal
import com.example.ui.components.academy.QuickStartAndHelpModal
import com.example.ui.components.academy.RewardsModal
import com.example.ui.components.academy.StreakStatsModal
import com.example.ui.components.academy.SubjectCatalogSheet
import com.example.ui.components.academy.SubjectHeader
import com.example.ui.components.academy.SubjectPagerIndicator
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.AcademyUiState
import com.example.ui.viewmodel.AcademyViewModel
import kotlinx.coroutines.launch

private enum class AcademyOverlay {
    NONE,
    STREAK,
    REWARDS,
    PROFILE,
    SEGMENT_TOPICS,
    START_HELP,
    APPS,
    EXAMS,
    SUBJECT_CATALOG,
    CREATE_SUBJECT
}

@Composable
fun AcademyScreen(
    state: AcademyUiState,
    viewModel: AcademyViewModel,
    onOpenLesson: (LessonEntity) -> Unit,
    onOpenTutorWithContext: (subjectName: String, areaName: String, topicName: String?, readinessPercent: Int, initialPrompt: String?) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenLabTool: (LabToolType) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val scope = rememberCoroutineScope()
    var activeOverlay by remember { mutableStateOf(AcademyOverlay.NONE) }

    if (activeOverlay != AcademyOverlay.NONE) {
        BackHandler { activeOverlay = AcademyOverlay.NONE }
    }

    val subjects = state.subjects
    val pageCount = maxOf(1, subjects.size)
    val pagerState = rememberPagerState(
        initialPage = state.activeSubjectIndex.coerceIn(0, maxOf(0, pageCount - 1)),
        pageCount = { pageCount }
    )

    LaunchedEffect(pagerState.settledPage, subjects.size) {
        if (subjects.isNotEmpty() && pagerState.settledPage != state.activeSubjectIndex) {
            viewModel.selectActiveSubjectIndex(pagerState.settledPage)
        }
    }

    LaunchedEffect(state.activeSubjectIndex, subjects.size) {
        if (subjects.isNotEmpty() &&
            state.activeSubjectIndex in subjects.indices &&
            pagerState.currentPage != state.activeSubjectIndex &&
            !pagerState.isScrollInProgress
        ) {
            pagerState.animateScrollToPage(state.activeSubjectIndex)
        }
    }

    val activeSubject = state.activeSubject
    val activeSegment = state.segments.getOrNull(state.selectedSegmentIndex)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(c.academyBg)
            .testTag("academy_subjects_list")
    ) {
        val isCompactScreen = maxHeight < 560.dp
        val isUltraShort = maxHeight < 440.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 620.dp)
                .align(Alignment.Center)
                .statusBarsPadding()
                .padding(bottom = if (isUltraShort) 2.dp else if (isCompactScreen) 4.dp else 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Barra superior en 3 zonas
            AcademyTopBar(
                streakDays = state.streakDays,
                pointsBalance = state.pointsBalance,
                avatarKey = state.avatarKey,
                onStreakClick = { activeOverlay = AcademyOverlay.STREAK },
                onRewardsClick = { activeOverlay = AcademyOverlay.REWARDS },
                onProfileClick = { activeOverlay = AcademyOverlay.PROFILE },
                compact = isCompactScreen,
                ultraShort = isUltraShort
            )

            // 2. Cabecera limpia sin tarjetas + puntos de paginación
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                SubjectHeader(
                    subject = activeSubject,
                    overallReadinessPercent = state.readinessPercent,
                    onOpenSubjectCatalog = { activeOverlay = AcademyOverlay.SUBJECT_CATALOG },
                    onCreateSubject = { activeOverlay = AcademyOverlay.CREATE_SUBJECT },
                    compact = isCompactScreen,
                    ultraShort = isUltraShort
                )
                Spacer(modifier = Modifier.height(if (isUltraShort) 1.dp else if (isCompactScreen) 2.dp else 6.dp))
                SubjectPagerIndicator(
                    pageCount = subjects.size,
                    activeIndex = pagerState.currentPage,
                    onSelectPage = { idx ->
                        scope.launch { pagerState.animateScrollToPage(idx) }
                        viewModel.selectActiveSubjectIndex(idx)
                    },
                    ultraShort = isUltraShort
                )
            }

            // 3. Medidor radial protagonista con pager horizontal nativo medido contra espacio disponible real
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val dialSize = min(maxWidth * 0.80f, maxHeight * 0.96f).coerceIn(110.dp, 315.dp)
                if (subjects.isEmpty()) {
                    Text(
                        text = "Cargando materias de LUMEN...",
                        color = c.academyMediumGray
                    )
                } else {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("academy_subject_pager")
                    ) { pageIndex ->
                        val pageSubject = subjects.getOrNull(pageIndex)
                        val pageSegments = remember(
                            pageSubject?.id,
                            state.courses,
                            state.units,
                            state.topics,
                            state.lessons,
                            state.quizzes,
                            state.flashcards
                        ) {
                            if (pageSubject == null) emptyList()
                            else if (pageSubject.id == activeSubject?.id && state.segments.isNotEmpty()) {
                                state.segments
                            } else {
                                PreparationCalculator.computeForSubject(
                                    subject = pageSubject,
                                    courses = state.courses,
                                    units = state.units,
                                    topics = state.topics,
                                    lessons = state.lessons,
                                    quizzes = state.quizzes,
                                    flashcards = state.flashcards,
                                    sessions = emptyList()
                                ).segments
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            PreparationGauge(
                                segments = pageSegments,
                                selectedSegmentIndex = if (pageIndex == pagerState.currentPage) state.selectedSegmentIndex else 0,
                                onSelectSegment = { segIdx -> viewModel.selectSegmentIndex(segIdx) },
                                onAdvanceActiveSegment = { activeOverlay = AcademyOverlay.SEGMENT_TOPICS },
                                dialSize = dialSize
                            )
                        }
                    }
                }
            }

            // 4. Botones flotantes inferiores laterales (Tutor contextual izquierda / Apps derecha)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = if (isUltraShort) 1.dp else if (isCompactScreen) 2.dp else 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FloatingTutorButton(
                    subjectName = activeSubject?.name ?: "Matemáticas",
                    onClick = {
                        val sName = activeSubject?.name ?: "Matemáticas"
                        val aName = activeSegment?.title ?: "General"
                        val topTopic = activeSegment?.topics?.firstOrNull { !it.isCompleted }?.title
                            ?: activeSegment?.topics?.firstOrNull()?.title
                        onOpenTutorWithContext(
                            sName,
                            aName,
                            topTopic,
                            activeSegment?.readinessPercent ?: state.readinessPercent,
                            null
                        )
                    },
                    compact = isUltraShort
                )
                ApplicationsButton(
                    hasPendingItems = state.dueFlashcardsCount > 0 || state.exams.isNotEmpty(),
                    onClick = { activeOverlay = AcademyOverlay.APPS },
                    compact = isUltraShort
                )
            }

            // 5. Navegación circular inferior en 3 columnas (EXÁMENES / COMENZAR / APPS)
            AcademyBottomNavigation(
                onOpenExams = { activeOverlay = AcademyOverlay.EXAMS },
                onOpenStart = { activeOverlay = AcademyOverlay.START_HELP },
                onOpenApps = { activeOverlay = AcademyOverlay.APPS },
                compact = isCompactScreen,
                ultraShort = isUltraShort
            )
        }
    }

    // Overlays y modales interactivos funcionales
    when (activeOverlay) {
        AcademyOverlay.NONE -> Unit

        AcademyOverlay.STREAK -> {
            StreakStatsModal(
                streakDays = state.streakDays,
                maxStreakDays = state.maxStreakDays,
                weeklyActiveDaysMask = state.weeklyActiveDaysMask,
                subjectName = activeSubject?.name ?: "Matemáticas",
                onLogSessionNow = {
                    viewModel.logQuickStudySession(activeSubject?.name ?: "Matemáticas", 25)
                },
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.REWARDS -> {
            RewardsModal(
                pointsBalance = state.pointsBalance,
                activeTitle = state.activeAccentTitle,
                catalog = state.rewardCatalog,
                unlockedIds = state.unlockedRewardIds,
                history = state.rewardHistory,
                onRedeem = viewModel::redeemReward,
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.PROFILE -> {
            ProfileModal(
                userName = state.userName,
                avatarKey = state.avatarKey,
                activeTitle = state.activeAccentTitle,
                pointsBalance = state.pointsBalance,
                streakDays = state.streakDays,
                subjects = state.subjects,
                onSelectAvatar = viewModel::selectAvatar,
                onUpdateName = viewModel::updateUserName,
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.SEGMENT_TOPICS -> {
            if (activeSubject != null && activeSegment != null) {
                ActiveSegmentTopicsSheet(
                    subject = activeSubject,
                    segment = activeSegment,
                    onSetTopicState = viewModel::setTopicMasteryState,
                    onAddTopic = { title, obj ->
                        viewModel.addTopicToActiveSubjectSegment(activeSegment, title, obj)
                    },
                    onOpenLesson = { lesson ->
                        activeOverlay = AcademyOverlay.NONE
                        onOpenLesson(lesson)
                    },
                    onAskTutor = { topicTitle ->
                        activeOverlay = AcademyOverlay.NONE
                        onOpenTutorWithContext(
                            activeSubject.name,
                            activeSegment.title,
                            topicTitle,
                            activeSegment.readinessPercent,
                            null
                        )
                    },
                    onDismiss = { activeOverlay = AcademyOverlay.NONE }
                )
            }
        }

        AcademyOverlay.START_HELP -> {
            QuickStartAndHelpModal(
                activeSubject = activeSubject,
                activeAreaName = activeSegment?.title ?: "Fundamentos",
                recommendations = state.recommendations,
                onOpenExams = { activeOverlay = AcademyOverlay.EXAMS },
                onExecuteRecommendation = { rec ->
                    when (rec.kind) {
                        RecommendationKind.RESUME_LESSON -> {
                            val lesson = state.lessons.find { it.id == rec.targetLessonId }
                            if (lesson != null) onOpenLesson(lesson) else activeOverlay = AcademyOverlay.SEGMENT_TOPICS
                        }
                        RecommendationKind.PREPARE_EXAM -> activeOverlay = AcademyOverlay.EXAMS
                        RecommendationKind.PRACTICE_WEAK_AREA -> {
                            rec.targetSegmentIndex?.let { viewModel.selectSegmentIndex(it) }
                            activeOverlay = AcademyOverlay.SEGMENT_TOPICS
                        }
                        RecommendationKind.REVIEW_FLASHCARDS, RecommendationKind.TAKE_QUIZ -> onOpenLibrary()
                        RecommendationKind.ASK_TUTOR -> {
                            onOpenTutorWithContext(
                                activeSubject?.name ?: "Matemáticas",
                                activeSegment?.title ?: "General",
                                null,
                                state.readinessPercent,
                                null
                            )
                        }
                    }
                },
                onSendToTutorWithContext = { question ->
                    onOpenTutorWithContext(
                        activeSubject?.name ?: "Matemáticas",
                        activeSegment?.title ?: "General",
                        activeSegment?.topics?.firstOrNull()?.title,
                        activeSegment?.readinessPercent ?: state.readinessPercent,
                        question
                    )
                },
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.APPS -> {
            AppsHubModal(
                subjectName = activeSubject?.name ?: "Matemáticas",
                dueFlashcardsCount = state.dueFlashcardsCount,
                onOpenLabTool = onOpenLabTool,
                onOpenLibraryTab = onOpenLibrary,
                onOpenExams = { activeOverlay = AcademyOverlay.EXAMS },
                onCreateQuickNotebook = { title ->
                    viewModel.createQuickNotebook(title, activeSubject?.name ?: "Matemáticas")
                },
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.EXAMS -> {
            val subjectLesson = state.lessons.firstOrNull { lesson ->
                state.courses.any { it.id == lesson.courseId && it.subjectId == activeSubject?.id } && !lesson.isCompleted
            } ?: state.lessons.firstOrNull { !it.isCompleted }

            ExamsHubModal(
                subjects = state.subjects,
                activeSubject = activeSubject,
                exams = state.exams,
                notebooks = state.notebooks,
                weeklyMinutesByDay = state.weeklyMinutesByDay,
                weeklyTotalMinutes = state.weeklyTotalMinutes,
                nextLesson = subjectLesson,
                onCreateExam = viewModel::createExam,
                onDeleteExam = viewModel::deleteExam,
                onRecordSimulacro = viewModel::recordExamSimulacro,
                onToggleNotebookLink = viewModel::toggleNotebookLinkForExam,
                onCreateQuickNotebook = viewModel::createQuickNotebook,
                onOpenLesson = onOpenLesson,
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.SUBJECT_CATALOG -> {
            SubjectCatalogSheet(
                subjects = state.subjects,
                activeSubjectId = activeSubject?.id,
                onSelectSubjectIndex = { idx ->
                    viewModel.selectActiveSubjectIndex(idx)
                    scope.launch { pagerState.animateScrollToPage(idx) }
                },
                onCreateSubjectClick = { activeOverlay = AcademyOverlay.CREATE_SUBJECT },
                onToggleFavorite = viewModel::toggleFavorite,
                onDeleteSubject = viewModel::deleteSubject,
                onDismiss = { activeOverlay = AcademyOverlay.NONE }
            )
        }

        AcademyOverlay.CREATE_SUBJECT -> {
            CreateSubjectDialog(
                onDismiss = { activeOverlay = AcademyOverlay.NONE },
                onConfirm = { name, area, desc ->
                    viewModel.saveSubject(0L, name, area, desc, 0, "#394BFA")
                    activeOverlay = AcademyOverlay.NONE
                }
            )
        }
    }
}

@Composable
fun SimpleTwoFieldDialog(
    dialogTitle: String,
    field1Label: String,
    field2Label: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }

    LumenGlassDialog(
        title = dialogTitle,
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(onClick = { onConfirm(f1, f2) }, enabled = f1.isNotBlank()) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    ) {
        OutlinedTextField(
            value = f1,
            onValueChange = { f1 = it },
            label = { Text("$field1Label *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = f2,
            onValueChange = { f2 = it },
            label = { Text(field2Label) },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
