package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val notes: List<NoteEntity> = emptyList(),
    val flashcards: List<FlashcardEntity> = emptyList(),
    val dueFlashcards: List<FlashcardEntity> = emptyList(),
    val quizzes: List<QuizEntity> = emptyList(),
    val folders: List<String> = emptyList(),
    val selectedFolder: String = "Todas",
    val selectedCategory: String = "Todas",
    val searchQuery: String = "",
    val onlyFavorites: Boolean = false
)

class LibraryViewModel(private val repository: LumenRepository) : ViewModel() {

    private val _selectedFolder = MutableStateFlow("Todas")
    private val _selectedCategory = MutableStateFlow("Todas")
    private val _searchQuery = MutableStateFlow("")
    private val _onlyFavorites = MutableStateFlow(false)

    private val filterFlow = combine(
        _selectedFolder,
        _selectedCategory,
        _searchQuery,
        _onlyFavorites
    ) { folder, category, query, fav ->
        listOf(folder, category, query, fav)
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        repository.notes,
        repository.flashcards,
        repository.quizzes,
        filterFlow
    ) { notes, flashcards, quizzes, filters ->
        val folder = filters[0] as String
        val category = filters[1] as String
        val query = filters[2] as String
        val onlyFav = filters[3] as Boolean

        val folders = listOf("Todas") + notes.map { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
        val filteredNotes = notes.filter { n ->
            (folder == "Todas" || n.folder == folder) &&
                (category == "Todas" || n.category == category) &&
                (!onlyFav || n.isFavorite) &&
                (query.isBlank() ||
                    n.title.contains(query, ignoreCase = true) ||
                    n.content.contains(query, ignoreCase = true) ||
                    n.tagsCsv.contains(query, ignoreCase = true) ||
                    n.subjectName.contains(query, ignoreCase = true))
        }

        val now = System.currentTimeMillis()
        val dueCards = flashcards.filter { it.nextReviewAt <= now }

        LibraryUiState(
            notes = filteredNotes,
            flashcards = flashcards,
            dueFlashcards = dueCards,
            quizzes = quizzes,
            folders = folders,
            selectedFolder = folder,
            selectedCategory = category,
            searchQuery = query,
            onlyFavorites = onlyFav
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun observeQuizQuestions(quizId: Long) = repository.observeQuizQuestions(quizId)

    fun selectFolder(folder: String) {
        _selectedFolder.value = folder
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearch(query: String) {
        _searchQuery.value = query
    }

    fun toggleOnlyFavorites() {
        _onlyFavorites.value = !_onlyFavorites.value
    }

    fun saveNote(
        id: Long,
        title: String,
        content: String,
        folder: String,
        tagsCsv: String,
        category: String,
        referenceSource: String,
        subjectName: String,
        isFavorite: Boolean
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.saveNote(
                NoteEntity(
                    id = id,
                    title = title.trim(),
                    content = content.trim(),
                    folder = folder.trim().ifBlank { "General" },
                    tagsCsv = tagsCsv.trim(),
                    category = category,
                    referenceSource = referenceSource.trim(),
                    subjectName = subjectName.trim().ifBlank { "General" },
                    isFavorite = isFavorite
                )
            )
        }
    }

    fun toggleFavorite(note: NoteEntity) {
        viewModelScope.launch { repository.toggleNoteFavorite(note) }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch { repository.deleteNote(note) }
    }

    fun saveFlashcard(subject: String, front: String, back: String) {
        if (front.isBlank() || back.isBlank()) return
        viewModelScope.launch {
            repository.saveFlashcard(
                FlashcardEntity(
                    subjectName = subject.trim().ifBlank { "General" },
                    front = front.trim(),
                    back = back.trim()
                )
            )
        }
    }

    fun reviewFlashcard(card: FlashcardEntity, quality: Int) {
        viewModelScope.launch { repository.reviewFlashcard(card, quality) }
    }

    fun deleteFlashcard(card: FlashcardEntity) {
        viewModelScope.launch { repository.deleteFlashcard(card) }
    }

    fun createQuiz(
        title: String,
        subject: String,
        description: String,
        questions: List<QuizQuestionEntity>
    ) {
        if (title.isBlank() || questions.isEmpty()) return
        viewModelScope.launch {
            repository.createQuiz(title.trim(), subject.trim().ifBlank { "General" }, description.trim(), questions)
        }
    }

    fun recordQuizAttempt(quiz: QuizEntity, scorePercent: Int) {
        viewModelScope.launch { repository.recordQuizAttempt(quiz, scorePercent) }
    }

    fun deleteQuiz(quiz: QuizEntity) {
        viewModelScope.launch { repository.deleteQuiz(quiz) }
    }
}
