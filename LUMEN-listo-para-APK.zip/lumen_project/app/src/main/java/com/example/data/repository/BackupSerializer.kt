package com.example.data.repository

import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.SubjectEntity
import org.json.JSONArray
import org.json.JSONObject

data class LumenBackupPayload(
    val subjects: List<SubjectEntity>,
    val notes: List<NoteEntity>,
    val flashcards: List<FlashcardEntity>,
    val tasks: List<PlannerTaskEntity>,
    val habits: List<HabitEntity>
)

object BackupSerializer {

    fun toJsonString(payload: LumenBackupPayload): String {
        val root = JSONObject()
        root.put("app", "LUMEN")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val subjectsArr = JSONArray()
        payload.subjects.forEach { s ->
            subjectsArr.put(JSONObject().apply {
                put("name", s.name)
                put("area", s.area)
                put("description", s.description)
                put("iconKey", s.iconKey)
                put("colorHex", s.colorHex)
                put("masteryLevel", s.masteryLevel)
                put("isFavorite", s.isFavorite)
            })
        }
        root.put("subjects", subjectsArr)

        val notesArr = JSONArray()
        payload.notes.forEach { n ->
            notesArr.put(JSONObject().apply {
                put("title", n.title)
                put("content", n.content)
                put("folder", n.folder)
                put("tagsCsv", n.tagsCsv)
                put("category", n.category)
                put("referenceSource", n.referenceSource)
                put("subjectName", n.subjectName)
                put("isFavorite", n.isFavorite)
            })
        }
        root.put("notes", notesArr)

        val cardsArr = JSONArray()
        payload.flashcards.forEach { c ->
            cardsArr.put(JSONObject().apply {
                put("subjectName", c.subjectName)
                put("front", c.front)
                put("back", c.back)
                put("masteryLevel", c.masteryLevel)
                put("easeFactor", c.easeFactor)
                put("intervalDays", c.intervalDays)
                put("repetitions", c.repetitions)
            })
        }
        root.put("flashcards", cardsArr)

        val tasksArr = JSONArray()
        payload.tasks.forEach { t ->
            tasksArr.put(JSONObject().apply {
                put("title", t.title)
                put("description", t.description)
                put("dueDateEpochDay", t.dueDateEpochDay)
                put("dueTimeLabel", t.dueTimeLabel)
                put("priority", t.priority)
                put("category", t.category)
                put("subjectName", t.subjectName)
                put("isCompleted", t.isCompleted)
            })
        }
        root.put("tasks", tasksArr)

        val habitsArr = JSONArray()
        payload.habits.forEach { h ->
            habitsArr.put(JSONObject().apply {
                put("title", h.title)
                put("targetPerWeek", h.targetPerWeek)
                put("currentStreak", h.currentStreak)
            })
        }
        root.put("habits", habitsArr)

        return root.toString(2)
    }

    fun fromJsonString(raw: String): LumenBackupPayload {
        val root = JSONObject(raw)
        if (root.optString("app") != "LUMEN") {
            throw IllegalArgumentException("El archivo seleccionado no corresponde a una copia de LUMEN.")
        }

        val subjects = mutableListOf<SubjectEntity>()
        val subjectsArr = root.optJSONArray("subjects") ?: JSONArray()
        for (i in 0 until subjectsArr.length()) {
            val obj = subjectsArr.getJSONObject(i)
            subjects += SubjectEntity(
                name = obj.getString("name"),
                area = obj.optString("area", "Personalizada"),
                description = obj.optString("description", ""),
                iconKey = obj.optString("iconKey", "menu_book"),
                colorHex = obj.optString("colorHex", "#D4AF37"),
                masteryLevel = obj.optInt("masteryLevel", 0),
                isFavorite = obj.optBoolean("isFavorite", false)
            )
        }

        val notes = mutableListOf<NoteEntity>()
        val notesArr = root.optJSONArray("notes") ?: JSONArray()
        for (i in 0 until notesArr.length()) {
            val obj = notesArr.getJSONObject(i)
            notes += NoteEntity(
                title = obj.getString("title"),
                content = obj.optString("content", ""),
                folder = obj.optString("folder", "General"),
                tagsCsv = obj.optString("tagsCsv", ""),
                category = obj.optString("category", "Apunte"),
                referenceSource = obj.optString("referenceSource", ""),
                subjectName = obj.optString("subjectName", "General"),
                isFavorite = obj.optBoolean("isFavorite", false)
            )
        }

        val cards = mutableListOf<FlashcardEntity>()
        val cardsArr = root.optJSONArray("flashcards") ?: JSONArray()
        for (i in 0 until cardsArr.length()) {
            val obj = cardsArr.getJSONObject(i)
            cards += FlashcardEntity(
                subjectName = obj.optString("subjectName", "General"),
                front = obj.getString("front"),
                back = obj.getString("back"),
                masteryLevel = obj.optInt("masteryLevel", 0),
                easeFactor = obj.optDouble("easeFactor", 2.5),
                intervalDays = obj.optInt("intervalDays", 1),
                repetitions = obj.optInt("repetitions", 0)
            )
        }

        val tasks = mutableListOf<PlannerTaskEntity>()
        val tasksArr = root.optJSONArray("tasks") ?: JSONArray()
        for (i in 0 until tasksArr.length()) {
            val obj = tasksArr.getJSONObject(i)
            tasks += PlannerTaskEntity(
                title = obj.getString("title"),
                description = obj.optString("description", ""),
                dueDateEpochDay = obj.optLong("dueDateEpochDay", 0L),
                dueTimeLabel = obj.optString("dueTimeLabel", "18:00"),
                priority = obj.optString("priority", "MEDIA"),
                category = obj.optString("category", "Estudio"),
                subjectName = obj.optString("subjectName", "General"),
                isCompleted = obj.optBoolean("isCompleted", false)
            )
        }

        val habits = mutableListOf<HabitEntity>()
        val habitsArr = root.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until habitsArr.length()) {
            val obj = habitsArr.getJSONObject(i)
            habits += HabitEntity(
                title = obj.getString("title"),
                targetPerWeek = obj.optInt("targetPerWeek", 5),
                currentStreak = obj.optInt("currentStreak", 0)
            )
        }

        return LumenBackupPayload(subjects, notes, cards, tasks, habits)
    }
}
