package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QuestionMark
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.LocalLumenColors

/**
 * Panel Liquid Glass multicapa con reflejo especular superior, transparencia calibrada
 * y borde luminoso fino sin desenfoque pesado sobre textos o entradas de teclado.
 */
@Composable
fun LumenGlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    glowColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val lumenColors = LocalLumenColors.current
    val shape = RoundedCornerShape(cornerRadius)
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.985f else 1f,
        animationSpec = spring(stiffness = 650f),
        label = "glass_press_scale"
    )

    val glassBrush = if (lumenColors.isDark) {
        Brush.linearGradient(
            colors = listOf(
                Color(0xD9192033),
                Color(0xB80E121D),
                Color(0xCC0B0E17)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xEBFFFFFF),
                Color(0xCCF3F6FC)
            )
        )
    }

    val rimBrush = Brush.linearGradient(
        colors = listOf(
            glowColor?.copy(alpha = 0.55f) ?: lumenColors.glassEdgeTop,
            lumenColors.glassEdgeBottom,
            lumenColors.violet.copy(alpha = if (lumenColors.isDark) 0.28f else 0.16f)
        )
    )

    val boxModifier = modifier
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .shadow(
            elevation = 16.dp,
            shape = shape,
            ambientColor = (glowColor ?: lumenColors.electricBlue).copy(alpha = 0.35f),
            spotColor = lumenColors.violet.copy(alpha = 0.25f)
        )
        .clip(shape)
        .background(brush = glassBrush, shape = shape)
        .border(width = 1.dp, brush = rimBrush, shape = shape)
        .then(
            if (onClick != null) {
                Modifier.clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
            } else {
                Modifier
            }
        )

    Box(modifier = boxModifier) {
        // Reflejo especular sutil superior
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = if (lumenColors.isDark) 0.22f else 0.7f),
                            Color.Transparent
                        )
                    )
                )
        )
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

/**
 * Botón principal grande azul eléctrico 3D con degradado discreto, brillo superior y microinteracción.
 */
@Composable
fun LumenElectricButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    val lumenColors = LocalLumenColors.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.97f else 1f,
        animationSpec = spring(stiffness = 700f),
        label = "electric_button_scale"
    )
    val shape = RoundedCornerShape(28.dp)

    val bgBrush = if (enabled) {
        Brush.verticalGradient(
            listOf(
                lumenColors.electricBlueBright,
                lumenColors.electricBlue,
                lumenColors.electricBlueDeep
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.surfaceContainerHigh,
                MaterialTheme.colorScheme.surfaceContainer
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (enabled) 18.dp else 0.dp,
                shape = shape,
                ambientColor = lumenColors.electricBlue.copy(alpha = 0.55f),
                spotColor = lumenColors.electricBlue.copy(alpha = 0.6f)
            )
            .clip(shape)
            .background(brush = bgBrush, shape = shape)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = if (enabled) 0.38f else 0.08f),
                        Color.Transparent
                    )
                ),
                shape = shape
            )
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 24.dp, vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Etiqueta monoespaciada en mayúsculas al estilo de la referencia visual.
 */
@Composable
fun LumenMonospaceTag(
    text: String,
    accentColor: Color = LocalLumenColors.current.electricBlueBright,
    containerColor: Color = LocalLumenColors.current.blueContainer,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = containerColor.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.32f))
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = accentColor,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

enum class NodeVisualState {
    ACTIVE,
    COMPLETED,
    LOCKED
}

/**
 * Nodo/plataforma circular 3D apilado inspirado en la referencia visual:
 * disco volumétrico luminoso para lecciones activas/completadas y placa grafito para pendientes/bloqueadas.
 */
@Composable
fun Lumen3dOrbitalNode(
    state: NodeVisualState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 94.dp,
    floatingQuestionBubble: Boolean = false
) {
    val lumenColors = LocalLumenColors.current
    val infiniteTransition = rememberInfiniteTransition(label = "node_pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_val"
    )
    val floatY by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_y"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        if (floatingQuestionBubble && state == NodeVisualState.ACTIVE) {
            Box(
                modifier = Modifier
                    .offset(y = floatY.dp)
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF283254), Color(0xFF101524))
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.QuestionMark,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Box(
            modifier = Modifier
                .size(width = size, height = size * 0.84f)
                .clickable(enabled = state != NodeVisualState.LOCKED, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = this.size.width
                val h = this.size.height
                val center = Offset(w / 2f, h * 0.45f)
                val rx = w * 0.44f
                val ry = h * 0.34f

                if (state == NodeVisualState.ACTIVE) {
                    // Aro orbital exterior luminoso
                    drawOval(
                        color = lumenColors.electricBlueBright.copy(alpha = 0.28f + 0.18f * pulse),
                        topLeft = Offset(center.x - rx * 1.15f, center.y - ry * 0.95f),
                        size = Size(rx * 2.3f, ry * 2.15f),
                        style = Stroke(width = 3.5f)
                    )
                    // Base 3D apilada profunda
                    drawOval(
                        color = Color(0xFF1A2875),
                        topLeft = Offset(center.x - rx, center.y - ry + h * 0.14f),
                        size = Size(rx * 2f, ry * 2f)
                    )
                    // Cuerpo azul eléctrico
                    drawOval(
                        brush = Brush.verticalGradient(
                            listOf(lumenColors.electricBlue, lumenColors.electricBlueDeep)
                        ),
                        topLeft = Offset(center.x - rx, center.y - ry + h * 0.05f),
                        size = Size(rx * 2f, ry * 2f)
                    )
                    // Domo superior iluminado
                    drawOval(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFEAF0FF),
                                lumenColors.electricBlueBright,
                                lumenColors.electricBlue
                            ),
                            center = Offset(center.x, center.y - ry * 0.15f),
                            radius = rx * 0.9f
                        ),
                        topLeft = Offset(center.x - rx * 0.86f, center.y - ry * 0.86f),
                        size = Size(rx * 1.72f, ry * 1.72f)
                    )
                } else if (state == NodeVisualState.COMPLETED) {
                    drawOval(
                        color = Color(0xFF103E35),
                        topLeft = Offset(center.x - rx, center.y - ry + h * 0.13f),
                        size = Size(rx * 2f, ry * 2f)
                    )
                    drawOval(
                        brush = Brush.radialGradient(
                            listOf(lumenColors.success, Color(0xFF198761))
                        ),
                        topLeft = Offset(center.x - rx, center.y - ry),
                        size = Size(rx * 2f, ry * 2f)
                    )
                } else {
                    // Placa oscura bloqueada con volumen metálico
                    drawOval(
                        color = Color(0xFF0A0D14),
                        topLeft = Offset(center.x - rx, center.y - ry + h * 0.14f),
                        size = Size(rx * 2f, ry * 2f)
                    )
                    drawOval(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF282D3B), Color(0xFF151924))
                        ),
                        topLeft = Offset(center.x - rx, center.y - ry),
                        size = Size(rx * 2f, ry * 2f)
                    )
                    drawOval(
                        color = Color.White.copy(alpha = 0.08f),
                        topLeft = Offset(center.x - rx, center.y - ry),
                        size = Size(rx * 2f, ry * 2f),
                        style = Stroke(width = 2f)
                    )
                }
            }

            when (state) {
                NodeVisualState.COMPLETED -> Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = "Completada",
                    tint = Color.White,
                    modifier = Modifier.offset(y = (-4).dp).size(24.dp)
                )
                NodeVisualState.LOCKED -> Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = "Bloqueada",
                    tint = Color(0xFF8B93A8),
                    modifier = Modifier.offset(y = (-4).dp).size(22.dp)
                )
                NodeVisualState.ACTIVE -> Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = "Activa",
                    tint = Color(0xFF101C52),
                    modifier = Modifier.offset(y = (-4).dp).size(24.dp)
                )
            }
        }
    }
}

/**
 * Objeto 3D protagonista para el panel de bienvenida y la cabecera de la academia privada.
 */
@Composable
fun Lumen3dPrismCore(
    progressPercent: Int,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    val transition = rememberInfiniteTransition(label = "prism_float")
    val hover by transition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "prism_hover"
    )

    Box(
        modifier = modifier.size(92.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { translationY = hover }
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            // Halo ambiental sutil
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        lumenColors.electricBlue.copy(alpha = 0.34f),
                        lumenColors.violet.copy(alpha = 0.14f),
                        Color.Transparent
                    )
                ),
                radius = w * 0.48f,
                center = Offset(cx, cy)
            )

            // Aro de progreso orbital
            drawArc(
                color = Color.White.copy(alpha = 0.12f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(w * 0.08f, h * 0.08f),
                size = Size(w * 0.84f, h * 0.84f),
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(lumenColors.electricBlueBright, lumenColors.violet, lumenColors.electricBlueBright)
                ),
                startAngle = -90f,
                sweepAngle = 360f * (progressPercent.coerceIn(0, 100) / 100f),
                useCenter = false,
                topLeft = Offset(w * 0.08f, h * 0.08f),
                size = Size(w * 0.84f, h * 0.84f),
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )

            // Octaedro/prisma central 3D con dos caras sombreadas
            val top = Offset(cx, cy - h * 0.25f)
            val bottom = Offset(cx, cy + h * 0.25f)
            val left = Offset(cx - w * 0.2f, cy)
            val right = Offset(cx + w * 0.2f, cy)

            val leftFace = Path().apply {
                moveTo(top.x, top.y)
                lineTo(left.x, left.y)
                lineTo(bottom.x, bottom.y)
                close()
            }
            val rightFace = Path().apply {
                moveTo(top.x, top.y)
                lineTo(right.x, right.y)
                lineTo(bottom.x, bottom.y)
                close()
            }
            drawPath(
                path = leftFace,
                brush = Brush.verticalGradient(listOf(Color(0xFF9DB2FF), lumenColors.electricBlue))
            )
            drawPath(
                path = rightFace,
                brush = Brush.verticalGradient(listOf(lumenColors.violet, lumenColors.electricBlueDeep))
            )
            drawLine(Color.White.copy(alpha = 0.55f), top, bottom, strokeWidth = 2f)
        }
    }
}

/**
 * Tarjeta de racha semanal con puntos luminosos (inspirada en el lenguaje visual de la referencia).
 */
@Composable
fun LumenStreakPill(
    streakDays: Int,
    weeklyActiveMask: Int,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    val dayLabels = listOf("L", "M", "X", "J", "V", "S", "D")

    LumenGlassPanel(
        modifier = modifier,
        cornerRadius = 24.dp,
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(lumenColors.electricBlueBright, lumenColors.violet)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocalFireDepartment,
                        contentDescription = "Racha de estudio",
                        tint = Color.White,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Racha de $streakDays día${if (streakDays == 1) "" else "s"}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "ESTA SEMANA",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                dayLabels.forEachIndexed { idx, label ->
                    val active = (weeklyActiveMask and (1 shl idx)) != 0
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .drawBehind {
                                    if (active) {
                                        drawCircle(
                                            color = lumenColors.electricBlue.copy(alpha = 0.45f),
                                            radius = size.minDimension * 0.9f
                                        )
                                    }
                                }
                                .clip(CircleShape)
                                .background(
                                    if (active) lumenColors.electricBlueBright
                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                                )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Cápsula contadora estilo referencia visual con texto monoespaciado en mayúsculas y cifra destacada.
 */
@Composable
fun LumenCounterPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    accentColor: Color = LocalLumenColors.current.electricBlueBright
) {
    val lumenColors = LocalLumenColors.current
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = lumenColors.glassSurface,
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    accentColor.copy(alpha = 0.6f),
                    lumenColors.glassEdgeBottom
                )
            )
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

/**
 * Diálogo Liquid Glass translúcido con desplazamiento seguro para teclado y pantallas compactas.
 */
@Composable
fun LumenGlassDialog(
    title: String,
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val lumenColors = LocalLumenColors.current
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LumenGlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            cornerRadius = 28.dp,
            contentPadding = PaddingValues(20.dp),
            glowColor = lumenColors.electricBlue
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(14.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (dismissButton != null) {
                    dismissButton()
                    Spacer(modifier = Modifier.width(8.dp))
                }
                confirmButton()
            }
        }
    }
}

