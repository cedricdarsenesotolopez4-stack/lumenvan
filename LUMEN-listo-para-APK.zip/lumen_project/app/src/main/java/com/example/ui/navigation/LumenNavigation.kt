package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.AppContainer
import com.example.ui.components.LumenTopBar
import com.example.ui.screens.AcademyScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LabScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.LessonsCatalogScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.MoreHubScreen
import com.example.ui.screens.PlannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TutorsScreen
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.AcademyViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.LabViewModel
import com.example.ui.viewmodel.LessonsViewModel
import com.example.ui.viewmodel.LibraryViewModel
import com.example.ui.viewmodel.LumenViewModelFactory
import com.example.ui.viewmodel.PlannerViewModel
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.TutorsAndChatViewModel

object LumenRoutes {
    const val HOME = "home"
    const val ACADEMY = "academy"
    const val TUTORS = "tutors"
    const val LIBRARY = "library"
    const val PLANNER = "planner"
    const val MORE = "more"
    const val LESSONS = "lessons"
    const val LESSON_DETAIL = "lesson_detail/{lessonId}"
    const val CONVERSATIONS = "conversations"
    const val LAB = "lab"
    const val SETTINGS = "settings"

    fun lessonDetail(lessonId: Long) = "lesson_detail/$lessonId"
}

data class BottomTabItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val primaryTabs = listOf(
    BottomTabItem(LumenRoutes.HOME, "Inicio", Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
    BottomTabItem(LumenRoutes.ACADEMY, "Academia", Icons.Rounded.School, Icons.Outlined.School, "nav_academy"),
    BottomTabItem(LumenRoutes.TUTORS, "Tutores", Icons.Rounded.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_tutors"),
    BottomTabItem(LumenRoutes.LIBRARY, "Biblioteca", Icons.Rounded.MenuBook, Icons.Outlined.MenuBook, "nav_library"),
    BottomTabItem(LumenRoutes.PLANNER, "Agenda", Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_planner")
)

@Composable
fun LumenAppRoot(container: AppContainer) {
    val factory = LumenViewModelFactory(container)
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: LumenRoutes.HOME

    val homeVm: HomeViewModel = viewModel(factory = factory)
    val academyVm: AcademyViewModel = viewModel(factory = factory)
    val lessonsVm: LessonsViewModel = viewModel(factory = factory)
    val tutorsVm: TutorsAndChatViewModel = viewModel(factory = factory)
    val libraryVm: LibraryViewModel = viewModel(factory = factory)
    val labVm: LabViewModel = viewModel(factory = factory)
    val plannerVm: PlannerViewModel = viewModel(factory = factory)
    val settingsVm: SettingsViewModel = viewModel(factory = factory)

    val lumenColors = LocalLumenColors.current
    val isPrimaryTab = primaryTabs.any { it.route == currentRoute }
    val hideAllChrome = currentRoute.startsWith("lesson_detail") ||
        (currentRoute == LumenRoutes.CONVERSATIONS &&
            tutorsVm.activeConversationId.collectAsStateWithLifecycle().value != null)
    val hideTopBar = hideAllChrome || currentRoute == LumenRoutes.ACADEMY
    val hideBottomBar = hideAllChrome

    val (topTitle, topSubtitle) = when {
        currentRoute == LumenRoutes.HOME -> "LUMEN" to "Academia privada"
        currentRoute == LumenRoutes.ACADEMY -> "Academia" to "Disciplinas y programas"
        currentRoute == LumenRoutes.TUTORS -> "Tutores" to "Mentores Gemini"
        currentRoute == LumenRoutes.LIBRARY -> "Biblioteca" to "Apuntes, tarjetas y tests"
        currentRoute == LumenRoutes.PLANNER -> "Planificador" to "Agenda, foco y hábitos"
        currentRoute == LumenRoutes.MORE -> "Más" to "Centro de herramientas"
        currentRoute == LumenRoutes.LESSONS -> "Lecciones" to "Ruta de aprendizaje 3D"
        currentRoute == LumenRoutes.CONVERSATIONS -> "Sesiones" to "Historial con tutores"
        currentRoute == LumenRoutes.LAB -> "Laboratorio" to "Experimentación Gemini"
        currentRoute == LumenRoutes.SETTINGS -> "Ajustes" to "Sistema, IA y respaldo"
        else -> "LUMEN" to null
    }

    fun navigateTopTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .drawBehind {
                if (lumenColors.isDark) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                lumenColors.electricBlue.copy(alpha = 0.14f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.85f, size.height * 0.08f),
                            radius = size.width * 0.72f
                        ),
                        center = Offset(size.width * 0.85f, size.height * 0.08f),
                        radius = size.width * 0.72f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                lumenColors.violet.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.12f, size.height * 0.55f),
                            radius = size.width * 0.65f
                        ),
                        center = Offset(size.width * 0.12f, size.height * 0.55f),
                        radius = size.width * 0.65f
                    )
                }
            }
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                if (!hideTopBar) {
                    LumenTopBar(
                        title = topTitle,
                        subtitle = topSubtitle,
                        showBack = !isPrimaryTab,
                        onBack = { navController.popBackStack() },
                        showMoreAction = currentRoute != LumenRoutes.MORE,
                        onMoreClick = {
                            navController.navigate(LumenRoutes.MORE) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (!useRail && !hideBottomBar) {
                    LumenLiquidBottomBar(
                        tabs = primaryTabs,
                        currentRoute = currentRoute,
                        onSelectTab = ::navigateTopTab
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && !hideBottomBar) {
                    NavigationRail(
                        containerColor = lumenColors.glassSurface
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        primaryTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = lumenColors.electricBlueBright,
                                    selectedTextColor = lumenColors.electricBlueBright,
                                    indicatorColor = lumenColors.electricBlue.copy(alpha = 0.2f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = LumenRoutes.HOME,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(LumenRoutes.HOME) {
                        val state by homeVm.uiState.collectAsStateWithLifecycle()
                        HomeScreen(
                            state = state,
                            onContinueLesson = { lesson ->
                                navController.navigate(LumenRoutes.lessonDetail(lesson.id))
                            },
                            onOpenAcademy = { navigateTopTab(LumenRoutes.ACADEMY) },
                            onOpenTutor = { tutor ->
                                tutorsVm.startConversationWithTutor(tutor) {
                                    navController.navigate(LumenRoutes.CONVERSATIONS)
                                }
                            },
                            onOpenLibrary = { navigateTopTab(LumenRoutes.LIBRARY) },
                            onOpenLab = { navController.navigate(LumenRoutes.LAB) },
                            onOpenPlanner = { navigateTopTab(LumenRoutes.PLANNER) },
                            onToggleTask = homeVm::toggleTask
                        )
                    }

                    composable(LumenRoutes.ACADEMY) {
                        val state by academyVm.uiState.collectAsStateWithLifecycle()
                        AcademyScreen(
                            state = state,
                            viewModel = academyVm,
                            onOpenLesson = { lesson ->
                                navController.navigate(LumenRoutes.lessonDetail(lesson.id))
                            },
                            onOpenTutorWithContext = { subjectName, areaName, topicName, readinessPercent, initialPrompt ->
                                tutorsVm.startContextualTutorSession(
                                    subjectName = subjectName,
                                    areaName = areaName,
                                    topicName = topicName,
                                    readinessPercent = readinessPercent,
                                    initialPrompt = initialPrompt
                                ) {
                                    navController.navigate(LumenRoutes.CONVERSATIONS)
                                }
                            },
                            onOpenLibrary = { navigateTopTab(LumenRoutes.LIBRARY) },
                            onOpenLabTool = { tool ->
                                labVm.selectTool(tool)
                                navController.navigate(LumenRoutes.LAB)
                            }
                        )
                    }

                    composable(LumenRoutes.TUTORS) {
                        val hubState by tutorsVm.hubState.collectAsStateWithLifecycle()
                        TutorsScreen(
                            hubState = hubState,
                            viewModel = tutorsVm,
                            onOpenConversation = { convId ->
                                tutorsVm.selectConversation(convId)
                                navController.navigate(LumenRoutes.CONVERSATIONS)
                            },
                            onOpenConversationsCenter = {
                                tutorsVm.selectConversation(null)
                                navController.navigate(LumenRoutes.CONVERSATIONS)
                            }
                        )
                    }

                    composable(LumenRoutes.LIBRARY) {
                        val state by libraryVm.uiState.collectAsStateWithLifecycle()
                        LibraryScreen(
                            state = state,
                            viewModel = libraryVm,
                            onOpenImportExport = { navController.navigate(LumenRoutes.SETTINGS) }
                        )
                    }

                    composable(LumenRoutes.PLANNER) {
                        val state by plannerVm.uiState.collectAsStateWithLifecycle()
                        PlannerScreen(state = state, viewModel = plannerVm)
                    }

                    composable(LumenRoutes.MORE) {
                        MoreHubScreen(
                            onOpenLessons = { navController.navigate(LumenRoutes.LESSONS) },
                            onOpenConversations = {
                                tutorsVm.selectConversation(null)
                                navController.navigate(LumenRoutes.CONVERSATIONS)
                            },
                            onOpenLab = { navController.navigate(LumenRoutes.LAB) },
                            onOpenSettings = { navController.navigate(LumenRoutes.SETTINGS) }
                        )
                    }

                    composable(LumenRoutes.LESSONS) {
                        val catalogState by lessonsVm.catalogState.collectAsStateWithLifecycle()
                        LessonsCatalogScreen(
                            state = catalogState,
                            onSelectLesson = { lesson ->
                                navController.navigate(LumenRoutes.lessonDetail(lesson.id))
                            }
                        )
                    }

                    composable(
                        route = LumenRoutes.LESSON_DETAIL,
                        arguments = listOf(navArgument("lessonId") { type = NavType.LongType })
                    ) { entry ->
                        val lessonId = entry.arguments?.getLong("lessonId") ?: 0L
                        LessonDetailScreen(
                            lessonId = lessonId,
                            viewModel = lessonsVm,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(LumenRoutes.CONVERSATIONS) {
                        val hubState by tutorsVm.hubState.collectAsStateWithLifecycle()
                        val chatState by tutorsVm.chatState.collectAsStateWithLifecycle()
                        val activeId by tutorsVm.activeConversationId.collectAsStateWithLifecycle()
                        ConversationsScreen(
                            hubState = hubState,
                            chatState = chatState,
                            activeConversationId = activeId,
                            viewModel = tutorsVm
                        )
                    }

                    composable(LumenRoutes.LAB) {
                        val state by labVm.uiState.collectAsStateWithLifecycle()
                        LabScreen(state = state, viewModel = labVm)
                    }

                    composable(LumenRoutes.SETTINGS) {
                        val state by settingsVm.uiState.collectAsStateWithLifecycle()
                        SettingsScreen(state = state, viewModel = settingsVm)
                    }
                }
            }
        }
    }
}

@Composable
private fun LumenLiquidBottomBar(
    tabs: List<BottomTabItem>,
    currentRoute: String,
    onSelectTab: (String) -> Unit
) {
    val lumenColors = LocalLumenColors.current
    val shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        lumenColors.glassEdgeTop,
                        lumenColors.electricBlueBright.copy(alpha = 0.45f),
                        lumenColors.glassEdgeTop,
                        Color.Transparent
                    )
                ),
                shape = shape
            ),
        color = lumenColors.glassSurface,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                val selected = currentRoute == tab.route
                val interaction = remember { MutableInteractionSource() }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable(
                            interactionSource = interaction,
                            indication = null,
                            onClick = { onSelectTab(tab.route) }
                        )
                        .padding(vertical = 4.dp)
                        .testTag(tab.testTag)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (selected) {
                                    Brush.horizontalGradient(
                                        listOf(
                                            lumenColors.electricBlue.copy(alpha = 0.28f),
                                            lumenColors.violet.copy(alpha = 0.22f)
                                        )
                                    )
                                } else {
                                    Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                }
                            )
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.label,
                            tint = if (selected) lumenColors.electricBlueBright else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) lumenColors.electricBlueBright else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
