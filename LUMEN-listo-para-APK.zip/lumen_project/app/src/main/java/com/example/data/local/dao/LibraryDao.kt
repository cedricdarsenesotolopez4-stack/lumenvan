package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.LabEntryEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM notes ORDER BY isFavorite DESC, updatedAt DESC")
    fun observeNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes")
    suspend fun getAllNotesOnce(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)

    @Query("SELECT * FROM flashcards ORDER BY nextReviewAt ASC, id ASC")
    fun observeFlashcards(): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards")
    suspend fun getAllFlashcardsOnce(): List<FlashcardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcard(card: FlashcardEntity): Long

    @Update
    suspend fun updateFlashcard(card: FlashcardEntity)

    @Delete
    suspend fun deleteFlashcard(card: FlashcardEntity)

    @Query("SELECT * FROM quizzes ORDER BY createdAt DESC")
    fun observeQuizzes(): Flow<List<QuizEntity>>

    @Query("SELECT * FROM quizzes")
    suspend fun getAllQuizzesOnce(): List<QuizEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: QuizEntity): Long

    @Update
    suspend fun updateQuiz(quiz: QuizEntity)

    @Delete
    suspend fun deleteQuiz(quiz: QuizEntity)

    @Query("SELECT * FROM quiz_questions WHERE quizId = :quizId ORDER BY id ASC")
    fun observeQuizQuestions(quizId: Long): Flow<List<QuizQuestionEntity>>

    @Query("SELECT * FROM quiz_questions")
    suspend fun getAllQuizQuestionsOnce(): List<QuizQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizQuestion(question: QuizQuestionEntity): Long

    @Query("SELECT * FROM lab_entries ORDER BY createdAt DESC")
    fun observeLabEntries(): Flow<List<LabEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLabEntry(entry: LabEntryEntity): Long

    @Update
    suspend fun updateLabEntry(entry: LabEntryEntity)

    @Delete
    suspend fun deleteLabEntry(entry: LabEntryEntity)
}
