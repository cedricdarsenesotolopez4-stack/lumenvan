package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.AppContainer

class LumenViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) ->
                HomeViewModel(container.repository, container.preferencesRepository) as T
            modelClass.isAssignableFrom(AcademyViewModel::class.java) ->
                AcademyViewModel(container.repository, container.preferencesRepository) as T
            modelClass.isAssignableFrom(LessonsViewModel::class.java) ->
                LessonsViewModel(container.repository) as T
            modelClass.isAssignableFrom(TutorsAndChatViewModel::class.java) ->
                TutorsAndChatViewModel(
                    container.repository,
                    container.aiRepository,
                    container.preferencesRepository
                ) as T
            modelClass.isAssignableFrom(LibraryViewModel::class.java) ->
                LibraryViewModel(container.repository) as T
            modelClass.isAssignableFrom(LabViewModel::class.java) ->
                LabViewModel(
                    container.repository,
                    container.aiRepository,
                    container.preferencesRepository
                ) as T
            modelClass.isAssignableFrom(PlannerViewModel::class.java) ->
                PlannerViewModel(container.repository) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(
                    container.repository,
                    container.preferencesRepository,
                    container.aiRepository
                ) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
