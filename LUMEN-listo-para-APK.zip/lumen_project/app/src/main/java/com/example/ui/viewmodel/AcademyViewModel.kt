package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.UnitEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import com.example.domain.AcademyRecommendation
import com.example.domain.GaugeSegmentModel
import com.example.domain.PreparationCalculator
import com.example.domain.RecommendationUseCase
import com.example.domain.SubjectPreparationReport
import com.example.domain.TopicMasteryState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class RewardCatalogItem(
    val id: String,
    val title: String,
    val description: String,
    val cost: Int,
    val category: String
)

data class AcademyUiState(
    val subjects: List<SubjectEntity> = emptyList(),
    val activeSubjectIndex: Int = 0,
    val activeSubject: SubjectEntity? = null,
    val segments: List<GaugeSegmentModel> = emptyList(),
    val selectedSegmentIndex: Int = 0,
    val preparationReport: SubjectPreparationReport? = null,
    val readinessPercent: Int = 0,
    val streakDays: Int = 1,
    val maxStreakDays: Int = 1,
    val weeklyActiveDaysMask: Int = 0b1000000,
    val weeklyMinutesByDay: List<Int> = List(7) { 0 },
    val weeklyTotalMinutes: Int = 0,
    val pointsBalance: Int = 120,
    val userName: String = "Estudiante",
    val avatarKey: String = "cosmos",
    val activeAccentTitle: String = "Aprendiz LUMEN",
    val unlockedRewardIds: Set<String> = emptySet(),
    val rewardCatalog: List<RewardCatalogItem> = defaultRewardCatalog(),
    val rewardHistory: List<RewardEventEntity> = emptyList(),
    val exams: List<ExamEntity> = emptyList(),
    val notebooks: List<NoteEntity> = emptyList(),
    val courses: List<CourseEntity> = emptyList(),
    val units: List<UnitEntity> = emptyList(),
    val topics: List<TopicEntity> = emptyList(),
    val lessons: List<LessonEntity> = emptyList(),
    val flashcards: List<FlashcardEntity> = emptyList(),
    val quizzes: List<QuizEntity> = emptyList(),
    val dueFlashcardsCount: Int = 0,
    val recommendations: List<AcademyRecommendation> = emptyList(),
    val areas: List<String> = emptyList(),
    val selectedArea: String = "Todas",
    val searchQuery: String = "",
    val selectedSubjectId: Long? = null
)

fun defaultRewardCatalog(): List<RewardCatalogItem> = listOf(
    RewardCatalogItem(
        id = "badge_polymath",
        title = "Insignia Polímata",
        description = "Distintivo académico de dominio multidisciplinar en tu perfil.",
        cost = 60,
        category = "Insignia"
    ),
    RewardCatalogItem(
        id = "theme_aurora",
        title = "Aura Electric Indigo",
        description = "Halo cromático azul luminoso y violeta para tus logros locales.",
        cost = 90,
        category = "Estilo"
    ),
    RewardCatalogItem(
        id = "title_researcher",
        title = "Título: Investigador Senior",
        description = "Acreditación local tras constancia y simulacros completados.",
        cost = 150,
        category = "Título"
    ),
    RewardCatalogItem(
        id = "badge_orion",
        title = "Emblema Orión 3D",
        description = "Emblema geométrico espacial para tu ficha de preparación.",
        cost = 200,
        category = "Insignia"
    )
)

class AcademyViewModel(
    private val repository: LumenRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _selectedArea = MutableStateFlow("Todas")
    private val _searchQuery = MutableStateFlow("")
    private val _selectedSubjectId = MutableStateFlow<Long?>(null)
    private val _selectedSegmentIndex = MutableStateFlow(0)
    private val _activeSubjectIdOverride = MutableStateFlow<Long?>(null)

    private val academyCoreFlow = combine(
        repository.subjects,
        repository.courses,
        repository.units,
        repository.topics,
        repository.lessons
    ) { subjects, courses, units, topics, lessons ->
        AcademyCoreBundle(subjects, courses, units, topics, lessons)
    }

    private val progressBundleFlow = combine(
        repository.exams,
        repository.rewardEvents,
        repository.notes,
        repository.flashcards,
        repository.quizzes
    ) { exams, rewards, notes, cards, quizzes ->
        ProgressBundle(exams, rewards, notes, cards, quizzes)
    }

    private val plannerAndPrefsFlow = combine(
        repository.studySessions,
        repository.habits,
        preferencesRepository.preferences
    ) { sessions, habits, prefs ->
        Triple(sessions, habits, prefs)
    }

    val uiState: StateFlow<AcademyUiState> = combine(
        academyCoreFlow,
        progressBundleFlow,
        plannerAndPrefsFlow,
        combine(_selectedArea, _searchQuery, _selectedSubjectId, _selectedSegmentIndex, _activeSubjectIdOverride) { a, q, s, seg, ov ->
            FilterParams(a, q, s, seg, ov)
        }
    ) { core, progress, (sessions, habits, prefs), filters ->
        val allSubjects = core.subjects
        val distinctAreas = listOf("Todas") + allSubjects.map { it.area }.distinct().sorted()
        val filteredSubjects = allSubjects.filter { s ->
            (filters.area == "Todas" || s.area == filters.area) &&
                (filters.query.isBlank() || s.name.contains(filters.query, ignoreCase = true) ||
                    s.description.contains(filters.query, ignoreCase = true))
        }

        val pagerSubjects = if (filteredSubjects.isNotEmpty()) filteredSubjects else allSubjects
        val preferredId = filters.activeSubjectIdOverride ?: prefs.lastActiveSubjectId
        val activeIndex = pagerSubjects.indexOfFirst { it.id == preferredId }
            .let { idx -> if (idx >= 0) idx else 0 }
        val activeSubject = pagerSubjects.getOrNull(activeIndex)

        val prepReport = activeSubject?.let { subject ->
            PreparationCalculator.computeForSubject(
                subject = subject,
                courses = core.courses,
                units = core.units,
                topics = core.topics,
                lessons = core.lessons,
                quizzes = progress.quizzes,
                flashcards = progress.flashcards,
                sessions = sessions
            )
        }

        val segments = prepReport?.segments.orEmpty()
        val segIdx = if (segments.isEmpty()) 0 else filters.segmentIndex.coerceIn(0, segments.lastIndex)

        val today = LocalDate.now()
        val todayEpoch = today.toEpochDay()
        val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
        val weeklyMinutes = (0..6).map { dayOffset ->
            val targetEpoch = monday.plusDays(dayOffset.toLong()).toEpochDay()
            sessions.filter { it.dateEpochDay == targetEpoch }.sumOf { it.durationMinutes }
        }

        // Calcula racha diaria real desde sesiones de estudio y hábitos
        val activeDaysSet = sessions.map { it.dateEpochDay }.toMutableSet()
        habits.filter { it.lastCompletedEpochDay >= todayEpoch - 30 }.forEach {
            activeDaysSet.add(it.lastCompletedEpochDay)
        }
        var computedStreak = 0
        var cursor = if (todayEpoch in activeDaysSet) todayEpoch else todayEpoch - 1
        while (cursor in activeDaysSet) {
            computedStreak++
            cursor--
        }
        val effectiveStreak = computedStreak.coerceAtLeast(if (habits.isNotEmpty()) habits.maxOf { it.currentStreak } else 0)
        val effectiveMaxStreak = maxOf(prefs.maxStreakDays, effectiveStreak).coerceAtLeast(1)

        var weekMask = 0
        for (i in 0..6) {
            val epoch = monday.plusDays(i.toLong()).toEpochDay()
            if (epoch in activeDaysSet || weeklyMinutes[i] > 0) {
                weekMask = weekMask or (1 shl i)
            }
        }
        if (weekMask == 0) {
            weekMask = 1 shl (today.dayOfWeek.value - 1)
        }

        val now = System.currentTimeMillis()
        val dueFlashcardsCount = progress.flashcards.count { it.nextReviewAt <= now }

        val updatedExams = progress.exams.map { exam ->
            val examSubject = allSubjects.find { it.id == exam.subjectId }
            if (examSubject == null) exam else {
                val subjReport = PreparationCalculator.computeForSubject(
                    subject = examSubject,
                    courses = core.courses,
                    units = core.units,
                    topics = core.topics,
                    lessons = core.lessons,
                    quizzes = progress.quizzes,
                    flashcards = progress.flashcards,
                    sessions = sessions
                )
                val liveReadiness = if (exam.lastSimulacroScore != null) {
                    ((subjReport.overallPercent * 0.55f) + (exam.lastSimulacroScore * 0.45f)).toInt()
                } else {
                    maxOf(subjReport.overallPercent, exam.readinessPercent)
                }.coerceIn(0, 100)
                exam.copy(readinessPercent = liveReadiness)
            }
        }

        val recommendations = RecommendationUseCase.buildRecommendations(
            subject = activeSubject,
            segments = segments,
            lessons = core.lessons,
            flashcards = progress.flashcards,
            quizzes = progress.quizzes,
            exams = updatedExams
        )

        AcademyUiState(
            subjects = pagerSubjects,
            activeSubjectIndex = activeIndex,
            activeSubject = activeSubject,
            segments = segments,
            selectedSegmentIndex = segIdx,
            preparationReport = prepReport,
            readinessPercent = prepReport?.overallPercent ?: 0,
            streakDays = effectiveStreak.coerceAtLeast(1),
            maxStreakDays = effectiveMaxStreak,
            weeklyActiveDaysMask = weekMask,
            weeklyMinutesByDay = weeklyMinutes,
            weeklyTotalMinutes = weeklyMinutes.sum(),
            pointsBalance = prefs.pointsBalance,
            userName = prefs.userName,
            avatarKey = prefs.avatarKey,
            activeAccentTitle = prefs.activeAccentTitle,
            unlockedRewardIds = prefs.unlockedRewardIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
            rewardCatalog = defaultRewardCatalog(),
            rewardHistory = progress.rewardEvents,
            exams = updatedExams,
            notebooks = progress.notes,
            courses = core.courses,
            units = core.units,
            topics = core.topics,
            lessons = core.lessons,
            flashcards = progress.flashcards,
            quizzes = progress.quizzes,
            dueFlashcardsCount = dueFlashcardsCount,
            recommendations = recommendations,
            areas = distinctAreas,
            selectedArea = filters.area,
            searchQuery = filters.query,
            selectedSubjectId = filters.selectedSubjectId
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AcademyUiState()
    )

    fun selectActiveSubjectIndex(index: Int) {
        val list = uiState.value.subjects
        val target = list.getOrNull(index) ?: return
        _activeSubjectIdOverride.value = target.id
        _selectedSegmentIndex.value = 0
        viewModelScope.launch {
            preferencesRepository.setLastActiveSubjectId(target.id)
        }
    }

    fun selectSegmentIndex(index: Int) {
        val count = uiState.value.segments.size
        if (count == 0) return
        _selectedSegmentIndex.value = index.coerceIn(0, count - 1)
    }

    fun selectArea(area: String) {
        _selectedArea.value = area
    }

    fun updateSearch(query: String) {
        _searchQuery.value = query
    }

    fun selectSubject(subjectId: Long?) {
        _selectedSubjectId.value = subjectId
    }

    fun setTopicMasteryState(topic: TopicEntity, newState: TopicMasteryState) {
        viewModelScope.launch {
            val prevState = TopicMasteryState.fromTopic(topic)
            repository.setTopicMastery(topic, newState.percentValue)
            if (newState.percentValue > prevState.percentValue) {
                val reward = when (newState) {
                    TopicMasteryState.LEARNING -> 5
                    TopicMasteryState.PRACTICED -> 10
                    TopicMasteryState.MASTERED -> 20
                    TopicMasteryState.NOT_STARTED -> 0
                }
                if (reward > 0) {
                    preferencesRepository.addPoints(reward)
                    repository.insertRewardEvent(
                        title = "Tema ${newState.label.lowercase()}: ${topic.title}",
                        pointsDelta = reward,
                        category = "Preparación"
                    )
                }
            }
        }
    }

    fun toggleTopic(topic: TopicEntity) {
        val next = if (topic.isCompleted) TopicMasteryState.NOT_STARTED else TopicMasteryState.MASTERED
        setTopicMasteryState(topic, next)
    }

    fun logQuickStudySession(subjectName: String, minutes: Int, notes: String = "Bloque activo en Academia") {
        viewModelScope.launch {
            repository.logStudySession(subjectName, minutes, notes)
            val points = (minutes / 10).coerceIn(5, 30)
            preferencesRepository.addPoints(points)
            repository.insertRewardEvent(
                title = "Sesión de estudio ($minutes min · $subjectName)",
                pointsDelta = points,
                category = "Constancia"
            )
            preferencesRepository.updateMaxStreak(uiState.value.streakDays + 1)
        }
    }

    fun saveSubject(
        editingId: Long,
        name: String,
        area: String,
        description: String,
        mastery: Int,
        colorHex: String
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.saveSubject(
                SubjectEntity(
                    id = editingId,
                    name = name.trim(),
                    area = area.trim().ifBlank { "Personalizada" },
                    description = description.trim(),
                    iconKey = "menu_book",
                    colorHex = colorHex,
                    masteryLevel = mastery.coerceIn(0, 100)
                )
            )
        }
    }

    fun toggleFavorite(subject: SubjectEntity) {
        viewModelScope.launch { repository.toggleSubjectFavorite(subject) }
    }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch {
            if (_selectedSubjectId.value == subject.id) _selectedSubjectId.value = null
            repository.deleteSubject(subject)
        }
    }

    fun createCourse(subjectId: Long, title: String, description: String, level: String, hours: Int) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val cover = when (level) {
                "Avanzado" -> "humanities"
                "Inicial" -> "science"
                else -> "math"
            }
            repository.saveCourse(
                CourseEntity(
                    subjectId = subjectId,
                    title = title.trim(),
                    description = description.trim().ifBlank { "Programa estructurado de estudio." },
                    level = level,
                    coverKey = cover,
                    estimatedHours = hours.coerceIn(1, 200)
                )
            )
        }
    }

    fun addUnit(courseId: Long, title: String, summary: String) {
        if (title.isBlank()) return
        viewModelScope.launch { repository.addUnit(courseId, title.trim(), summary.trim()) }
    }

    fun addTopic(unitId: Long, title: String, objective: String) {
        if (title.isBlank()) return
        viewModelScope.launch { repository.addTopic(unitId, title.trim(), objective.trim()) }
    }

    fun addTopicToActiveSubjectSegment(segment: GaugeSegmentModel, title: String, objective: String) {
        val activeSubject = uiState.value.activeSubject ?: return
        if (title.isBlank()) return
        viewModelScope.launch {
            if (segment.unitId > 0L) {
                repository.addTopic(segment.unitId, title.trim(), objective.trim())
            } else {
                val existingCourse = uiState.value.courses.firstOrNull { it.subjectId == activeSubject.id }
                if (existingCourse != null) {
                    repository.addUnit(existingCourse.id, segment.title, segment.summary)
                }
            }
        }
    }

    fun deleteTopic(topic: TopicEntity) {
        viewModelScope.launch { repository.deleteTopic(topic) }
    }

    fun createExam(
        subject: SubjectEntity,
        title: String,
        daysUntilExam: Int,
        syllabusTopicsCsv: String,
        objectives: String,
        initialLevel: String,
        targetPercent: Int,
        linkedNotebookIds: Set<Long>
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val examEpoch = LocalDate.now().toEpochDay() + daysUntilExam.coerceIn(1, 365)
            repository.saveExam(
                ExamEntity(
                    subjectId = subject.id,
                    subjectName = subject.name,
                    title = title.trim(),
                    examDateEpochDay = examEpoch,
                    syllabusTopicsCsv = syllabusTopicsCsv.trim(),
                    objectives = objectives.trim(),
                    initialLevel = initialLevel,
                    linkedNotebookIdsCsv = linkedNotebookIds.joinToString(","),
                    targetPercent = targetPercent.coerceIn(50, 100),
                    readinessPercent = uiState.value.readinessPercent
                )
            )
            preferencesRepository.addPoints(15)
            repository.insertRewardEvent(
                title = "Examen planificado: ${title.trim()}",
                pointsDelta = 15,
                category = "Exámenes"
            )
        }
    }

    fun deleteExam(exam: ExamEntity) {
        viewModelScope.launch { repository.deleteExam(exam) }
    }

    fun recordExamSimulacro(exam: ExamEntity, scorePercent: Int) {
        viewModelScope.launch {
            repository.recordExamSimulacro(exam, scorePercent)
            val bonus = if (scorePercent >= exam.targetPercent) 25 else 15
            preferencesRepository.addPoints(bonus)
            repository.insertRewardEvent(
                title = "Simulacro ${exam.title} ($scorePercent%)",
                pointsDelta = bonus,
                category = "Simulacros"
            )
        }
    }

    fun toggleNotebookLinkForExam(exam: ExamEntity, noteId: Long) {
        viewModelScope.launch { repository.toggleNotebookLinkForExam(exam, noteId) }
    }

    fun createQuickNotebook(title: String, subjectName: String, content: String = "") {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.saveNote(
                NoteEntity(
                    title = title.trim(),
                    content = content.trim().ifBlank { "Cuaderno de estudio para $subjectName. Añade síntesis, fórmulas y dudas clave." },
                    folder = "Cuadernos",
                    tagsCsv = "${subjectName.lowercase()},cuaderno",
                    category = "Cuaderno",
                    subjectName = subjectName
                )
            )
        }
    }

    fun redeemReward(item: RewardCatalogItem) {
        viewModelScope.launch {
            val ok = preferencesRepository.redeemReward(item.id, item.title, item.cost)
            if (ok) {
                repository.insertRewardEvent(
                    title = "Recompensa canjeada: ${item.title}",
                    pointsDelta = -item.cost,
                    category = item.category
                )
            }
        }
    }

    fun selectAvatar(avatarKey: String) {
        viewModelScope.launch { preferencesRepository.setAvatarKey(avatarKey) }
    }

    fun updateUserName(name: String) {
        viewModelScope.launch { preferencesRepository.setUserName(name) }
    }
}

private data class AcademyCoreBundle(
    val subjects: List<SubjectEntity>,
    val courses: List<CourseEntity>,
    val units: List<UnitEntity>,
    val topics: List<TopicEntity>,
    val lessons: List<LessonEntity>
)

private data class ProgressBundle(
    val exams: List<ExamEntity>,
    val rewardEvents: List<RewardEventEntity>,
    val notes: List<NoteEntity>,
    val flashcards: List<FlashcardEntity>,
    val quizzes: List<QuizEntity>
)

private data class FilterParams(
    val area: String,
    val query: String,
    val selectedSubjectId: Long?,
    val segmentIndex: Int,
    val activeSubjectIdOverride: Long?
)
