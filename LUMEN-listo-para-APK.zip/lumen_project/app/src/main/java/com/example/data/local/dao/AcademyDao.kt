package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.UnitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AcademyDao {
    @Query("SELECT * FROM subjects ORDER BY isFavorite DESC, name ASC")
    fun observeSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects")
    suspend fun getAllSubjectsOnce(): List<SubjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Update
    suspend fun updateSubject(subject: SubjectEntity)

    @Delete
    suspend fun deleteSubject(subject: SubjectEntity)

    @Query("SELECT * FROM courses ORDER BY createdAt DESC")
    fun observeCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses")
    suspend fun getAllCoursesOnce(): List<CourseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity): Long

    @Update
    suspend fun updateCourse(course: CourseEntity)

    @Delete
    suspend fun deleteCourse(course: CourseEntity)

    @Query("SELECT * FROM units ORDER BY orderIndex ASC")
    fun observeUnits(): Flow<List<UnitEntity>>

    @Query("SELECT * FROM units")
    suspend fun getAllUnitsOnce(): List<UnitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUnit(unit: UnitEntity): Long

    @Delete
    suspend fun deleteUnit(unit: UnitEntity)

    @Query("SELECT * FROM topics ORDER BY orderIndex ASC")
    fun observeTopics(): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics")
    suspend fun getAllTopicsOnce(): List<TopicEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: TopicEntity): Long

    @Update
    suspend fun updateTopic(topic: TopicEntity)

    @Delete
    suspend fun deleteTopic(topic: TopicEntity)

    @Query("SELECT * FROM lessons ORDER BY id ASC")
    fun observeLessons(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE id = :lessonId LIMIT 1")
    fun observeLessonById(lessonId: Long): Flow<LessonEntity?>

    @Query("SELECT * FROM lessons")
    suspend fun getAllLessonsOnce(): List<LessonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: LessonEntity): Long

    @Update
    suspend fun updateLesson(lesson: LessonEntity)

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun countSubjects(): Int

    @Query("SELECT * FROM exams ORDER BY examDateEpochDay ASC")
    fun observeExams(): Flow<List<ExamEntity>>

    @Query("SELECT COUNT(*) FROM exams")
    suspend fun countExams(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamEntity): Long

    @Update
    suspend fun updateExam(exam: ExamEntity)

    @Delete
    suspend fun deleteExam(exam: ExamEntity)

    @Query("SELECT * FROM reward_events ORDER BY createdAt DESC LIMIT 40")
    fun observeRewardEvents(): Flow<List<RewardEventEntity>>

    @Query("SELECT COUNT(*) FROM reward_events")
    suspend fun countRewardEvents(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRewardEvent(event: RewardEventEntity): Long
}
