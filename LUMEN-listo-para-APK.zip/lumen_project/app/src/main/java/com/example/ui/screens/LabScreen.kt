package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiConnectionMode
import com.example.data.ai.LabToolType
import com.example.ui.components.LumenAiStatusBanner
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenElectricButton
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.LabUiState
import com.example.ui.viewmodel.LabViewModel

@Composable
fun LabScreen(
    state: LabUiState,
    viewModel: LabViewModel,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var topicInput by remember { mutableStateOf("") }
    var observationsInput by remember { mutableStateOf("") }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("lab_screen_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                LumenAiStatusBanner(
                    message = state.aiNotice,
                    isConnected = state.connectionMode == AiConnectionMode.FIREBASE_CONNECTED
                )
            }

            item {
                LumenSectionHeader(
                    title = "Laboratorio de conocimiento",
                    subtitle = "10 instrumentos cognitivos impulsados por Gemini"
                )
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(LabToolType.entries) { tool ->
                        FilterChip(
                            selected = state.selectedTool == tool,
                            onClick = { viewModel.selectTool(tool) },
                            label = { Text(tool.title) }
                        )
                    }
                }
            }

            item {
                LumenGlassPanel(glowColor = lumenColors.violet) {
                    LumenMonospaceTag(text = "MÓDULO ACTIVO", accentColor = lumenColors.violet)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(state.selectedTool.title, style = MaterialTheme.typography.titleLarge)
                    Text(
                        state.selectedTool.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        label = { Text("Tema, texto o apuntes de entrada *") },
                        minLines = 2,
                        maxLines = 5,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("lab_topic_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = observationsInput,
                        onValueChange = { observationsInput = it },
                        label = { Text("Observaciones personales / hipótesis (opcional)") },
                        maxLines = 3,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            LumenElectricButton(
                                text = if (state.isGenerating) "Generando..." else "Experimentar",
                                icon = Icons.Rounded.AutoAwesome,
                                enabled = topicInput.isNotBlank() && !state.isGenerating,
                                onClick = { viewModel.generate(topicInput, observationsInput) },
                                modifier = Modifier.testTag("lab_generate_button")
                            )
                        }
                        if (state.isGenerating) {
                            OutlinedButton(onClick = { viewModel.cancelGeneration() }) {
                                Icon(Icons.Rounded.Stop, contentDescription = "Cancelar")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Detener")
                            }
                        }
                    }

                    state.errorMessage?.let { err ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(err, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        if (state.lastFailedInput != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(onClick = { viewModel.retryLastFailed() }) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reintentar con Gemini")
                            }
                        }
                    }

                    state.savedBannerMessage?.let { msg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(msg, style = MaterialTheme.typography.labelMedium, color = lumenColors.success)
                    }
                }
            }

            if (state.isGenerating || state.streamingOutput.isNotBlank()) {
                item {
                    LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (state.isGenerating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = lumenColors.electricBlueBright
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(
                                text = "RESULTADO EN TIEMPO REAL",
                                style = MaterialTheme.typography.labelMedium,
                                color = lumenColors.electricBlueBright
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(state.streamingOutput, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            item {
                LumenSectionHeader(
                    title = "Cuaderno de experimentos",
                    subtitle = "${state.entries.size} registro(s) guardados"
                )
            }

            items(state.entries, key = { it.id }) { entry ->
                LumenSurfaceCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LumenBadge(
                            text = entry.toolName,
                            containerColor = lumenColors.violetContainer,
                            contentColor = lumenColors.violet
                        )
                        IconButton(onClick = { viewModel.deleteEntry(entry) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Eliminar experimento", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    Text(entry.inputTopic, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = entry.generatedOutput,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (entry.observations.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "OBSERVACIÓN: ${entry.observations}",
                            style = MaterialTheme.typography.labelSmall,
                            color = lumenColors.electricBlueBright
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    if (entry.savedToLibrary) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = lumenColors.success, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Guardado en Biblioteca", style = MaterialTheme.typography.labelMedium, color = lumenColors.success)
                        }
                    } else {
                        OutlinedButton(onClick = { viewModel.saveEntryToLibrary(entry) }) {
                            Icon(Icons.Rounded.BookmarkAdd, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Guardar en Biblioteca")
                        }
                    }
                }
            }
        }
    }
}
