package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiConnectionMode
import com.example.data.ai.AiRepository
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import com.example.worker.ReminderScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val preferences: UserPreferences = UserPreferences(),
    val aiConnectionMode: AiConnectionMode = AiConnectionMode.FIREBASE_CONNECTED,
    val aiModelId: String = "gemini-3.8-flash",
    val aiStatusDescription: String = "",
    val feedbackMessage: String? = null
)

class SettingsViewModel(
    private val repository: LumenRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val aiRepository: AiRepository
) : ViewModel() {

    private val _feedback = MutableStateFlow<String?>(null)
    private val _refreshTick = MutableStateFlow(0)

    val uiState: StateFlow<SettingsUiState> = combine(
        preferencesRepository.preferences,
        _feedback,
        _refreshTick
    ) { prefs, feedback, _ ->
        SettingsUiState(
            preferences = prefs,
            aiConnectionMode = aiRepository.currentConnectionMode(),
            aiModelId = aiRepository.modelId,
            aiStatusDescription = aiRepository.currentStatusDescription(),
            feedbackMessage = feedback
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState(
            aiConnectionMode = aiRepository.currentConnectionMode(),
            aiModelId = aiRepository.modelId,
            aiStatusDescription = aiRepository.currentStatusDescription()
        )
    )

    fun refreshAiStatus() {
        _refreshTick.value++
    }

    fun setUserName(name: String) {
        viewModelScope.launch { preferencesRepository.setUserName(name) }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setDarkTheme(enabled) }
    }

    fun setDailyGoal(minutes: Int) {
        viewModelScope.launch { preferencesRepository.setDailyStudyGoal(minutes) }
    }

    fun setPreferredLevel(level: String) {
        viewModelScope.launch { preferencesRepository.setPreferredLevel(level) }
    }

    fun setSpacedRepetitionGoal(count: Int) {
        viewModelScope.launch { preferencesRepository.setSpacedRepetitionGoal(count) }
    }

    fun toggleReminders(context: Context, enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            preferencesRepository.setRemindersEnabled(enabled)
            if (enabled) {
                ReminderScheduler.scheduleDailyReminder(context, hour, minute)
                _feedback.value = "Recordatorio diario programado a las %02d:%02d.".format(hour, minute)
            } else {
                ReminderScheduler.cancelDailyReminder(context)
                _feedback.value = "Recordatorios desactivados."
            }
        }
    }

    fun updateReminderTime(context: Context, hour: Int, minute: Int) {
        viewModelScope.launch {
            preferencesRepository.setReminderTime(hour, minute)
            if (uiState.value.preferences.remindersEnabled) {
                ReminderScheduler.scheduleDailyReminder(context, hour, minute)
            }
            _feedback.value = "Hora de recordatorio actualizada: %02d:%02d.".format(hour, minute)
        }
    }

    suspend fun generateExportJson(): String = repository.exportBackupJson()

    fun importBackupJson(rawJson: String) {
        viewModelScope.launch {
            try {
                val count = repository.importBackupJson(rawJson)
                _feedback.value = "Importación completada: $count elementos incorporados."
            } catch (e: Exception) {
                _feedback.value = "Error al importar: ${e.localizedMessage ?: "archivo no válido"}"
            }
        }
    }

    fun postFeedback(message: String) {
        _feedback.value = message
    }

    fun clearFeedback() {
        _feedback.value = null
    }
}
