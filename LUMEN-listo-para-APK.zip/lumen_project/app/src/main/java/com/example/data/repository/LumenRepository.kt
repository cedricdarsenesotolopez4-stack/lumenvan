package com.example.data.repository

import com.example.data.local.LumenDatabase
import com.example.data.local.LumenSeedData
import com.example.data.local.entity.ActivityLogEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.LabEntryEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.PlannerTaskEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.local.entity.UnitEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.roundToInt

class LumenRepository(private val db: LumenDatabase) {

    private val academyDao = db.academyDao()
    private val tutorDao = db.tutorDao()
    private val libraryDao = db.libraryDao()
    private val plannerDao = db.plannerDao()

    // Reactive streams
    val subjects: Flow<List<SubjectEntity>> = academyDao.observeSubjects()
    val courses: Flow<List<CourseEntity>> = academyDao.observeCourses()
    val units: Flow<List<UnitEntity>> = academyDao.observeUnits()
    val topics: Flow<List<TopicEntity>> = academyDao.observeTopics()
    val lessons: Flow<List<LessonEntity>> = academyDao.observeLessons()
    val exams: Flow<List<ExamEntity>> = academyDao.observeExams()
    val rewardEvents: Flow<List<RewardEventEntity>> = academyDao.observeRewardEvents()

    val tutors: Flow<List<TutorEntity>> = tutorDao.observeTutors()
    val conversations: Flow<List<ConversationEntity>> = tutorDao.observeConversations()

    val notes: Flow<List<NoteEntity>> = libraryDao.observeNotes()
    val flashcards: Flow<List<FlashcardEntity>> = libraryDao.observeFlashcards()
    val quizzes: Flow<List<QuizEntity>> = libraryDao.observeQuizzes()
    val labEntries: Flow<List<LabEntryEntity>> = libraryDao.observeLabEntries()

    val tasks: Flow<List<PlannerTaskEntity>> = plannerDao.observeTasks()
    val studySessions: Flow<List<StudySessionEntity>> = plannerDao.observeStudySessions()
    val habits: Flow<List<HabitEntity>> = plannerDao.observeHabits()
    val recentActivity: Flow<List<ActivityLogEntity>> = plannerDao.observeRecentActivity()

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        LumenSeedData.seedIfEmpty(db)
    }

    fun observeLesson(lessonId: Long): Flow<LessonEntity?> = academyDao.observeLessonById(lessonId)
    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>> = tutorDao.observeMessages(conversationId)
    fun observeQuizQuestions(quizId: Long): Flow<List<QuizQuestionEntity>> = libraryDao.observeQuizQuestions(quizId)

    // Academy CRUD
    suspend fun saveSubject(subject: SubjectEntity) {
        if (subject.id == 0L) {
            academyDao.insertSubject(subject)
            logActivity("Nueva materia añadida", "${subject.name} · ${subject.area}", "Academia")
        } else {
            academyDao.updateSubject(subject)
        }
    }

    suspend fun toggleSubjectFavorite(subject: SubjectEntity) {
        academyDao.updateSubject(subject.copy(isFavorite = !subject.isFavorite))
    }

    suspend fun deleteSubject(subject: SubjectEntity) {
        academyDao.deleteSubject(subject)
    }

    suspend fun saveCourse(course: CourseEntity) {
        if (course.id == 0L) {
            val id = academyDao.insertCourse(course)
            val unitId = academyDao.insertUnit(
                UnitEntity(
                    courseId = id,
                    title = "Unidad I · Fundamentos",
                    summary = "Introducción estructurada y primeros ejercicios.",
                    orderIndex = 1
                )
            )
            academyDao.insertLesson(
                LessonEntity(
                    courseId = id,
                    unitId = unitId,
                    title = "Introducción a ${course.title}",
                    subtitle = "Marco conceptual y objetivos de aprendizaje",
                    level = course.level,
                    durationMinutes = 15,
                    explanation = course.description,
                    definitionsRaw = "Concepto base::Idea rectora sobre la que se construye este curso.",
                    examplesRaw = "Aplica este principio redactando un ejemplo propio en tu Biblioteca.",
                    diagramType = "TANGENT",
                    comprehensionQuestion = "¿Cuál es el objetivo principal de esta primera lección?",
                    comprehensionOptionsRaw = "Establecer bases sólidas antes de avanzar|||Memorizar definiciones sin contexto",
                    comprehensionAnswerIndex = 0,
                    practicalActivity = "Formula tres preguntas clave que quieras resolver a lo largo de este curso.",
                    evaluationQuestion = "¿Qué nivel tiene asignado este curso?",
                    evaluationOptionsRaw = "Inicial|||Intermedio|||Avanzado",
                    evaluationAnswerIndex = when (course.level) {
                        "Inicial" -> 0
                        "Avanzado" -> 2
                        else -> 1
                    },
                    currentStage = 0,
                    isCompleted = false,
                    isUnlocked = true
                )
            )
            logActivity("Nuevo curso creado", course.title, "Academia")
        } else {
            academyDao.updateCourse(course)
        }
    }

    suspend fun deleteCourse(course: CourseEntity) = academyDao.deleteCourse(course)

    suspend fun addUnit(courseId: Long, title: String, summary: String) {
        val count = academyDao.getAllUnitsOnce().count { it.courseId == courseId }
        academyDao.insertUnit(UnitEntity(courseId = courseId, title = title, summary = summary, orderIndex = count + 1))
    }

    suspend fun addTopic(unitId: Long, title: String, objective: String) {
        val count = academyDao.getAllTopicsOnce().count { it.unitId == unitId }
        academyDao.insertTopic(TopicEntity(unitId = unitId, title = title, learningObjective = objective, orderIndex = count + 1))
        logActivity("Tema añadido", title, "Academia")
    }

    suspend fun toggleTopicCompleted(topic: TopicEntity) {
        val nextCompleted = !topic.isCompleted
        academyDao.updateTopic(
            topic.copy(
                isCompleted = nextCompleted,
                masteryPercent = if (nextCompleted) 100 else 0
            )
        )
    }

    suspend fun setTopicMastery(topic: TopicEntity, masteryPercent: Int) {
        val bounded = masteryPercent.coerceIn(0, 100)
        academyDao.updateTopic(
            topic.copy(
                masteryPercent = bounded,
                isCompleted = bounded >= 90
            )
        )
        logActivity("Progreso actualizado", "${topic.title} · $bounded%", "Academia")
    }

    suspend fun deleteTopic(topic: TopicEntity) = academyDao.deleteTopic(topic)

    // Exams & Rewards
    suspend fun saveExam(exam: ExamEntity): Long {
        val id = if (exam.id == 0L) {
            academyDao.insertExam(exam).also {
                logActivity("Examen programado", "${exam.title} · ${exam.subjectName}", "Exámenes")
            }
        } else {
            academyDao.updateExam(exam)
            exam.id
        }
        return id
    }

    suspend fun deleteExam(exam: ExamEntity) = academyDao.deleteExam(exam)

    suspend fun recordExamSimulacro(exam: ExamEntity, scorePercent: Int) {
        val bounded = scorePercent.coerceIn(0, 100)
        val blendedReadiness = ((exam.readinessPercent * 0.4f) + (bounded * 0.6f)).roundToInt().coerceIn(0, 100)
        academyDao.updateExam(
            exam.copy(
                lastSimulacroScore = bounded,
                simulacrosCount = exam.simulacrosCount + 1,
                readinessPercent = blendedReadiness
            )
        )
        logActivity("Simulacro completado", "${exam.title} · $bounded%", "Exámenes")
    }

    suspend fun toggleNotebookLinkForExam(exam: ExamEntity, noteId: Long) {
        val current = exam.linkedNotebookIdsCsv.split(",").filter { it.isNotBlank() }.toMutableSet()
        val idStr = noteId.toString()
        if (idStr in current) current.remove(idStr) else current.add(idStr)
        academyDao.updateExam(exam.copy(linkedNotebookIdsCsv = current.joinToString(",")))
    }

    suspend fun insertRewardEvent(title: String, pointsDelta: Int, category: String) {
        academyDao.insertRewardEvent(
            RewardEventEntity(
                title = title,
                pointsDelta = pointsDelta,
                category = category
            )
        )
    }

    // Lesson progress
    suspend fun updateLessonStage(lesson: LessonEntity, newStage: Int, completed: Boolean = false, score: Int = lesson.scorePercent) {
        val updated = lesson.copy(
            currentStage = newStage.coerceIn(0, 4),
            isCompleted = completed || lesson.isCompleted,
            scorePercent = max(lesson.scorePercent, score),
            updatedAt = System.currentTimeMillis()
        )
        academyDao.updateLesson(updated)
        if (completed) {
            logActivity("Lección completada", "${lesson.title} (${updated.scorePercent}%)", "Lecciones")
        }
    }

    // Tutors & Conversations
    suspend fun saveTutor(tutor: TutorEntity): Long {
        val id = tutorDao.insertTutor(tutor)
        logActivity("Tutor creado", "${tutor.name} · ${tutor.specialty}", "Tutores")
        return id
    }

    suspend fun deleteTutor(tutor: TutorEntity) {
        if (tutor.isCustom) {
            tutorDao.deleteTutor(tutor)
        }
    }

    suspend fun createConversation(tutorId: Long, title: String, level: String): Long {
        val id = tutorDao.insertConversation(
            ConversationEntity(
                tutorId = tutorId,
                title = title,
                studentLevel = level,
                lastMessagePreview = "Sesión iniciada"
            )
        )
        logActivity("Conversación iniciada", title, "Conversaciones")
        return id
    }

    suspend fun renameConversation(conversation: ConversationEntity, newTitle: String) {
        tutorDao.updateConversation(conversation.copy(title = newTitle.trim(), updatedAt = System.currentTimeMillis()))
    }

    suspend fun changeConversationTutor(conversation: ConversationEntity, newTutorId: Long) {
        tutorDao.updateConversation(conversation.copy(tutorId = newTutorId, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteConversation(conversation: ConversationEntity) {
        tutorDao.deleteConversation(conversation)
    }

    suspend fun getMessagesOnce(conversationId: Long): List<MessageEntity> =
        tutorDao.getMessagesForConversationOnce(conversationId)

    suspend fun insertMessage(message: MessageEntity): Long {
        val id = tutorDao.insertMessage(message)
        tutorDao.getConversationById(message.conversationId)?.let { conv ->
            tutorDao.updateConversation(
                conv.copy(
                    lastMessagePreview = message.content.replace("\n", " ").take(90),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        return id
    }

    suspend fun deleteMessage(message: MessageEntity) {
        tutorDao.deleteMessage(message)
    }

    // Library: Notes, Flashcards, Quizzes
    suspend fun saveNote(note: NoteEntity) {
        val updated = note.copy(updatedAt = System.currentTimeMillis())
        if (note.id == 0L) {
            libraryDao.insertNote(updated)
            logActivity("Nuevo material en Biblioteca", "${note.category}: ${note.title}", "Biblioteca")
        } else {
            libraryDao.updateNote(updated)
        }
    }

    suspend fun toggleNoteFavorite(note: NoteEntity) {
        libraryDao.updateNote(note.copy(isFavorite = !note.isFavorite))
    }

    suspend fun deleteNote(note: NoteEntity) = libraryDao.deleteNote(note)

    suspend fun saveFlashcard(card: FlashcardEntity) {
        if (card.id == 0L) {
            libraryDao.insertFlashcard(card)
            logActivity("Flashcard creada", card.front.take(60), "Biblioteca")
        } else {
            libraryDao.updateFlashcard(card)
        }
    }

    suspend fun deleteFlashcard(card: FlashcardEntity) = libraryDao.deleteFlashcard(card)

    /**
     * Repetición espaciada tipo SM-2 simplificada:
     * quality: 1 = Difícil (reinicia), 3 = Bien, 4 = Dominada, 5 = Perfecta
     */
    suspend fun reviewFlashcard(card: FlashcardEntity, quality: Int) {
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L
        val q = quality.coerceIn(0, 5)

        val newReps: Int
        val newInterval: Int
        if (q < 3) {
            newReps = 0
            newInterval = 1
        } else {
            newReps = card.repetitions + 1
            newInterval = when (newReps) {
                1 -> 1
                2 -> 3
                else -> (card.intervalDays * card.easeFactor).roundToInt().coerceAtLeast(4)
            }
        }
        val newEase = (card.easeFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)))
            .coerceAtLeast(1.3)
        val newMastery = when {
            q < 3 -> max(0, card.masteryLevel - 1)
            q == 3 -> (card.masteryLevel + 1).coerceAtMost(4)
            else -> (card.masteryLevel + 1).coerceAtMost(5)
        }

        libraryDao.updateFlashcard(
            card.copy(
                repetitions = newReps,
                intervalDays = newInterval,
                easeFactor = newEase,
                masteryLevel = newMastery,
                lastReviewedAt = now,
                nextReviewAt = now + newInterval * dayMs
            )
        )
        logActivity("Repaso de flashcard", "${card.subjectName} · Próximo repaso en $newInterval d", "Biblioteca")
    }

    suspend fun createQuiz(title: String, subject: String, description: String, questions: List<QuizQuestionEntity>) {
        val quizId = libraryDao.insertQuiz(QuizEntity(title = title, subjectName = subject, description = description))
        questions.forEach { q ->
            libraryDao.insertQuizQuestion(q.copy(quizId = quizId))
        }
        logActivity("Cuestionario creado", title, "Biblioteca")
    }

    suspend fun recordQuizAttempt(quiz: QuizEntity, scorePercent: Int) {
        libraryDao.updateQuiz(
            quiz.copy(
                bestScorePercent = max(quiz.bestScorePercent, scorePercent),
                attemptsCount = quiz.attemptsCount + 1
            )
        )
        logActivity("Cuestionario completado", "${quiz.title} · $scorePercent%", "Biblioteca")
    }

    suspend fun deleteQuiz(quiz: QuizEntity) = libraryDao.deleteQuiz(quiz)

    // Lab entries
    suspend fun saveLabEntry(entry: LabEntryEntity): Long {
        val id = libraryDao.insertLabEntry(entry)
        logActivity("Experimento en Laboratorio", "${entry.toolName}: ${entry.inputTopic.take(40)}", "Laboratorio")
        return id
    }

    suspend fun saveLabResultToLibrary(entry: LabEntryEntity) {
        libraryDao.insertNote(
            NoteEntity(
                title = "${entry.toolName}: ${entry.inputTopic.take(45)}",
                content = buildString {
                    appendLine(entry.generatedOutput)
                    if (entry.observations.isNotBlank()) {
                        appendLine()
                        appendLine("Observaciones personales:")
                        appendLine(entry.observations)
                    }
                },
                folder = "Laboratorio",
                tagsCsv = "laboratorio,síntesis",
                category = "Documento",
                referenceSource = "Generado en Laboratorio LUMEN",
                subjectName = "General"
            )
        )
        libraryDao.updateLabEntry(entry.copy(savedToLibrary = true))
        logActivity("Resultado guardado en Biblioteca", entry.inputTopic.take(50), "Laboratorio")
    }

    suspend fun updateLabObservations(entry: LabEntryEntity, observations: String) {
        libraryDao.updateLabEntry(entry.copy(observations = observations))
    }

    suspend fun deleteLabEntry(entry: LabEntryEntity) = libraryDao.deleteLabEntry(entry)

    // Planner
    suspend fun saveTask(task: PlannerTaskEntity) {
        if (task.id == 0L) {
            plannerDao.insertTask(task)
            logActivity("Tarea planificada", "${task.title} · ${task.priority}", "Planificador")
        } else {
            plannerDao.updateTask(task)
        }
    }

    suspend fun toggleTaskCompleted(task: PlannerTaskEntity) {
        val next = !task.isCompleted
        plannerDao.updateTask(task.copy(isCompleted = next))
        if (next) {
            logActivity("Tarea completada", task.title, "Planificador")
        }
    }

    suspend fun deleteTask(task: PlannerTaskEntity) = plannerDao.deleteTask(task)

    suspend fun logStudySession(subjectName: String, minutes: Int, notes: String) {
        val todayEpoch = LocalDate.now().toEpochDay()
        plannerDao.insertStudySession(
            StudySessionEntity(
                subjectName = subjectName,
                durationMinutes = minutes.coerceAtLeast(1),
                focusNotes = notes,
                dateEpochDay = todayEpoch
            )
        )
        logActivity("Sesión de estudio registrada", "$subjectName · $minutes min", "Planificador")
    }

    suspend fun addHabit(title: String, targetPerWeek: Int) {
        plannerDao.insertHabit(HabitEntity(title = title, targetPerWeek = targetPerWeek.coerceIn(1, 7)))
        logActivity("Hábito académico creado", title, "Planificador")
    }

    suspend fun toggleHabitToday(habit: HabitEntity) {
        val today = LocalDate.now()
        val todayEpoch = today.toEpochDay()
        val dayBit = 1 shl (today.dayOfWeek.value - 1)
        val alreadyDoneToday = habit.lastCompletedEpochDay == todayEpoch
        val updated = if (alreadyDoneToday) {
            habit.copy(
                currentStreak = max(0, habit.currentStreak - 1),
                lastCompletedEpochDay = todayEpoch - 1,
                completedDaysMask = habit.completedDaysMask and dayBit.inv()
            )
        } else {
            val continuesStreak = habit.lastCompletedEpochDay == todayEpoch - 1
            habit.copy(
                currentStreak = if (continuesStreak) habit.currentStreak + 1 else max(1, habit.currentStreak + 1),
                lastCompletedEpochDay = todayEpoch,
                completedDaysMask = habit.completedDaysMask or dayBit
            )
        }
        plannerDao.updateHabit(updated)
    }

    suspend fun deleteHabit(habit: HabitEntity) = plannerDao.deleteHabit(habit)

    private suspend fun logActivity(title: String, subtitle: String, section: String) {
        plannerDao.insertActivityLog(
            ActivityLogEntity(title = title, subtitle = subtitle, section = section)
        )
    }

    // Export / Import
    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val payload = LumenBackupPayload(
            subjects = academyDao.getAllSubjectsOnce(),
            notes = libraryDao.getAllNotesOnce(),
            flashcards = libraryDao.getAllFlashcardsOnce(),
            tasks = plannerDao.getAllTasksOnce(),
            habits = plannerDao.getAllHabitsOnce()
        )
        BackupSerializer.toJsonString(payload)
    }

    suspend fun importBackupJson(rawJson: String): Int = withContext(Dispatchers.IO) {
        val payload = BackupSerializer.fromJsonString(rawJson)
        var importedCount = 0

        val existingSubjects = academyDao.getAllSubjectsOnce().map { it.name.lowercase() }.toSet()
        payload.subjects.forEach { s ->
            if (s.name.lowercase() !in existingSubjects) {
                academyDao.insertSubject(s)
                importedCount++
            }
        }
        payload.notes.forEach { n ->
            libraryDao.insertNote(n)
            importedCount++
        }
        payload.flashcards.forEach { c ->
            libraryDao.insertFlashcard(c)
            importedCount++
        }
        payload.tasks.forEach { t ->
            plannerDao.insertTask(t)
            importedCount++
        }
        payload.habits.forEach { h ->
            plannerDao.insertHabit(h)
            importedCount++
        }
        logActivity("Copia de seguridad importada", "$importedCount elementos incorporados", "Ajustes")
        importedCount
    }
}
