package com.example.ui.components.academy

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.RewardEventEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.domain.GaugeSegmentModel
import com.example.domain.TopicMasteryState
import com.example.ui.components.LumenGlassDialog
import com.example.ui.components.LumenGlassPanel
import com.example.ui.theme.LocalLumenColors
import com.example.ui.theme.LumenMonoFamily
import com.example.ui.viewmodel.RewardCatalogItem

@Composable
fun StreakStatsModal(
    streakDays: Int,
    maxStreakDays: Int,
    weeklyActiveDaysMask: Int,
    subjectName: String,
    onLogSessionNow: () -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    val weekLabels = listOf("L", "M", "X", "J", "V", "S", "D")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.96f))
                .statusBarsPadding()
                .padding(20.dp)
                .testTag("academy_streak_modal")
        ) {
            // Resplandor cálido detrás de la llama
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(c.warning.copy(alpha = 0.24f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 0.34f),
                        radius = size.width * 0.65f
                    ),
                    center = Offset(size.width / 2f, size.height * 0.34f),
                    radius = size.width * 0.65f
                )
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(c.academyGraphite)
                    .testTag("academy_modal_close")
            ) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar racha", tint = c.academyWhite)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .verticalScroll(rememberScrollState())
                    .padding(top = 56.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Racha de $streakDays ${if (streakDays == 1) "día" else "días"}",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = c.academyWhite
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "RÉCORD HISTÓRICO: $maxStreakDays DÍAS",
                    fontFamily = LumenMonoFamily,
                    fontSize = 11.sp,
                    color = c.academyMediumGray
                )

                Spacer(modifier = Modifier.height(22.dp))

                // Ilustración geométrica propia de hoguera LUMEN
                Canvas(modifier = Modifier.size(164.dp)) {
                    val w = size.width
                    val h = size.height
                    // Troncos cruzados
                    rotate(degrees = 11f, pivot = Offset(w * 0.5f, h * 0.82f)) {
                        drawRoundRect(
                            color = Color(0xFF6B4226),
                            topLeft = Offset(w * 0.16f, h * 0.76f),
                            size = Size(w * 0.68f, h * 0.10f),
                            cornerRadius = CornerRadius(24f, 24f)
                        )
                    }
                    rotate(degrees = -11f, pivot = Offset(w * 0.5f, h * 0.82f)) {
                        drawRoundRect(
                            color = Color(0xFF815130),
                            topLeft = Offset(w * 0.16f, h * 0.78f),
                            size = Size(w * 0.68f, h * 0.10f),
                            cornerRadius = CornerRadius(24f, 24f)
                        )
                    }
                    // Llama exterior
                    val outerFlame = Path().apply {
                        moveTo(w * 0.50f, h * 0.06f)
                        cubicTo(w * 0.78f, h * 0.38f, w * 0.78f, h * 0.70f, w * 0.50f, h * 0.76f)
                        cubicTo(w * 0.22f, h * 0.70f, w * 0.22f, h * 0.38f, w * 0.50f, h * 0.06f)
                        close()
                    }
                    drawPath(outerFlame, color = Color(0xFFFF7A1A))

                    // Llama interior
                    val innerFlame = Path().apply {
                        moveTo(w * 0.50f, h * 0.28f)
                        cubicTo(w * 0.66f, h * 0.48f, w * 0.66f, h * 0.70f, w * 0.50f, h * 0.74f)
                        cubicTo(w * 0.34f, h * 0.70f, w * 0.34f, h * 0.48f, w * 0.50f, h * 0.28f)
                        close()
                    }
                    drawPath(innerFlame, color = Color(0xFFFFD83B))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(999.dp))
                        .background(c.academyGraphite)
                        .border(1.dp, c.academyDarkGray, RoundedCornerShape(999.dp))
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Tu constancia está activa — completa un bloque hoy para sumar +15 pts",
                        style = MaterialTheme.typography.titleMedium,
                        color = c.academyWhite,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                Text(
                    text = "ESTA SEMANA",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.4.sp),
                    color = c.academyMediumGray
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    weekLabels.forEachIndexed { idx, day ->
                        val active = (weeklyActiveDaysMask and (1 shl idx)) != 0
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(if (active) Color(0xFFFF7A1A) else c.academyDarkGray)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = day,
                                fontFamily = LumenMonoFamily,
                                fontSize = 11.sp,
                                color = if (active) c.academyWhite else c.academyMediumGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(26.dp))

                Button(
                    onClick = {
                        onLogSessionNow()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text("Registrar sesión de 25 min en $subjectName", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun RewardsModal(
    pointsBalance: Int,
    activeTitle: String,
    catalog: List<RewardCatalogItem>,
    unlockedIds: Set<String>,
    history: List<RewardEventEntity>,
    onRedeem: (RewardCatalogItem) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.96f))
                .statusBarsPadding()
                .padding(18.dp)
                .testTag("academy_rewards_modal")
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("RECOMPENSAS", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                            Text("Logros e insignias", style = MaterialTheme.typography.headlineMedium, color = c.academyWhite)
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(c.academyGraphite)
                                .testTag("academy_modal_close")
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                        }
                    }
                }

                item {
                    LumenGlassPanel(glowColor = c.academyElectricBlue) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("SALDO DE ENERGÍA", style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                                Text(
                                    text = "$pointsBalance pts",
                                    fontFamily = LumenMonoFamily,
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = c.academyWhite
                                )
                                Text("Título activo: $activeTitle", style = MaterialTheme.typography.bodySmall, color = c.academyLuminousBlue)
                            }
                            Icon(Icons.Rounded.Bolt, contentDescription = null, tint = c.academyLuminousBlue, modifier = Modifier.size(34.dp))
                        }
                    }
                }

                item {
                    Text("Canje local por esfuerzo académico (sin compras)", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                }

                items(catalog, key = { it.id }) { item ->
                    val unlocked = item.id in unlockedIds
                    val affordable = pointsBalance >= item.cost
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(c.academyGraphite)
                            .border(1.dp, if (unlocked) c.academyElectricBlue else c.academyDarkGray, RoundedCornerShape(18.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${item.category.uppercase()} · ${item.cost} pts", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                            Text(item.title, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                            Text(item.description, style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = { onRedeem(item) },
                            enabled = !unlocked && affordable,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (unlocked) c.success else c.academyElectricBlue,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(if (unlocked) "Activo" else "Canjear")
                        }
                    }
                }

                if (history.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Historial reciente", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                    }
                    items(history.take(10), key = { it.id }) { ev ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(c.academyBlackSecondary)
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ev.title, style = MaterialTheme.typography.bodyMedium, color = c.academyWhite)
                                Text(ev.category, style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                            }
                            Text(
                                text = if (ev.pointsDelta >= 0) "+${ev.pointsDelta} pts" else "${ev.pointsDelta} pts",
                                fontFamily = LumenMonoFamily,
                                fontWeight = FontWeight.Bold,
                                color = if (ev.pointsDelta >= 0) c.success else c.academyLuminousBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileModal(
    userName: String,
    avatarKey: String,
    activeTitle: String,
    pointsBalance: Int,
    streakDays: Int,
    subjects: List<SubjectEntity>,
    onSelectAvatar: (String) -> Unit,
    onUpdateName: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    var nameInput by remember(userName) { mutableStateOf(userName) }
    val avatars = listOf("cosmos" to "Cosmos", "prism" to "Prisma", "atom" to "Átomo", "quill" to "Pluma", "compass" to "Brújula")

    Dialog(onDismissRequest = onDismiss) {
        LumenGlassPanel(glowColor = c.academyViolet) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Perfil de estudio", style = MaterialTheme.typography.titleLarge, color = c.academyWhite)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AcademyAvatarOrb(avatarKey = avatarKey, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(userName, style = MaterialTheme.typography.titleLarge, color = c.academyWhite)
                    Text(activeTitle, style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                    Text("$pointsBalance pts · Racha $streakDays d · ${subjects.size} materias", style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                label = { Text("Nombre local del estudiante") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text("ESTILO DE AVATAR", style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                avatars.forEach { (key, label) ->
                    val selected = key == avatarKey
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (selected) c.academyElectricBlue else c.academyGraphite)
                            .clickable { onSelectAvatar(key) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AcademyAvatarOrb(avatarKey = key, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Cerrar") }
                Button(
                    onClick = {
                        onUpdateName(nameInput)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White)
                ) {
                    Text("Guardar")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ActiveSegmentTopicsSheet(
    subject: SubjectEntity,
    segment: GaugeSegmentModel,
    onSetTopicState: (TopicEntity, TopicMasteryState) -> Unit,
    onAddTopic: (String, String) -> Unit,
    onOpenLesson: (LessonEntity) -> Unit,
    onAskTutor: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    var newTopicTitle by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.96f))
                .statusBarsPadding()
                .padding(18.dp)
                .testTag("academy_segment_topics_sheet")
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${subject.name.uppercase()} · BLOQUE", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                            Text("${segment.title} (${segment.readinessPercent}%)", style = MaterialTheme.typography.headlineMedium, color = c.academyWhite)
                            if (segment.summary.isNotBlank()) {
                                Text(segment.summary, style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                            }
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(c.academyGraphite)
                                .testTag("academy_modal_close")
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                        }
                    }
                }

                item {
                    Button(
                        onClick = { onAskTutor(segment.topics.firstOrNull()?.title ?: segment.title) },
                        colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Practicar ${segment.title} con Tutor Gemini")
                    }
                }

                items(segment.topics, key = { it.id }) { topic ->
                    val currentState = TopicMasteryState.fromTopic(topic)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(c.academyGraphite)
                            .border(1.dp, c.academyDarkGray, RoundedCornerShape(18.dp))
                            .padding(14.dp)
                            .testTag("segment_topic_${topic.id}")
                    ) {
                        Text(topic.title, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                        if (topic.learningObjective.isNotBlank()) {
                            Text(topic.learningObjective, style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            TopicMasteryState.entries.forEach { stateOption ->
                                val selected = currentState == stateOption
                                val chipColor = when {
                                    !selected -> c.academyBlackSecondary
                                    stateOption == TopicMasteryState.MASTERED -> c.success
                                    stateOption == TopicMasteryState.PRACTICED -> c.academyElectricBlue
                                    stateOption == TopicMasteryState.LEARNING -> c.academyViolet
                                    else -> c.academyDarkGray
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(chipColor)
                                        .border(1.dp, if (selected) Color.White.copy(alpha = 0.4f) else c.academyDarkGray, RoundedCornerShape(999.dp))
                                        .clickable { onSetTopicState(topic, stateOption) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = stateOption.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) Color.White else c.academyMediumGray
                                    )
                                }
                            }
                        }
                    }
                }

                if (segment.lessons.isNotEmpty()) {
                    item {
                        Text("Lecciones vinculadas", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                    }
                    items(segment.lessons, key = { it.id }) { lesson ->
                        OutlinedButton(
                            onClick = { onOpenLesson(lesson) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = c.academyLuminousBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(lesson.title, color = c.academyWhite, modifier = Modifier.weight(1f))
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newTopicTitle,
                            onValueChange = { newTopicTitle = it },
                            label = { Text("Añadir nuevo tema a ${segment.title}") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (newTopicTitle.isNotBlank()) {
                                    onAddTopic(newTopicTitle, "Dominar $newTopicTitle")
                                    newTopicTitle = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(c.academyElectricBlue)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Añadir tema", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubjectCatalogSheet(
    subjects: List<SubjectEntity>,
    activeSubjectId: Long?,
    onSelectSubjectIndex: (Int) -> Unit,
    onCreateSubjectClick: () -> Unit,
    onToggleFavorite: (SubjectEntity) -> Unit,
    onDeleteSubject: (SubjectEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    Dialog(onDismissRequest = onDismiss) {
        LumenGlassPanel(glowColor = c.academyElectricBlue) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Todas las materias", style = MaterialTheme.typography.titleLarge, color = c.academyWhite)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                }
            }
            LazyColumn(
                modifier = Modifier.height(340.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(subjects.size, key = { subjects[it].id }) { index ->
                    val sub = subjects[index]
                    val active = sub.id == activeSubjectId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) c.academyElectricBlue.copy(alpha = 0.22f) else c.academyGraphite)
                            .border(1.dp, if (active) c.academyElectricBlue else c.academyDarkGray, RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectSubjectIndex(index)
                                onDismiss()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(sub.name, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                            Text(sub.area, style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                        }
                        IconButton(onClick = { onToggleFavorite(sub) }) {
                            Icon(
                                Icons.Rounded.Star,
                                contentDescription = "Favorita",
                                tint = if (sub.isFavorite) c.warning else c.academyMediumGray
                            )
                        }
                        if (subjects.size > 1) {
                            IconButton(onClick = { onDeleteSubject(sub) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    onDismiss()
                    onCreateSubjectClick()
                },
                colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Crear materia personalizada")
            }
        }
    }
}

@Composable
fun CreateSubjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    val c = LocalLumenColors.current
    var name by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("Personalizada") }
    var description by remember { mutableStateOf("") }

    LumenGlassDialog(
        title = "Nueva materia",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(name, area, description) },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                modifier = Modifier.testTag("save_subject_button")
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nombre de la materia *") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("subject_name_input")
        )
        OutlinedTextField(
            value = area,
            onValueChange = { area = it },
            label = { Text("Área de conocimiento") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Descripción") },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
