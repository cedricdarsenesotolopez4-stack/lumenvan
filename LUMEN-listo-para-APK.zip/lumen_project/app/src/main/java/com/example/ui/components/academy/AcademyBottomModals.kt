package com.example.ui.components.academy

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.UnfoldMore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ai.LabToolType
import com.example.data.local.entity.SubjectEntity
import com.example.domain.AcademyRecommendation
import com.example.domain.RecommendationKind
import com.example.ui.theme.LocalLumenColors

@Composable
fun QuickStartAndHelpModal(
    activeSubject: SubjectEntity?,
    activeAreaName: String,
    recommendations: List<AcademyRecommendation>,
    onOpenExams: () -> Unit,
    onExecuteRecommendation: (AcademyRecommendation) -> Unit,
    onSendToTutorWithContext: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    var selectedMode by remember { mutableStateOf("Conversación") }
    var promptText by remember { mutableStateOf("") }
    val subjectLabel = (activeSubject?.name ?: "Matemáticas").uppercase()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.98f))
                .statusBarsPadding()
                .padding(18.dp)
                .testTag("academy_start_modal")
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(c.academyGraphite)
                                .border(1.dp, c.academyDarkGray, CircleShape)
                                .testTag("academy_modal_close")
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                        }
                    }
                }

                // Tarjeta superior translúcida: PREPARACIÓN PARA EL EXAMEN (inspirada en captura)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(c.academyBlackSecondary)
                            .border(1.dp, c.academyDarkGray.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
                            .clickable {
                                onDismiss()
                                onOpenExams()
                            }
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "PREPARACIÓN PARA EL EXAMEN",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.4.sp),
                            color = c.academyMediumGray
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "¿Se acerca un examen?",
                            style = MaterialTheme.typography.titleLarge,
                            color = c.academyMediumGray
                        )
                        Text(
                            text = "Vamos a hacer un plan.",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = c.academyWhite
                        )
                    }
                }

                // Panel principal oscuro AYUDA RÁPIDA
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(28.dp))
                            .background(c.academyGraphite.copy(alpha = 0.85f))
                            .border(1.dp, c.academyDarkGray, RoundedCornerShape(28.dp))
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AYUDA RÁPIDA",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold),
                                color = c.academyLuminousBlue
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = null, tint = c.academyWhite, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "¿Algo se te complica?",
                            style = MaterialTheme.typography.headlineSmall,
                            color = c.academyMediumGray,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Vamos a resolverlo ahora.",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = c.academyWhite,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Selector de 3 modos con cápsula elevada
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(c.academyBlackSecondary)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(
                                "Lección" to Icons.AutoMirrored.Rounded.MenuBook,
                                "Conversación" to Icons.Rounded.ChatBubbleOutline,
                                "Repaso" to Icons.Rounded.Quiz
                            ).forEach { (mode, icon) ->
                                val active = selectedMode == mode
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (active) c.academyDarkGray else Color.Transparent)
                                        .border(
                                            1.dp,
                                            if (active) c.academyWhite.copy(alpha = 0.25f) else Color.Transparent,
                                            RoundedCornerShape(16.dp)
                                        )
                                        .clickable { selectedMode = mode }
                                        .padding(vertical = 10.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = mode,
                                        tint = if (active) c.academyWhite else c.academyMediumGray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = mode,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (active) c.academyWhite else c.academyMediumGray
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$subjectLabel · ${activeAreaName.uppercase()}",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                                color = c.academyMediumGray
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Rounded.UnfoldMore, contentDescription = null, tint = c.academyMediumGray, modifier = Modifier.size(14.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = promptText,
                            onValueChange = { promptText = it },
                            placeholder = { Text("Pregúntale al tutor") },
                            maxLines = 3,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("academy_quick_tutor_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                val effectivePrompt = promptText.ifBlank {
                                    when (selectedMode) {
                                        "Lección" -> "Explícame paso a paso el bloque $activeAreaName."
                                        "Repaso" -> "Ponme un ejercicio breve y verifica si comprendo $activeAreaName."
                                        else -> "Tengo dudas en $activeAreaName de ${activeSubject?.name ?: "esta materia"}."
                                    }
                                }
                                onDismiss()
                                onSendToTutorWithContext(effectivePrompt)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("academy_quick_tutor_send")
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Iniciar con Tutor Gemini", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Motor real de recomendaciones (COMENZAR)
                if (recommendations.isNotEmpty()) {
                    item {
                        Text(
                            text = "SIGUIENTES PASOS RECOMENDADOS",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.3.sp),
                            color = c.academyMediumGray
                        )
                    }
                    items(recommendations, key = { it.id }) { rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(c.academyBlackSecondary)
                                .border(1.dp, c.academyDarkGray, RoundedCornerShape(18.dp))
                                .clickable {
                                    onDismiss()
                                    onExecuteRecommendation(rec)
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(c.academyElectricBlue.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (rec.kind) {
                                        RecommendationKind.RESUME_LESSON -> Icons.AutoMirrored.Rounded.MenuBook
                                        RecommendationKind.PREPARE_EXAM -> Icons.Rounded.School
                                        RecommendationKind.REVIEW_FLASHCARDS -> Icons.Rounded.Style
                                        RecommendationKind.TAKE_QUIZ -> Icons.Rounded.Quiz
                                        RecommendationKind.ASK_TUTOR -> Icons.Rounded.AutoAwesome
                                        RecommendationKind.PRACTICE_WEAK_AREA -> Icons.Rounded.EditNote
                                    },
                                    contentDescription = null,
                                    tint = c.academyLuminousBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rec.badge, style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                                Text(rec.title, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                                Text(rec.subtitle, style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                            }
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = c.academyMediumGray)
                        }
                    }
                }
            }
        }
    }
}

private data class StudyAppTile(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val accentBlue: Boolean
)

@Composable
fun AppsHubModal(
    subjectName: String,
    dueFlashcardsCount: Int,
    onOpenLabTool: (LabToolType) -> Unit,
    onOpenLibraryTab: () -> Unit,
    onOpenExams: () -> Unit,
    onCreateQuickNotebook: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todas") }
    var showQuickNotebookField by remember { mutableStateOf(false) }
    var quickNoteTitle by remember { mutableStateOf("") }

    val apps = remember(dueFlashcardsCount) {
        listOf(
            StudyAppTile("flashcards", "Flashcards", if (dueFlashcardsCount > 0) "$dueFlashcardsCount pendientes hoy" else "Repetición SM-2", "Estudio", Icons.Rounded.Style, true),
            StudyAppTile("quizzes", "Cuestionarios", "Tests con evaluación", "Evaluación", Icons.Rounded.Quiz, false),
            StudyAppTile("summaries", "Resúmenes IA", "Síntesis clara Gemini", "Práctica IA", Icons.Rounded.Description, true),
            StudyAppTile("maps", "Mapas conceptuales", "Esquemas de nodos", "Práctica IA", Icons.Rounded.AccountTree, false),
            StudyAppTile("exercises", "Generador de ejercicios", "Práctica graduada", "Práctica IA", Icons.Rounded.EditNote, true),
            StudyAppTile("podcasts", "Guiones de estudio", "Explicación narrativa", "Práctica IA", Icons.Rounded.GraphicEq, false),
            StudyAppTile("simulacros", "Simulacros", "Ensayos cronometrados", "Evaluación", Icons.Rounded.School, true),
            StudyAppTile("apuntes", "Apuntes y cuadernos", "Archivo personal", "Estudio", Icons.AutoMirrored.Rounded.MenuBook, false)
        )
    }

    val filtered = apps.filter { app ->
        (selectedCategory == "Todas" || app.category == selectedCategory) &&
            (search.isBlank() || app.title.contains(search, ignoreCase = true) || app.subtitle.contains(search, ignoreCase = true))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.98f))
                .statusBarsPadding()
                .padding(18.dp)
                .testTag("academy_apps_modal")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Apps de aprendizaje", style = MaterialTheme.typography.headlineMedium, color = c.academyWhite)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = { showQuickNotebookField = !showQuickNotebookField },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(c.academyGraphite)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Crear apunte rápido", tint = c.academyWhite)
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(c.academyGraphite)
                            .testTag("academy_modal_close")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Buscar herramienta de estudio...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (showQuickNotebookField) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = quickNoteTitle,
                        onValueChange = { quickNoteTitle = it },
                        placeholder = { Text("Título del nuevo cuaderno de $subjectName") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (quickNoteTitle.isNotBlank()) {
                                onCreateQuickNotebook(quickNoteTitle)
                                quickNoteTitle = ""
                                showQuickNotebookField = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White)
                    ) { Text("Crear") }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Hero Card: Generador Cognitivo
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(c.academyDeepViolet, c.academyBlackSecondary)
                        )
                    )
                    .border(1.dp, c.academyElectricBlue.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Text("GENERADOR COGNITIVO · $subjectName".uppercase(), style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Transforma cualquier tema en resúmenes, mapas o tests reales con Gemini.", style = MaterialTheme.typography.bodyMedium, color = c.academyWhite)
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        onDismiss()
                        onOpenLabTool(LabToolType.CONCEPT_MAP)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Abrir Laboratorio Gemini")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Todas", "Estudio", "Práctica IA", "Evaluación").forEach { cat ->
                    val selected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (selected) c.academyElectricBlue else c.academyGraphite)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(cat, style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filtered, key = { it.id }) { tile ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(c.academyGraphite)
                            .border(1.dp, c.academyDarkGray, RoundedCornerShape(20.dp))
                            .clickable {
                                onDismiss()
                                when (tile.id) {
                                    "flashcards", "quizzes", "apuntes" -> onOpenLibraryTab()
                                    "summaries" -> onOpenLabTool(LabToolType.SUMMARY_GENERATOR)
                                    "maps" -> onOpenLabTool(LabToolType.CONCEPT_MAP)
                                    "exercises" -> onOpenLabTool(LabToolType.EXERCISE_GENERATOR)
                                    "podcasts" -> onOpenLabTool(LabToolType.CONCEPT_EXPLAINER)
                                    "simulacros" -> onOpenExams()
                                }
                            }
                            .padding(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (tile.accentBlue) c.academyElectricBlue.copy(alpha = 0.22f) else c.academyDeepViolet),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = tile.icon,
                                contentDescription = tile.title,
                                tint = if (tile.accentBlue) c.academyLuminousBlue else c.academyWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(tile.title, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                        Text(tile.subtitle, style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                    }
                }
            }
        }
    }
}
