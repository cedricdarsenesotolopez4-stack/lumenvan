package com.example

import android.app.Application
import android.content.Context
import com.example.data.ai.AiRepository
import com.example.data.ai.FirebaseAiRepository
import com.example.data.local.LumenDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import com.example.worker.ReminderScheduler

class AppContainer(context: Context) {
    val database: LumenDatabase = LumenDatabase.getInstance(context)
    val repository: LumenRepository = LumenRepository(database)
    val preferencesRepository: UserPreferencesRepository = UserPreferencesRepository(context)
    val aiRepository: AiRepository = FirebaseAiRepository(context)
}

class LumenApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        ReminderScheduler.ensureChannel(this)
    }
}
