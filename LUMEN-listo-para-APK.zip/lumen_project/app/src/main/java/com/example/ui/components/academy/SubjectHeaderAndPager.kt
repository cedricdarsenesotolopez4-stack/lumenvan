package com.example.ui.components.academy

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SubjectEntity
import com.example.ui.theme.LocalLumenColors

@Composable
fun SubjectHeader(
    subject: SubjectEntity?,
    overallReadinessPercent: Int,
    onOpenSubjectCatalog: () -> Unit,
    onCreateSubject: () -> Unit,
    compact: Boolean = false,
    ultraShort: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val title = subject?.name ?: "Academia"
    val areaText = subject?.area?.uppercase() ?: "PREPARACIÓN"

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = if (ultraShort) 14.dp else 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onOpenSubjectCatalog)
                .padding(horizontal = 12.dp, vertical = if (ultraShort) 0.dp else if (compact) 2.dp else 4.dp)
                .testTag("academy_subject_header")
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = when {
                        ultraShort -> 19.sp
                        compact -> 23.sp
                        else -> 27.sp
                    },
                    lineHeight = when {
                        ultraShort -> 22.sp
                        compact -> 26.sp
                        else -> 32.sp
                    },
                    letterSpacing = (-0.5).sp
                ),
                color = c.academyWhite,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = "Cambiar o gestionar materias",
                tint = c.academyMediumGray,
                modifier = Modifier.size(if (ultraShort) 16.dp else 20.dp)
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$areaText · GLOBAL $overallReadinessPercent%",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = if (ultraShort) 0.8.sp else 1.3.sp,
                    fontSize = if (ultraShort) 9.sp else 10.sp
                ),
                color = c.academyMediumGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(c.academyGraphite)
                    .clickable(onClick = onCreateSubject)
                    .padding(if (ultraShort) 2.dp else 4.dp)
                    .testTag("academy_fab")
                    .semantics { contentDescription = "Añadir nueva materia" },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = "Nueva materia",
                    tint = c.academyWhite,
                    modifier = Modifier.size(if (ultraShort) 11.dp else 13.dp)
                )
            }
        }
    }
}

@Composable
fun SubjectPagerIndicator(
    pageCount: Int,
    activeIndex: Int,
    onSelectPage: (Int) -> Unit,
    ultraShort: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    if (pageCount <= 1) return

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = if (ultraShort) 1.dp else 4.dp)
            .testTag("academy_pager_dots"),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(pageCount) { index ->
            val selected = index == activeIndex
            val width by animateDpAsState(targetValue = if (selected) 18.dp else 6.dp, label = "dotW")
            val color by animateColorAsState(
                targetValue = if (selected) c.academyWhite else c.academyDarkGray,
                label = "dotColor"
            )
            Box(
                modifier = Modifier
                    .height(6.dp)
                    .width(width)
                    .clip(CircleShape)
                    .background(color)
                    .clickable { onSelectPage(index) }
                    .semantics { contentDescription = "Materia ${index + 1}" }
            )
        }
    }
}
