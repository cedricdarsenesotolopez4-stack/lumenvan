package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "planner_tasks")
data class PlannerTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val dueDateEpochDay: Long,
    val dueTimeLabel: String = "18:00",
    val priority: String = "MEDIA", // ALTA, MEDIA, BAJA
    val category: String = "Estudio", // Estudio, Objetivo, Repaso, Proyecto
    val subjectName: String = "General",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val durationMinutes: Int,
    val focusNotes: String = "",
    val dateEpochDay: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetPerWeek: Int = 5,
    val currentStreak: Int = 0,
    val lastCompletedEpochDay: Long = -1L,
    val completedDaysMask: Int = 0 // 7-bit mask for current week
)

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subtitle: String,
    val section: String, // Academia, Lecciones, Tutores, Biblioteca, Laboratorio, Planificador
    val timestamp: Long = System.currentTimeMillis()
)
