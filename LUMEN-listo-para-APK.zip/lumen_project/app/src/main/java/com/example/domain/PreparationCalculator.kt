package com.example.domain

import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.FlashcardEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.TopicEntity
import com.example.data.local.entity.UnitEntity
import kotlin.math.roundToInt

/**
 * Estados explícitos de dominio de cada tema dentro de LUMEN Academia.
 */
enum class TopicMasteryState(
    val label: String,
    val percentValue: Int
) {
    NOT_STARTED("No iniciado", 0),
    LEARNING("Aprendiendo", 30),
    PRACTICED("Practicado", 70),
    MASTERED("Dominado", 100);

    companion object {
        fun fromTopic(topic: TopicEntity): TopicMasteryState = when {
            topic.isCompleted || topic.masteryPercent >= 90 -> MASTERED
            topic.masteryPercent >= 50 -> PRACTICED
            topic.masteryPercent > 0 -> LEARNING
            else -> NOT_STARTED
        }
    }
}

data class GaugeSegmentModel(
    val unitId: Long,
    val title: String,
    val summary: String,
    val readinessPercent: Int,
    val topics: List<TopicEntity>,
    val lessons: List<LessonEntity>,
    val masteredCount: Int,
    val totalCount: Int
)

data class SubjectPreparationReport(
    val overallPercent: Int,
    val segments: List<GaugeSegmentModel>,
    val topicsPercent: Int,
    val lessonsPercent: Int,
    val quizzesPercent: Int,
    val flashcardsPercent: Int,
    val sessionsPercent: Int
)

/**
 * Calcula el Nivel de Preparación (0..100%) de forma determinista y verificable a partir
 * de datos reales persistidos en Room:
 *
 * Fórmula ponderada global por materia:
 * - 45% Dominio promedio de temas (`TopicEntity`: No iniciado 0%, Aprendiendo 1..49%, Practicado 50..89%, Dominado 90..100%).
 * - 25% Lecciones completadas y su avance por etapas (`LessonEntity`).
 * - 15% Mejor puntuación promedio en cuestionarios de la materia (`QuizEntity`).
 * - 10% Dominio de tarjetas espaciadas de la materia (`FlashcardEntity`, escala 0..5 -> 0..100%).
 * - 05% Sesiones de estudio registradas recientemente (hasta 120 min = 100%).
 *
 * Si una materia no tiene actividad registrada todavía, devuelve exactamente 0%.
 */
object PreparationCalculator {

    fun computeForSubject(
        subject: SubjectEntity,
        courses: List<CourseEntity>,
        units: List<UnitEntity>,
        topics: List<TopicEntity>,
        lessons: List<LessonEntity>,
        quizzes: List<QuizEntity>,
        flashcards: List<FlashcardEntity>,
        sessions: List<StudySessionEntity>
    ): SubjectPreparationReport {
        val subjectCourses = courses.filter { it.subjectId == subject.id }
        val courseIds = subjectCourses.map { it.id }.toSet()
        val subjectUnits = units.filter { it.courseId in courseIds }.sortedBy { it.orderIndex }
        val subjectLessons = lessons.filter { it.courseId in courseIds }

        val segments = buildSegments(
            subjectUnits = subjectUnits,
            allTopics = topics,
            subjectLessons = subjectLessons
        )

        val unitIds = subjectUnits.map { it.id }.toSet()
        val subjectTopics = topics.filter { it.unitId in unitIds }

        val topicsScore = if (subjectTopics.isEmpty()) 0f else {
            subjectTopics.map { topicScore(it) }.average().toFloat()
        }

        val lessonsScore = if (subjectLessons.isEmpty()) 0f else {
            subjectLessons.map { lesson ->
                when {
                    lesson.isCompleted && lesson.scorePercent > 0 -> lesson.scorePercent.toFloat()
                    lesson.isCompleted -> 100f
                    lesson.currentStage > 0 -> (lesson.currentStage.coerceIn(0, 4) / 4f) * 75f
                    else -> 0f
                }
            }.average().toFloat()
        }

        val subjectQuizzes = quizzes.filter {
            it.subjectName.equals(subject.name, ignoreCase = true) && it.attemptsCount > 0
        }
        val quizzesScore = if (subjectQuizzes.isEmpty()) 0f else {
            subjectQuizzes.map { it.bestScorePercent.coerceIn(0, 100).toFloat() }.average().toFloat()
        }

        val subjectCards = flashcards.filter {
            it.subjectName.equals(subject.name, ignoreCase = true) && it.repetitions > 0
        }
        val flashcardsScore = if (subjectCards.isEmpty()) 0f else {
            subjectCards.map { (it.masteryLevel.coerceIn(0, 5) / 5f) * 100f }.average().toFloat()
        }

        val subjectMinutes = sessions
            .filter { it.subjectName.equals(subject.name, ignoreCase = true) }
            .sumOf { it.durationMinutes }
        val sessionsScore = ((subjectMinutes / 120f) * 100f).coerceIn(0f, 100f)

        val rawOverall = (topicsScore * 0.45f) +
            (lessonsScore * 0.25f) +
            (quizzesScore * 0.15f) +
            (flashcardsScore * 0.10f) +
            (sessionsScore * 0.05f)

        return SubjectPreparationReport(
            overallPercent = rawOverall.roundToInt().coerceIn(0, 100),
            segments = segments,
            topicsPercent = topicsScore.roundToInt().coerceIn(0, 100),
            lessonsPercent = lessonsScore.roundToInt().coerceIn(0, 100),
            quizzesPercent = quizzesScore.roundToInt().coerceIn(0, 100),
            flashcardsPercent = flashcardsScore.roundToInt().coerceIn(0, 100),
            sessionsPercent = sessionsScore.roundToInt().coerceIn(0, 100)
        )
    }

    private fun buildSegments(
        subjectUnits: List<UnitEntity>,
        allTopics: List<TopicEntity>,
        subjectLessons: List<LessonEntity>
    ): List<GaugeSegmentModel> {
        val baseUnits = subjectUnits.take(5)
        val built = baseUnits.map { unit ->
            val unitTopics = allTopics.filter { it.unitId == unit.id }.sortedBy { it.orderIndex }
            val unitLessons = subjectLessons.filter { it.unitId == unit.id }
            val topicAvg = if (unitTopics.isEmpty()) 0f else unitTopics.map { topicScore(it) }.average().toFloat()
            val lessonAvg = if (unitLessons.isEmpty()) null else {
                unitLessons.map {
                    if (it.isCompleted) it.scorePercent.coerceAtLeast(80).toFloat()
                    else (it.currentStage.coerceIn(0, 4) / 4f) * 75f
                }.average().toFloat()
            }
            val readiness = when {
                unitTopics.isEmpty() && lessonAvg == null -> 0
                lessonAvg != null && unitTopics.isNotEmpty() -> ((topicAvg * 0.75f) + (lessonAvg * 0.25f)).roundToInt()
                lessonAvg != null -> lessonAvg.roundToInt()
                else -> topicAvg.roundToInt()
            }.coerceIn(0, 100)

            GaugeSegmentModel(
                unitId = unit.id,
                title = cleanSegmentTitle(unit.title),
                summary = unit.summary,
                readinessPercent = readiness,
                topics = unitTopics,
                lessons = unitLessons,
                masteredCount = unitTopics.count { TopicMasteryState.fromTopic(it) == TopicMasteryState.MASTERED },
                totalCount = unitTopics.size
            )
        }.toMutableList()

        val fallbackNames = listOf("Fundamentos", "Análisis", "Práctica", "Síntesis", "Dominio")
        while (built.size < 5) {
            val idx = built.size
            built.add(
                GaugeSegmentModel(
                    unitId = -(idx + 1L),
                    title = fallbackNames[idx],
                    summary = "Área modular de estudio",
                    readinessPercent = 0,
                    topics = emptyList(),
                    lessons = emptyList(),
                    masteredCount = 0,
                    totalCount = 0
                )
            )
        }
        return built
    }

    private fun cleanSegmentTitle(rawTitle: String): String {
        val stripped = rawTitle
            .replace(Regex("^Unidad\\s+[IVX0-9]+\\s*[·:-]\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
        return stripped.ifBlank { rawTitle }
    }

    private fun topicScore(topic: TopicEntity): Float {
        return if (topic.isCompleted) {
            maxOf(topic.masteryPercent, 100).coerceIn(0, 100).toFloat()
        } else {
            topic.masteryPercent.coerceIn(0, 100).toFloat()
        }
    }
}
