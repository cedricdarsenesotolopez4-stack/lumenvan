package com.example.data.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.TutorEntity
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

enum class AiConnectionMode {
    FIREBASE_CONNECTED,
    OFFLINE_LOCAL_ONLY
}

enum class LabToolType(val title: String, val subtitle: String) {
    QUIZ_GENERATOR("Generador de cuestionarios", "Preguntas de opción múltiple, V/F y desarrollo"),
    FLASHCARD_GENERATOR("Generador de flashcards", "Tarjetas de memoria listas para repaso espaciado"),
    SUMMARY_GENERATOR("Generador de resúmenes", "Síntesis estructurada con ideas clave"),
    OUTLINE_GENERATOR("Generador de esquemas", "Jerarquía temática ordenada por niveles"),
    CONCEPT_MAP("Mapas conceptuales", "Nodos, relaciones lógicas y jerarquía"),
    EXERCISE_GENERATOR("Generador de ejercicios", "Práctica graduada sin revelar la solución de inmediato"),
    STUDY_PLANNER("Planes de estudio", "Secuencia por sesiones, objetivos y criterios de dominio"),
    NOTE_ANALYZER("Analizador de apuntes", "Detecta lagunas, conceptos clave y mejoras"),
    CONCEPT_EXPLAINER("Explicador de conceptos", "Explicación intuitiva, formal y ejemplo aplicado"),
    PROJECT_IDEAS("Ideas de proyectos", "Experimentos y proyectos de investigación práctica")
}

sealed interface AiStreamEvent {
    data class Chunk(val accumulatedText: String) : AiStreamEvent
    data class Completed(val finalText: String, val isPlaceholder: Boolean = false) : AiStreamEvent
}

interface AiRepository {
    val modelId: String
    fun currentConnectionMode(): AiConnectionMode
    fun currentStatusDescription(): String
    fun isNetworkAvailable(): Boolean

    fun streamTutorReply(
        tutor: TutorEntity,
        studentLevel: String,
        history: List<MessageEntity>,
        userPrompt: String
    ): Flow<AiStreamEvent>

    fun streamLabGeneration(
        tool: LabToolType,
        topicOrInput: String,
        studentLevel: String
    ): Flow<AiStreamEvent>
}

class FirebaseAiRepository(private val context: Context) : AiRepository {

    override val modelId: String = DEFAULT_MODEL_ID
    private val aiClient by lazy { Firebase.ai }

    override fun isNetworkAvailable(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return true
            val network = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            true
        }
    }

    override fun currentConnectionMode(): AiConnectionMode {
        return if (isNetworkAvailable()) {
            AiConnectionMode.FIREBASE_CONNECTED
        } else {
            AiConnectionMode.OFFLINE_LOCAL_ONLY
        }
    }

    override fun currentStatusDescription(): String {
        return if (isNetworkAvailable()) {
            "Conectado a Gemini ($DEFAULT_MODEL_ID) mediante Firebase AI Logic y App Check."
        } else {
            "Sin conexión a internet. Tus cursos, apuntes, flashcards y planificador siguen funcionando sin conexión; reconéctate para consultar a Gemini."
        }
    }

    override fun streamTutorReply(
        tutor: TutorEntity,
        studentLevel: String,
        history: List<MessageEntity>,
        userPrompt: String
    ): Flow<AiStreamEvent> = flow {
        if (!isNetworkAvailable()) {
            throw IllegalStateException("No hay conexión a internet. Conéctate a la red para hablar con ${tutor.name}.")
        }

        val tutorModel = aiClient.generativeModel(
            modelName = DEFAULT_MODEL_ID,
            generationConfig = generationConfig {
                temperature = 0.6f
                maxOutputTokens = 2048
            },
            systemInstruction = content {
                text(buildTutorSystemPrompt(tutor, studentLevel))
            }
        )

        val chatHistory = buildSanitizedChatHistory(history)
        val chat = tutorModel.startChat(history = chatHistory)
        val accumulated = StringBuilder()

        chat.sendMessageStream(userPrompt.trim()).collect { chunk ->
            val piece = chunk.text.orEmpty()
            if (piece.isNotEmpty()) {
                accumulated.append(piece)
                emit(AiStreamEvent.Chunk(accumulated.toString()))
            }
        }

        val finalText = accumulated.toString().trim()
        if (finalText.isBlank()) {
            throw IllegalStateException("Gemini no devolvió contenido para esta consulta.")
        }
        emit(AiStreamEvent.Completed(finalText = finalText, isPlaceholder = false))
    }.flowOn(Dispatchers.IO)

    override fun streamLabGeneration(
        tool: LabToolType,
        topicOrInput: String,
        studentLevel: String
    ): Flow<AiStreamEvent> = flow {
        if (!isNetworkAvailable()) {
            throw IllegalStateException("Sin conexión a internet. El Laboratorio requiere red para consultar a Gemini.")
        }

        val labModel = aiClient.generativeModel(
            modelName = DEFAULT_MODEL_ID,
            generationConfig = generationConfig {
                temperature = 0.55f
                maxOutputTokens = 3072
            },
            systemInstruction = content {
                text(buildLabSystemPrompt(tool, studentLevel))
            }
        )

        val prompt = """
            Herramienta solicitada: ${tool.title} (${tool.subtitle})
            Nivel del estudiante: $studentLevel
            Material o tema de entrada:
            ${topicOrInput.trim()}
        """.trimIndent()

        val accumulated = StringBuilder()
        labModel.generateContentStream(prompt).collect { chunk ->
            val piece = chunk.text.orEmpty()
            if (piece.isNotEmpty()) {
                accumulated.append(piece)
                emit(AiStreamEvent.Chunk(accumulated.toString()))
            }
        }

        val finalText = accumulated.toString().trim()
        if (finalText.isBlank()) {
            throw IllegalStateException("Gemini no devolvió resultados para ${tool.title}.")
        }
        emit(AiStreamEvent.Completed(finalText = finalText, isPlaceholder = false))
    }.flowOn(Dispatchers.IO)

    private fun buildSanitizedChatHistory(history: List<MessageEntity>): List<Content> {
        val valid = history
            .filter { !it.isError && it.content.isNotBlank() }
            .takeLast(24)
            .dropWhile { it.role != "user" }

        val merged = mutableListOf<Pair<String, String>>()
        for (msg in valid) {
            val role = if (msg.role == "user") "user" else "model"
            val text = msg.content.trim()
            if (merged.isNotEmpty() && merged.last().first == role) {
                val prev = merged.removeAt(merged.lastIndex)
                merged.add(role to "${prev.second}\n\n$text")
            } else {
                merged.add(role to text)
            }
        }
        // If history ends with a user turn (e.g. a failed previous send), drop trailing user turn
        // so the upcoming sendMessageStream(userPrompt) cleanly follows a model turn or empty history.
        if (merged.lastOrNull()?.first == "user") {
            merged.removeAt(merged.lastIndex)
        }
        return merged.map { (role, text) -> content(role) { text(text) } }
    }

    companion object {
        const val DEFAULT_MODEL_ID = "gemini-3.8-flash"

        fun buildTutorSystemPrompt(tutor: TutorEntity, studentLevel: String): String = """
            Eres ${tutor.name}, tutor académico especializado en ${tutor.specialty} (área: ${tutor.subjectArea}) dentro de la academia personal LUMEN.
            Nivel actual del estudiante: $studentLevel.
            Personalidad académica: ${tutor.academicPersonality}
            Instrucciones pedagógicas específicas: ${tutor.pedagogicalInstructions}

            Metodología obligatoria de LUMEN:
            1. Responde en español con claridad, rigor y tono cercano de academia privada (salvo que en Idiomas el estudiante practique otro idioma, explicando las correcciones en español).
            2. Identifica los conocimientos previos del estudiante antes de dar saltos conceptuales.
            3. Explica los conceptos con precisión y ofrece ejemplos concretos y pertinentes.
            4. Cuando el estudiante esté aprendiendo un procedimiento o resolviendo un problema, NO reveles la respuesta final de inmediato: guía paso a paso, propón un siguiente paso o ejercicio breve y espera su intento.
            5. Si el estudiante comete un error real, corrígelo con claridad y explica exactamente por qué ocurre ese error.
            6. Comprueba la comprensión al final de cada explicación relevante.
            7. No inventes citas, fuentes ni hechos verificados si no tienes certeza; indícalo con honestidad intelectual.
        """.trimIndent()

        fun buildLabSystemPrompt(tool: LabToolType, studentLevel: String): String = """
            Eres el módulo de Laboratorio Académico de LUMEN impulsado por Gemini.
            Herramienta activa: ${tool.title} — ${tool.subtitle}.
            Nivel del estudiante: $studentLevel.
            Idioma de salida: español.

            Reglas de rigor:
            - Estructura la respuesta de forma limpia, legible y lista para guardarse como material de estudio en la Biblioteca.
            - Adapta la profundidad y vocabulario al nivel $studentLevel.
            - No presentes datos inventados ni referencias bibliográficas ficticias como hechos verificados; si algo depende de verificación externa, señálalo explícitamente.
            - En ejercicios, incluye pistas progresivas antes de las soluciones para fomentar el aprendizaje activo.
        """.trimIndent()
    }
}
