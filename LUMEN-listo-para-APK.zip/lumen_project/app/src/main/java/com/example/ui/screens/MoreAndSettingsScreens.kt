package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.ai.AiConnectionMode
import com.example.ui.components.LumenAiStatusBanner
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.SettingsUiState
import com.example.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MoreHubScreen(
    onOpenLessons: () -> Unit,
    onOpenConversations: () -> Unit,
    onOpenLab: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("more_hub_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                LumenSectionHeader(
                    title = "Centro de herramientas",
                    subtitle = "Lecciones 3D, Sesiones, Laboratorio y Ajustes"
                )
            }
            item {
                MoreHubItemCard(
                    title = "Lecciones",
                    tag = "RUTA 3D",
                    description = "Camino de aprendizaje interactivo con nodos por etapas y evaluación final.",
                    icon = Icons.Rounded.AutoStories,
                    tint = lumenColors.electricBlueBright,
                    testTag = "more_lessons_card",
                    onClick = onOpenLessons
                )
            }
            item {
                MoreHubItemCard(
                    title = "Conversaciones",
                    tag = "TUTORES",
                    description = "Historial completo de sesiones con tutores, búsqueda y cambio de mentor.",
                    icon = Icons.Rounded.Forum,
                    tint = lumenColors.violet,
                    testTag = "more_conversations_card",
                    onClick = onOpenConversations
                )
            }
            item {
                MoreHubItemCard(
                    title = "Laboratorio",
                    tag = "GEMINI AI",
                    description = "Generador de cuestionarios, esquemas, mapas conceptuales y análisis de apuntes.",
                    icon = Icons.Rounded.Science,
                    tint = lumenColors.electricBlueBright,
                    testTag = "more_lab_card",
                    onClick = onOpenLab
                )
            }
            item {
                MoreHubItemCard(
                    title = "Ajustes",
                    tag = "SISTEMA",
                    description = "Apariencia, preferencias de estudio, Gemini, copias JSON y notificaciones.",
                    icon = Icons.Rounded.Settings,
                    tint = lumenColors.success,
                    testTag = "more_settings_card",
                    onClick = onOpenSettings
                )
            }
        }
    }
}

@Composable
private fun MoreHubItemCard(
    title: String,
    tag: String,
    description: String,
    icon: ImageVector,
    tint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    LumenGlassPanel(
        glowColor = tint,
        onClick = onClick,
        modifier = Modifier.testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.radialGradient(
                            listOf(tint.copy(alpha = 0.3f), Color(0xFF0A0D16))
                        )
                    )
                    .border(1.dp, tint.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                LumenMonospaceTag(text = tag, accentColor = tint)
                Spacer(modifier = Modifier.height(6.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(
                Icons.AutoMirrored.Rounded.ArrowForwardIos,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SettingsScreen(
    state: SettingsUiState,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = state.preferences

    var nameInput by remember(prefs.userName) { mutableStateOf(prefs.userName) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.toggleReminders(context, true, prefs.reminderHour, prefs.reminderMinute)
        } else {
            viewModel.toggleReminders(context, false, prefs.reminderHour, prefs.reminderMinute)
            viewModel.postFeedback("Permiso de notificaciones denegado. Puedes activarlo en los ajustes del sistema.")
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.generateExportJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray(Charsets.UTF_8))
                        }
                    }
                    viewModel.postFeedback("Copia de seguridad exportada correctamente.")
                } catch (e: Exception) {
                    viewModel.postFeedback("Error al exportar: ${e.localizedMessage}")
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    }
                    viewModel.importBackupJson(raw)
                } catch (e: Exception) {
                    viewModel.postFeedback("Error leyendo el archivo: ${e.localizedMessage}")
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("settings_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            state.feedbackMessage?.let { msg ->
                item {
                    LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                        Text(msg, style = MaterialTheme.typography.bodyMedium, color = lumenColors.electricBlueBright)
                    }
                }
            }

            item {
                LumenSurfaceCard {
                    LumenSectionHeader(title = "Apariencia y perfil local")
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Nombre de estudio") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { viewModel.setUserName(nameInput) }) {
                            Text("Aplicar")
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Estética oscura Liquid Glass", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Negro profundo y grafito con acentos en azul eléctrico y violeta.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.isDarkTheme,
                            onCheckedChange = { viewModel.setDarkTheme(it) },
                            modifier = Modifier.testTag("settings_dark_theme_switch")
                        )
                    }
                }
            }

            item {
                LumenSurfaceCard {
                    LumenSectionHeader(title = "Preferencias de estudio")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("META DIARIA: ${prefs.dailyStudyGoalMinutes} MIN", style = MaterialTheme.typography.labelMedium, color = lumenColors.electricBlueBright)
                    Slider(
                        value = prefs.dailyStudyGoalMinutes.toFloat(),
                        onValueChange = { viewModel.setDailyGoal(it.toInt()) },
                        valueRange = 15f..240f,
                        steps = 14
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Nivel habitual de tutores y laboratorio", style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Básico", "Intermedio", "Avanzado").forEach { lvl ->
                            FilterChip(
                                selected = prefs.preferredLevel == lvl,
                                onClick = { viewModel.setPreferredLevel(lvl) },
                                label = { Text(lvl) }
                            )
                        }
                    }
                }
            }

            item {
                LumenGlassPanel(glowColor = lumenColors.violet) {
                    LumenSectionHeader(
                        title = "Configuración de Gemini",
                        subtitle = "Modelo activo: ${state.aiModelId} · Firebase AI Logic",
                        actionLabel = "Comprobar",
                        onAction = { viewModel.refreshAiStatus() }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LumenAiStatusBanner(
                        message = state.aiStatusDescription,
                        isConnected = state.aiConnectionMode == AiConnectionMode.FIREBASE_CONNECTED
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "LUMEN utiliza Firebase AI Logic y App Check (sin claves API en el APK). Si no hay conexión a internet, las funciones locales permanecen operativas.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                LumenSurfaceCard {
                    LumenSectionHeader(title = "Notificaciones y recordatorios")
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Recordatorio diario de estudio", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Programado con WorkManager a las %02d:%02d".format(prefs.reminderHour, prefs.reminderMinute),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.remindersEnabled,
                            onCheckedChange = { enable ->
                                if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val granted = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!granted) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        viewModel.toggleReminders(context, true, prefs.reminderHour, prefs.reminderMinute)
                                    }
                                } else {
                                    viewModel.toggleReminders(context, enable, prefs.reminderHour, prefs.reminderMinute)
                                }
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(9 to 0, 17 to 0, 20 to 0).forEach { (h, m) ->
                            FilterChip(
                                selected = prefs.reminderHour == h && prefs.reminderMinute == m,
                                onClick = { viewModel.updateReminderTime(context, h, m) },
                                label = { Text("%02d:%02d".format(h, m)) }
                            )
                        }
                    }
                }
            }

            item {
                LumenSurfaceCard {
                    LumenSectionHeader(
                        title = "Respaldo y privacidad",
                        subtitle = "100% local en Room sin cuentas obligatorias"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { exportLauncher.launch("lumen_respaldo.json") },
                            modifier = Modifier.weight(1f).testTag("export_backup_button")
                        ) {
                            Icon(Icons.Rounded.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exportar JSON")
                        }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) },
                            modifier = Modifier.weight(1f).testTag("import_backup_button")
                        ) {
                            Icon(Icons.Rounded.Upload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Importar JSON")
                        }
                    }
                }
            }

            item {
                LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Shield, contentDescription = null, tint = lumenColors.electricBlueBright)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("LUMEN · Academia Personal v1.0", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Privado, sin funciones sociales ni rastreo. Todos tus apuntes, flashcards, progreso y planificación viven en tu dispositivo.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
