package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiConnectionMode
import com.example.data.local.entity.ConversationEntity
import com.example.ui.components.LumenAiStatusBanner
import com.example.ui.components.LumenGlassDialog
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.components.TutorAvatarBadge
import com.example.ui.components.hexToColor
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.ChatSessionState
import com.example.ui.viewmodel.TutorsAndChatViewModel
import com.example.ui.viewmodel.TutorsHubUiState

@Composable
fun ConversationsScreen(
    hubState: TutorsHubUiState,
    chatState: ChatSessionState,
    activeConversationId: Long?,
    viewModel: TutorsAndChatViewModel,
    modifier: Modifier = Modifier
) {
    if (activeConversationId != null && chatState.activeConversation != null) {
        BackHandler {
            viewModel.selectConversation(null)
        }
        TutorChatView(
            hubState = hubState,
            chatState = chatState,
            viewModel = viewModel,
            onBackToList = { viewModel.selectConversation(null) },
            modifier = modifier
        )
    } else {
        ConversationsListView(
            hubState = hubState,
            viewModel = viewModel,
            modifier = modifier
        )
    }
}

@Composable
private fun ConversationsListView(
    hubState: TutorsHubUiState,
    viewModel: TutorsAndChatViewModel,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var showNewConvDialog by remember { mutableStateOf(false) }
    var renamingConv by remember { mutableStateOf<ConversationEntity?>(null) }

    Scaffold(
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewConvDialog = true },
                containerColor = lumenColors.electricBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("new_conversation_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Nueva conversación")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .testTag("conversations_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    LumenAiStatusBanner(
                        message = hubState.aiStatusMessage,
                        isConnected = hubState.connectionMode == AiConnectionMode.FIREBASE_CONNECTED
                    )
                }

                item {
                    LumenGlassPanel(contentPadding = PaddingValues(14.dp)) {
                        OutlinedTextField(
                            value = hubState.searchQuery,
                            onValueChange = viewModel::updateSearch,
                            placeholder = { Text("Buscar sesiones con tutores...") },
                            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("conversations_search_input")
                        )
                    }
                }

                item {
                    LumenSectionHeader(
                        title = "Centro de sesiones",
                        subtitle = "${hubState.conversations.size} guardadas localmente"
                    )
                }

                if (hubState.conversations.isEmpty()) {
                    item {
                        LumenSurfaceCard {
                            Text(
                                "No hay conversaciones que coincidan. Pulsa + para iniciar una nueva sesión con tu tutor preferido.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(hubState.conversations, key = { it.id }) { conv ->
                        val tutor = hubState.tutors.find { it.id == conv.tutorId }
                        val accent = hexToColor(tutor?.accentHex ?: "#4D6BFF", lumenColors.electricBlueBright)

                        LumenSurfaceCard(
                            onClick = { viewModel.selectConversation(conv.id) },
                            borderColor = accent.copy(alpha = 0.35f),
                            modifier = Modifier.testTag("conversation_card_${conv.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TutorAvatarBadge(
                                    initials = tutor?.avatarInitials ?: "TU",
                                    accentColor = accent
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = conv.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${tutor?.name ?: "Tutor"} · ${tutor?.specialty ?: ""} · ${conv.studentLevel}".uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = accent
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = conv.lastMessagePreview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(onClick = { renamingConv = conv }) {
                                    Icon(Icons.Rounded.Edit, contentDescription = "Renombrar conversación")
                                }
                                IconButton(onClick = { viewModel.deleteConversation(conv) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Eliminar conversación", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewConvDialog) {
        var topic by remember { mutableStateOf("") }
        var selectedTutor by remember(hubState.tutors) { mutableStateOf(hubState.tutors.firstOrNull()) }

        LumenGlassDialog(
            title = "Nueva sesión de tutoría",
            onDismissRequest = { showNewConvDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        selectedTutor?.let { tutor ->
                            viewModel.startConversationWithTutor(tutor, topic)
                        }
                        showNewConvDialog = false
                    },
                    enabled = selectedTutor != null
                ) { Text("Iniciar") }
            },
            dismissButton = {
                TextButton(onClick = { showNewConvDialog = false }) { Text("Cancelar") }
            }
        ) {
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Tema o pregunta inicial") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            LumenMonospaceTag(text = "SELECCIONA UN TUTOR")
            hubState.tutors.take(8).forEach { t ->
                val isSelected = selectedTutor?.id == t.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) lumenColors.blueContainer else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                        .border(
                            1.dp,
                            if (isSelected) lumenColors.electricBlueBright else Color.Transparent,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedTutor = t }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${t.name} · ${t.specialty}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }

    renamingConv?.let { conv ->
        var newTitle by remember(conv.id) { mutableStateOf(conv.title) }
        LumenGlassDialog(
            title = "Renombrar sesión",
            onDismissRequest = { renamingConv = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameConversation(conv, newTitle)
                        renamingConv = null
                    },
                    enabled = newTitle.isNotBlank()
                ) { Text("Guardar") }
            },
            dismissButton = {
                TextButton(onClick = { renamingConv = null }) { Text("Cancelar") }
            }
        ) {
            OutlinedTextField(
                value = newTitle,
                onValueChange = { newTitle = it },
                label = { Text("Nuevo título") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun TutorChatView(
    hubState: TutorsHubUiState,
    chatState: ChatSessionState,
    viewModel: TutorsAndChatViewModel,
    onBackToList: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    val conv = chatState.activeConversation ?: return
    val tutor = chatState.activeTutor
    val accent = hexToColor(tutor?.accentHex ?: "#4D6BFF", lumenColors.electricBlueBright)

    var messageInput by remember { mutableStateOf("") }
    var showSwitchTutorMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(chatState.messages.size, chatState.streamingText) {
        val total = chatState.messages.size + if (chatState.isGenerating) 1 else 0
        val targetIndex = (total - 1).coerceAtLeast(0)
        if (total > 0) {
            listState.animateScrollToItem(targetIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .testTag("tutor_chat_view")
    ) {
        // Cabecera cristal líquido de la conversación
        Surface(
            color = lumenColors.glassSurface,
            border = BorderStroke(1.dp, lumenColors.glassEdgeBottom)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToList) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Volver a conversaciones")
                }
                TutorAvatarBadge(
                    initials = tutor?.avatarInitials ?: "TU",
                    accentColor = accent,
                    size = 40.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = conv.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${tutor?.name ?: "Tutor"} · ${tutor?.specialty ?: ""}".uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = accent
                    )
                }
                Box {
                    IconButton(onClick = { showSwitchTutorMenu = true }) {
                        Icon(Icons.Rounded.SwapHoriz, contentDescription = "Cambiar tutor")
                    }
                    DropdownMenu(
                        expanded = showSwitchTutorMenu,
                        onDismissRequest = { showSwitchTutorMenu = false }
                    ) {
                        hubState.tutors.forEach { t ->
                            DropdownMenuItem(
                                text = { Text("${t.name} (${t.specialty})") },
                                onClick = {
                                    viewModel.changeTutorForConversation(conv, t.id)
                                    showSwitchTutorMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        if (hubState.connectionMode != AiConnectionMode.FIREBASE_CONNECTED) {
            LumenAiStatusBanner(
                message = hubState.aiStatusMessage,
                isConnected = false,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (chatState.messages.isEmpty() && !chatState.isGenerating) {
                item {
                    LumenGlassPanel(glowColor = accent) {
                        LumenMonospaceTag(text = "SESIÓN ACTIVA", accentColor = accent)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Sesión lista con ${tutor?.name ?: "tu tutor"}.",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Plantea un problema, pide una explicación o comparte tu razonamiento inicial para recibir guía paso a paso.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(chatState.messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    val bubbleShape = RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = if (isUser) 20.dp else 6.dp,
                        bottomEnd = if (isUser) 6.dp else 20.dp
                    )
                    Surface(
                        shape = bubbleShape,
                        color = if (isUser) lumenColors.electricBlue else MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(
                            1.dp,
                            if (isUser) Color.White.copy(alpha = 0.25f) else lumenColors.cardBorder.copy(alpha = 0.8f)
                        ),
                        modifier = Modifier.widthIn(max = 324.dp)
                    ) {
                        Text(
                            text = msg.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            if (chatState.isGenerating) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
                            modifier = Modifier.widthIn(max = 324.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = accent
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "GEMINI EN STREAMING...",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = accent
                                    )
                                }
                                if (chatState.streamingText.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = chatState.streamingText,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            chatState.errorMessage?.let { err ->
                item {
                    LumenSurfaceCard(borderColor = MaterialTheme.colorScheme.error) {
                        Text(err, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        if (chatState.lastFailedPrompt != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = { viewModel.retryLastFailed() }) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reintentar respuesta")
                            }
                        }
                    }
                }
            }
        }

        // Barra de entrada optimizada sin blur pesado para escritura fluida en Samsung
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(1.dp, lumenColors.cardBorder.copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageInput,
                    onValueChange = { messageInput = it },
                    placeholder = { Text("Escribe tu duda o desarrollo...") },
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_message_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                if (chatState.isGenerating) {
                    IconButton(
                        onClick = { viewModel.cancelGeneration() },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.16f))
                            .testTag("chat_cancel_button")
                    ) {
                        Icon(
                            Icons.Rounded.Stop,
                            contentDescription = "Detener generación",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                } else {
                    val canSend = messageInput.isNotBlank()
                    IconButton(
                        onClick = {
                            val text = messageInput
                            messageInput = ""
                            viewModel.sendMessage(text)
                        },
                        enabled = canSend,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (canSend) {
                                    Brush.verticalGradient(
                                        listOf(lumenColors.electricBlueBright, lumenColors.electricBlueDeep)
                                    )
                                } else {
                                    Brush.verticalGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.surfaceContainerHigh,
                                            MaterialTheme.colorScheme.surfaceContainerHigh
                                        )
                                    )
                                }
                            )
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.Send,
                            contentDescription = "Enviar mensaje",
                            tint = if (canSend) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
