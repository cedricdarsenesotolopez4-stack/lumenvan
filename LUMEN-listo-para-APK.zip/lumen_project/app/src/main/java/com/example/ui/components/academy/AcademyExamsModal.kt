package com.example.ui.components.academy

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.SubjectEntity
import com.example.ui.theme.LocalLumenColors
import com.example.ui.theme.LumenMonoFamily
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.math.max

@Composable
fun ExamsHubModal(
    subjects: List<SubjectEntity>,
    activeSubject: SubjectEntity?,
    exams: List<ExamEntity>,
    notebooks: List<NoteEntity>,
    weeklyMinutesByDay: List<Int>,
    weeklyTotalMinutes: Int,
    nextLesson: LessonEntity?,
    onCreateExam: (SubjectEntity, String, Int, String, String, String, Int, Set<Long>) -> Unit,
    onDeleteExam: (ExamEntity) -> Unit,
    onRecordSimulacro: (ExamEntity, Int) -> Unit,
    onToggleNotebookLink: (ExamEntity, Long) -> Unit,
    onCreateQuickNotebook: (String, String) -> Unit,
    onOpenLesson: (LessonEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalLumenColors.current
    var currentTab by remember { mutableIntStateOf(0) } // 0 = Exámenes, 1 = Cuadernos, 2 = Nuevo examen
    val featuredExam = exams.firstOrNull { it.subjectId == activeSubject?.id } ?: exams.firstOrNull()
    var simulacroScoreInput by remember { mutableStateOf("82") }
    var showSimulacroBar by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(c.academyBg.copy(alpha = 0.98f))
                .statusBarsPadding()
                .padding(18.dp)
                .testTag("academy_exams_modal")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("CENTRO DE PREPARACIÓN", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                    Text("Exámenes y Cuadernos", style = MaterialTheme.typography.headlineMedium, color = c.academyWhite)
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(c.academyGraphite)
                        .testTag("academy_modal_close")
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = c.academyWhite)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(c.academyGraphite)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("Exámenes", "Cuadernos", "+ Nuevo").forEachIndexed { idx, label ->
                    val selected = currentTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) c.academyElectricBlue else Color.Transparent)
                            .clickable { currentTab = idx }
                            .padding(vertical = 9.dp)
                            .testTag("exams_tab_$idx"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (currentTab) {
                0 -> {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Tarjeta destacada con muesca, nodos 3D orbitales y DÍAS PARA EL EXAMEN
                        item {
                            FeaturedExamNodeCard(
                                exam = featuredExam,
                                onStartNextLesson = {
                                    if (nextLesson != null) {
                                        onDismiss()
                                        onOpenLesson(nextLesson)
                                    } else {
                                        currentTab = 2
                                    }
                                },
                                onToggleSimulacro = { showSimulacroBar = !showSimulacroBar }
                            )
                        }

                        if (showSimulacroBar && featuredExam != null) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(c.academyGraphite)
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = simulacroScoreInput,
                                        onValueChange = { simulacroScoreInput = it.filter { ch -> ch.isDigit() } },
                                        label = { Text("Nota simulacro (0-100)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            val score = simulacroScoreInput.toIntOrNull() ?: 80
                                            onRecordSimulacro(featuredExam, score)
                                            showSimulacroBar = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White)
                                    ) { Text("Registrar") }
                                }
                            }
                        }

                        // Tu resumen semanal
                        item {
                            WeeklyStudyBarsCard(
                                weeklyMinutes = weeklyMinutesByDay,
                                totalMinutes = weeklyTotalMinutes
                            )
                        }

                        // Tus exámenes
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Tus exámenes", style = MaterialTheme.typography.titleLarge, color = c.academyWhite)
                                Text("${exams.size} activo(s)", style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                            }
                        }

                        items(exams, key = { it.id }) { exam ->
                            val daysLeft = (exam.examDateEpochDay - LocalDate.now().toEpochDay()).coerceAtLeast(0)
                            val linkedCount = exam.linkedNotebookIdsCsv.split(",").count { it.isNotBlank() }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(c.academyGraphite)
                                    .border(1.dp, c.academyDarkGray, RoundedCornerShape(18.dp))
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${exam.subjectName.uppercase()} · FALTAN $daysLeft DÍAS", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                                    Text(exam.title, style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                                    Text(
                                        "Preparación ${exam.readinessPercent}% / Meta ${exam.targetPercent}% · $linkedCount cuaderno(s)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = c.academyMediumGray
                                    )
                                }
                                IconButton(onClick = { onDeleteExam(exam) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Eliminar examen", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }

                        // Empieza una nueva preparación (cuadrícula 2x2)
                        item {
                            Text("Empieza una nueva preparación", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                            Spacer(modifier = Modifier.height(8.dp))
                            val quickSubjects = subjects.take(4)
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                quickSubjects.chunked(2).forEach { pair ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        pair.forEach { subj ->
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(16.dp))
                                                    .background(c.academyBlackSecondary)
                                                    .border(1.dp, c.academyDarkGray, RoundedCornerShape(16.dp))
                                                    .clickable { currentTab = 2 }
                                                    .padding(14.dp)
                                            ) {
                                                Column {
                                                    Text(subj.name, style = MaterialTheme.typography.titleSmall, color = c.academyWhite)
                                                    Text("Crear plan", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { currentTab = 2 },
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("exams_new_button")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, tint = c.academyLuminousBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Nuevo examen", color = c.academyWhite)
                            }
                        }
                    }
                }

                1 -> {
                    NotebooksLinkedGridView(
                        notebooks = notebooks,
                        featuredExam = featuredExam,
                        defaultSubjectName = activeSubject?.name ?: "Matemáticas",
                        onToggleLink = onToggleNotebookLink,
                        onCreateNotebook = onCreateQuickNotebook,
                        modifier = Modifier.weight(1f)
                    )
                }

                2 -> {
                    NewExamForm(
                        subjects = subjects,
                        initialSubject = activeSubject ?: subjects.firstOrNull(),
                        notebooks = notebooks,
                        onSave = { subj, title, days, syllabus, obj, level, target, linkedIds ->
                            onCreateExam(subj, title, days, syllabus, obj, level, target, linkedIds)
                            currentTab = 0
                        },
                        onCancel = { currentTab = 0 },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun FeaturedExamNodeCard(
    exam: ExamEntity?,
    onStartNextLesson: () -> Unit,
    onToggleSimulacro: () -> Unit
) {
    val c = LocalLumenColors.current
    val daysLeft = exam?.let { (it.examDateEpochDay - LocalDate.now().toEpochDay()).coerceAtLeast(0) } ?: 0
    val gap = exam?.let { max(0, it.targetPercent - it.readinessPercent) } ?: 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(c.academyBlackSecondary)
            .border(1.dp, c.academyDarkGray, RoundedCornerShape(26.dp))
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (exam != null) {
            // Muesca superior "% MATERIA"
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(c.academyGraphite)
                    .border(1.dp, c.academyElectricBlue.copy(alpha = 0.6f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "${exam.readinessPercent}% ${exam.subjectName.uppercase()}",
                    fontFamily = LumenMonoFamily,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.academyWhite
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(exam.title, style = MaterialTheme.typography.titleLarge, color = c.academyWhite, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(12.dp))

            // Nodo 3D orbital + segundo nodo bloqueado como en la referencia
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .shadow(16.dp, CircleShape, ambientColor = c.academyElectricBlue)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color.White, c.academyLuminousBlue, c.academyElectricBlue)))
                            .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.HelpOutline, contentDescription = null, tint = c.academyBg, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(c.academyGraphite)
                            .border(1.dp, c.academyDarkGray, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = c.academyMediumGray, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(modifier = Modifier.width(18.dp))
                Column {
                    Text("LO QUE SIGUE", style = MaterialTheme.typography.labelSmall, color = c.academyLuminousBlue)
                    Text("¿Todo listo para empezar?", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
                    Text("Brecha actual: -$gap pts vs meta", style = MaterialTheme.typography.bodySmall, color = c.academyMediumGray)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Píldora DÍAS PARA EL EXAMEN
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(c.academyGraphite)
                    .border(1.dp, c.academyDarkGray, RoundedCornerShape(999.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DÍAS PARA EL EXAMEN", style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = daysLeft.toString(),
                    fontFamily = LumenMonoFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.academyWhite
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onStartNextLesson,
                colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                shape = RoundedCornerShape(999.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("¡Vamos! · Siguiente lección", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = onToggleSimulacro,
                shape = RoundedCornerShape(999.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Registrar simulacro de examen", color = c.academyWhite)
            }
        } else {
            Text("Aún no tienes exámenes programados", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onStartNextLesson,
                colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White)
            ) {
                Text("Programar mi primer examen")
            }
        }
    }
}

@Composable
private fun WeeklyStudyBarsCard(
    weeklyMinutes: List<Int>,
    totalMinutes: Int
) {
    val c = LocalLumenColors.current
    val dayNames = listOf("L", "M", "X", "J", "V", "S", "D")
    val maxMin = max(60, weeklyMinutes.maxOrNull() ?: 60)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(c.academyGraphite)
            .border(1.dp, c.academyDarkGray, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Tu resumen semanal", style = MaterialTheme.typography.titleMedium, color = c.academyWhite)
            Text(
                text = "$totalMinutes min",
                fontFamily = LumenMonoFamily,
                fontWeight = FontWeight.Bold,
                color = c.academyLuminousBlue
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(78.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            dayNames.forEachIndexed { idx, label ->
                val min = weeklyMinutes.getOrElse(idx) { 0 }
                val ratio = (min.toFloat() / maxMin).coerceIn(0.12f, 1f)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    Box(
                        modifier = Modifier
                            .width(18.dp)
                            .weight(1f, fill = true),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(ratio)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (min > 0) c.academyElectricBlue else c.academyDarkGray)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(label, fontFamily = LumenMonoFamily, fontSize = 10.sp, color = c.academyMediumGray)
                }
            }
        }
    }
}

@Composable
private fun NotebooksLinkedGridView(
    notebooks: List<NoteEntity>,
    featuredExam: ExamEntity?,
    defaultSubjectName: String,
    onToggleLink: (ExamEntity, Long) -> Unit,
    onCreateNotebook: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val dateFormat = remember { SimpleDateFormat("d MMM yyyy", Locale.forLanguageTag("es-ES")) }
    val linkedIds = featuredExam?.linkedNotebookIdsCsv?.split(",")?.filter { it.isNotBlank() }?.toSet().orEmpty()
    var newTitle by remember { mutableStateOf("") }
    var showCreateBox by remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        if (featuredExam != null) {
            Text(
                text = "Toca un cuaderno para vincularlo a «${featuredExam.title}»",
                style = MaterialTheme.typography.bodySmall,
                color = c.academyMediumGray
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
        if (showCreateBox) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    placeholder = { Text("Título del cuaderno") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            onCreateNotebook(newTitle, defaultSubjectName)
                            newTitle = ""
                            showCreateBox = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White)
                ) { Text("Crear") }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Tarjeta punteada "Nuevo cuaderno" inspirada directamente en la imagen 4
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(186.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(c.academyBlackSecondary)
                        .border(1.2.dp, c.academyDarkGray, RoundedCornerShape(20.dp))
                        .clickable { showCreateBox = !showCreateBox }
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF331B0E)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Book, contentDescription = null, tint = Color(0xFFD9642B), modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Nuevo cuaderno", style = MaterialTheme.typography.titleMedium, color = c.academyWhite, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Crea un cuaderno vacío y añade apuntes para tus exámenes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.academyMediumGray,
                        textAlign = TextAlign.Center
                    )
                }
            }

            items(notebooks, key = { it.id }) { note ->
                val isLinked = note.id.toString() in linkedIds
                val spineColor = if (isLinked) c.academyViolet else Color(0xFF475772)
                val bgTint = if (isLinked) c.academyDeepViolet else Color(0xFF171C26)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(186.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(bgTint)
                        .border(1.dp, if (isLinked) c.academyViolet else c.academyDarkGray, RoundedCornerShape(20.dp))
                        .clickable {
                            if (featuredExam != null) {
                                onToggleLink(featuredExam, note.id)
                            }
                        }
                ) {
                    // Lomo vertical izquierdo coloreado
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .fillMaxHeight()
                            .background(spineColor)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isLinked) Icons.Rounded.Psychology else Icons.Rounded.Description,
                                contentDescription = null,
                                tint = c.academyWhite,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        if (isLinked) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color.Black.copy(alpha = 0.25f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Vinculado", style = MaterialTheme.typography.labelSmall, color = Color.White)
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.Black.copy(alpha = 0.22f))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = c.academyWhite,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = dateFormat.format(Date(note.updatedAt)),
                                style = MaterialTheme.typography.labelSmall,
                                color = c.academyMediumGray
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NewExamForm(
    subjects: List<SubjectEntity>,
    initialSubject: SubjectEntity?,
    notebooks: List<NoteEntity>,
    onSave: (SubjectEntity, String, Int, String, String, String, Int, Set<Long>) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    var selectedSubject by remember(initialSubject) { mutableStateOf(initialSubject ?: subjects.firstOrNull()) }
    var title by remember { mutableStateOf("") }
    var daysText by remember { mutableStateOf("21") }
    var syllabus by remember { mutableStateOf("") }
    var objectives by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("Intermedio") }
    var targetText by remember { mutableStateOf("85") }
    var linkedNotes by remember { mutableStateOf(setOf<Long>()) }

    LazyColumn(
        modifier = modifier.testTag("exams_new_form_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Configurar nuevo examen", style = MaterialTheme.typography.titleLarge, color = c.academyWhite)
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                subjects.take(8).forEach { subj ->
                    FilterChip(
                        selected = selectedSubject?.id == subj.id,
                        onClick = { selectedSubject = subj },
                        label = { Text(subj.name) }
                    )
                }
            }
        }
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Nombre del examen *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("exam_title_input")
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = daysText,
                    onValueChange = { daysText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Días restantes") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Meta (%)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            OutlinedTextField(
                value = syllabus,
                onValueChange = { syllabus = it },
                label = { Text("Temario y bloques incluidos") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = objectives,
                onValueChange = { objectives = it },
                label = { Text("Objetivos del estudiante") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Inicial", "Intermedio", "Avanzado").forEach { lvl ->
                    FilterChip(selected = level == lvl, onClick = { level = lvl }, label = { Text(lvl) })
                }
            }
        }
        if (notebooks.isNotEmpty()) {
            item {
                Text("Vincular cuadernos:", style = MaterialTheme.typography.labelSmall, color = c.academyMediumGray)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    notebooks.take(4).forEach { note ->
                        val picked = note.id in linkedNotes
                        FilterChip(
                            selected = picked,
                            onClick = {
                                linkedNotes = if (picked) linkedNotes - note.id else linkedNotes + note.id
                            },
                            label = { Text(note.title.take(22)) }
                        )
                    }
                }
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                    Text("Cancelar", color = c.academyWhite)
                }
                Button(
                    onClick = {
                        val subj = selectedSubject ?: return@Button
                        onSave(
                            subj,
                            title,
                            daysText.toIntOrNull() ?: 14,
                            syllabus,
                            objectives,
                            level,
                            targetText.toIntOrNull() ?: 85,
                            linkedNotes
                        )
                    },
                    enabled = title.isNotBlank() && selectedSubject != null,
                    colors = ButtonDefaults.buttonColors(containerColor = c.academyElectricBlue, contentColor = Color.White),
                    modifier = Modifier.weight(1f).testTag("save_exam_button")
                ) {
                    Text("Guardar examen")
                }
            }
        }
    }
}
