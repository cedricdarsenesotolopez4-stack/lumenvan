package com.example.ui.components.academy

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.GaugeSegmentModel
import com.example.ui.theme.LocalLumenColors
import com.example.ui.theme.LumenMonoFamily
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

private data class DialSlotSpec(
    val centerAngleDeg: Float,
    val sweepAngleDeg: Float,
    val isTopFeatured: Boolean
)

private val DIAL_SLOTS = listOf(
    DialSlotSpec(centerAngleDeg = -90f, sweepAngleDeg = 74f, isTopFeatured = true),
    DialSlotSpec(centerAngleDeg = -25f, sweepAngleDeg = 46f, isTopFeatured = false),
    DialSlotSpec(centerAngleDeg = 32f, sweepAngleDeg = 46f, isTopFeatured = false),
    DialSlotSpec(centerAngleDeg = 148f, sweepAngleDeg = 46f, isTopFeatured = false),
    DialSlotSpec(centerAngleDeg = 205f, sweepAngleDeg = 46f, isTopFeatured = false)
)

@Composable
fun PreparationGauge(
    segments: List<GaugeSegmentModel>,
    selectedSegmentIndex: Int,
    onSelectSegment: (Int) -> Unit,
    onAdvanceActiveSegment: () -> Unit,
    dialSize: Dp = 290.dp,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val safeSegments = if (segments.isEmpty()) {
        List(5) { idx ->
            GaugeSegmentModel(-idx.toLong(), "BLOQUE ${idx + 1}", "", 0, emptyList(), emptyList(), 0, 0)
        }
    } else segments

    val safeSelected = selectedSegmentIndex.coerceIn(0, safeSegments.lastIndex)
    val orderedSegments = remember(safeSegments, safeSelected) {
        List(5) { slot ->
            val realIdx = (safeSelected + slot) % safeSegments.size
            realIdx to safeSegments[realIdx]
        }
    }

    val activeSegment = orderedSegments.first().second
    val animatedActiveProgress by animateFloatAsState(
        targetValue = (activeSegment.readinessPercent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing),
        label = "activeGaugeProgress"
    )
    val animatedPercentages = orderedSegments.mapIndexed { slotIdx, (_, seg) ->
        val animated by animateFloatAsState(
            targetValue = if (slotIdx == 0) (seg.readinessPercent / 100f) else (seg.readinessPercent / 100f),
            animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing),
            label = "seg_$slotIdx"
        )
        animated.coerceIn(0f, 1f)
    }

    Box(
        modifier = modifier
            .size(dialSize)
            .testTag("academy_preparation_gauge"),
        contentAlignment = Alignment.Center
    ) {
        // Dial radial interactivo dibujado con Canvas nativo
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(orderedSegments) {
                    detectTapGestures { tapOffset ->
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val dx = tapOffset.x - cx
                        val dy = tapOffset.y - cy
                        val dist = hypot(dx, dy)
                        val minR = size.width * 0.25f
                        val maxR = size.width * 0.49f
                        if (dist in minR..maxR) {
                            var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                            val hitSlot = DIAL_SLOTS.indexOfFirst { slot ->
                                val diff = normalizeAngleDiff(angle, slot.centerAngleDeg)
                                kotlin.math.abs(diff) <= slot.sweepAngleDeg / 2f + 5f
                            }
                            if (hitSlot == 0) {
                                onAdvanceActiveSegment()
                            } else if (hitSlot in 1 until orderedSegments.size) {
                                onSelectSegment(orderedSegments[hitSlot].first)
                            }
                        }
                    }
                }
        ) {
            val minDim = size.minDimension
            val centerPt = Offset(size.width / 2f, size.height / 2f)

            // Halo ambiental sutil detrás del segmento activo superior
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        c.academyElectricBlue.copy(alpha = 0.22f * (0.35f + animatedActiveProgress)),
                        c.academyViolet.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = Offset(centerPt.x, centerPt.y - minDim * 0.16f),
                    radius = minDim * 0.45f
                ),
                center = Offset(centerPt.x, centerPt.y - minDim * 0.16f),
                radius = minDim * 0.45f
            )

            DIAL_SLOTS.forEachIndexed { slotIdx, slot ->
                val fillFraction = animatedPercentages.getOrElse(slotIdx) { 0f }
                val outerR = if (slot.isTopFeatured) minDim * 0.465f else minDim * 0.435f
                val innerR = if (slot.isTopFeatured) minDim * 0.300f else minDim * 0.305f
                val startAngle = slot.centerAngleDeg - slot.sweepAngleDeg / 2f

                val sectorPath = buildAnnularSectorPath(
                    center = centerPt,
                    innerRadius = innerR,
                    outerRadius = outerR,
                    startAngleDeg = startAngle,
                    sweepAngleDeg = slot.sweepAngleDeg
                )

                // Fondo grafito sólido del segmento
                drawPath(
                    path = sectorPath,
                    color = if (slot.isTopFeatured) c.academyBlackSecondary else c.academyGraphite
                )

                // Relleno activo proporcional en azul eléctrico -> luminoso -> violeta
                if (fillFraction > 0.01f) {
                    val activeSweep = (slot.sweepAngleDeg * fillFraction).coerceAtLeast(2f)
                    val progressPath = buildAnnularSectorPath(
                        center = centerPt,
                        innerRadius = innerR,
                        outerRadius = outerR,
                        startAngleDeg = startAngle,
                        sweepAngleDeg = activeSweep
                    )
                    drawPath(
                        path = progressPath,
                        brush = Brush.linearGradient(
                            colors = listOf(c.academyElectricBlue, c.academyLuminousBlue, c.academyViolet),
                            start = Offset(centerPt.x - outerR, centerPt.y - outerR),
                            end = Offset(centerPt.x + outerR, centerPt.y + outerR)
                        )
                    )
                }

                // Contorno técnico del segmento (superior destacado con contorno claro visible)
                drawPath(
                    path = sectorPath,
                    color = if (slot.isTopFeatured) {
                        if (fillFraction > 0.05f) c.academyLuminousBlue.copy(alpha = 0.85f) else c.academyWhite.copy(alpha = 0.38f)
                    } else {
                        c.academyDarkGray.copy(alpha = 0.85f)
                    },
                    style = Stroke(
                        width = if (slot.isTopFeatured) 2.4f else 1.3f,
                        join = StrokeJoin.Round,
                        cap = StrokeCap.Round
                    )
                )
            }

            // Indicador triangular superior sobre el segmento protagonista
            val tipY = centerPt.y - minDim * 0.486f
            val triPath = Path().apply {
                moveTo(centerPt.x, tipY + 10f)
                lineTo(centerPt.x - 8f, tipY - 3f)
                lineTo(centerPt.x + 8f, tipY - 3f)
                close()
            }
            drawPath(
                path = triPath,
                color = c.academyElectricBlue
            )

            // Anillo sutil interno de precisión
            drawCircle(
                color = c.academyDarkGray.copy(alpha = 0.35f),
                radius = minDim * 0.275f,
                center = centerPt,
                style = Stroke(width = 1f)
            )
        }

        // Etiqueta superior centrada dentro/sobre el arco destacado: NOMBRE >
        val isCompactDial = dialSize < 235.dp
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = if (isCompactDial) dialSize * 0.06f else dialSize * 0.095f)
                .clip(RoundedCornerShape(999.dp))
                .clickable(onClick = onAdvanceActiveSegment)
                .padding(horizontal = 10.dp, vertical = 3.dp)
                .testTag("academy_active_segment_label"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = activeSegment.title.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp,
                    fontSize = if (isCompactDial) 9.5.sp else 11.sp
                ),
                color = c.academyWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(2.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = "Abrir temas de ${activeSegment.title}",
                tint = c.academyWhite.copy(alpha = 0.85f),
                modifier = Modifier.size(if (isCompactDial) 12.dp else 14.dp)
            )
        }

        // Centro: Porcentaje tabular en fuente mono + NIVEL DE PREPARACIÓN + botón 3D '>'
        val isUltraCompact = dialSize < 200.dp
        val continueBtnSize = when {
            isUltraCompact -> 38.dp
            isCompactDial -> 48.dp
            else -> 56.dp
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = if (isUltraCompact) dialSize * 0.06f else if (isCompactDial) 14.dp else 18.dp)
        ) {
            PreparationPercentage(
                percent = activeSegment.readinessPercent,
                compact = isCompactDial,
                ultraCompact = isUltraCompact
            )
            Spacer(modifier = Modifier.height(if (isUltraCompact) 3.dp else if (isCompactDial) 6.dp else 14.dp))
            ContinueButton(
                onClick = onAdvanceActiveSegment,
                buttonSize = continueBtnSize
            )
        }
    }
}

@Composable
fun PreparationPercentage(
    percent: Int,
    compact: Boolean = false,
    ultraCompact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    Column(
        modifier = modifier.testTag("academy_preparation_percentage"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "$percent%",
            fontFamily = LumenMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = when {
                ultraCompact -> 22.sp
                compact -> 30.sp
                else -> 44.sp
            },
            lineHeight = when {
                ultraCompact -> 24.sp
                compact -> 32.sp
                else -> 46.sp
            },
            color = c.academyWhite,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "NIVEL DE PREPARACIÓN",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Medium,
                letterSpacing = if (ultraCompact) 0.4.sp else if (compact) 0.9.sp else 1.4.sp,
                fontSize = if (ultraCompact) 7.sp else if (compact) 8.sp else 9.5.sp
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = c.academyMediumGray,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ContinueButton(
    onClick: () -> Unit,
    buttonSize: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "continueScale"
    )

    Box(
        modifier = modifier
            .size(buttonSize)
            .scale(scale)
            .shadow(14.dp, CircleShape, ambientColor = c.academyElectricBlue, spotColor = c.academyLuminousBlue)
            .clip(CircleShape)
            .background(
                Brush.verticalGradient(
                    listOf(c.academyLuminousBlue, c.academyElectricBlue, Color(0xFF2838CC))
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))
                ),
                shape = CircleShape
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick
            )
            .testTag("academy_continue_button")
            .semantics { contentDescription = "Avanzar o explorar bloques del área actual" },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(buttonSize * 0.54f)
        )
    }
}

private fun buildAnnularSectorPath(
    center: Offset,
    innerRadius: Float,
    outerRadius: Float,
    startAngleDeg: Float,
    sweepAngleDeg: Float
): Path {
    val outerRect = Rect(
        center.x - outerRadius,
        center.y - outerRadius,
        center.x + outerRadius,
        center.y + outerRadius
    )
    val innerRect = Rect(
        center.x - innerRadius,
        center.y - innerRadius,
        center.x + innerRadius,
        center.y + innerRadius
    )
    val endAngleRad = Math.toRadians((startAngleDeg + sweepAngleDeg).toDouble())
    val endInnerX = center.x + (innerRadius * cos(endAngleRad)).toFloat()
    val endInnerY = center.y + (innerRadius * sin(endAngleRad)).toFloat()

    return Path().apply {
        arcTo(outerRect, startAngleDeg, sweepAngleDeg, true)
        lineTo(endInnerX, endInnerY)
        arcTo(innerRect, startAngleDeg + sweepAngleDeg, -sweepAngleDeg, false)
        close()
    }
}

private fun normalizeAngleDiff(a: Float, b: Float): Float {
    var diff = (a - b) % 360f
    if (diff > 180f) diff -= 360f
    if (diff < -180f) diff += 360f
    return diff
}
