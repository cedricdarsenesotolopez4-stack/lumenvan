package com.example.ui.components.academy

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalLumenColors
import com.example.ui.theme.LumenMonoFamily

@Composable
fun AcademyTopBar(
    streakDays: Int,
    pointsBalance: Int,
    avatarKey: String,
    onStreakClick: () -> Unit,
    onRewardsClick: () -> Unit,
    onProfileClick: () -> Unit,
    compact: Boolean = false,
    ultraShort: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val pillShape = RoundedCornerShape(999.dp)
    val pillMinHeight = when {
        ultraShort -> 32.dp
        compact -> 38.dp
        else -> 48.dp
    }
    val pillVertPad = when {
        ultraShort -> 2.dp
        compact -> 4.dp
        else -> 8.dp
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (ultraShort) 1.dp else if (compact) 2.dp else 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Píldora de racha diaria (izquierda)
        Row(
            modifier = Modifier
                .heightIn(min = pillMinHeight)
                .clip(pillShape)
                .background(c.academyGraphite.copy(alpha = 0.92f))
                .border(1.dp, c.academyDarkGray, pillShape)
                .clickable(onClick = onStreakClick)
                .padding(horizontal = 12.dp, vertical = pillVertPad)
                .testTag("academy_streak_pill")
                .semantics { contentDescription = "Racha de estudio de $streakDays días" },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.LocalFireDepartment,
                contentDescription = null,
                tint = c.warning,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = streakDays.toString(),
                fontFamily = LumenMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = c.academyWhite
            )
        }

        // 2. Píldora central RECOMPENSAS en azul eléctrico luminoso
        Row(
            modifier = Modifier
                .heightIn(min = pillMinHeight)
                .clip(pillShape)
                .background(
                    Brush.horizontalGradient(
                        listOf(c.academyElectricBlue, c.academyLuminousBlue)
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.42f), Color.Transparent)
                    ),
                    shape = pillShape
                )
                .clickable(onClick = onRewardsClick)
                .padding(horizontal = 15.dp, vertical = pillVertPad)
                .testTag("academy_rewards_pill")
                .semantics { contentDescription = "Abrir recompensas y puntos" },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "RECOMPENSAS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp,
                    fontSize = 11.sp
                ),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // 3. Píldora derecha: Energía/Puntos + Avatar local
        Row(
            modifier = Modifier
                .heightIn(min = pillMinHeight)
                .clip(pillShape)
                .background(c.academyGraphite.copy(alpha = 0.92f))
                .border(1.dp, c.academyDarkGray, pillShape)
                .clickable(onClick = onProfileClick)
                .padding(start = 10.dp, end = 6.dp, top = pillVertPad / 2, bottom = pillVertPad / 2)
                .testTag("academy_profile_pill")
                .semantics { contentDescription = "Perfil local con $pointsBalance puntos" },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Bolt,
                contentDescription = null,
                tint = c.academyLuminousBlue,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = pointsBalance.toString(),
                fontFamily = LumenMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = c.academyWhite
            )
            Spacer(modifier = Modifier.width(8.dp))
            AcademyAvatarOrb(
                avatarKey = avatarKey,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
fun AcademyAvatarOrb(
    avatarKey: String,
    modifier: Modifier = Modifier
) {
    val c = LocalLumenColors.current
    val accentPair = when (avatarKey) {
        "prism" -> c.academyViolet to c.academyLuminousBlue
        "atom" -> c.success to c.academyElectricBlue
        "quill" -> c.warning to c.academyViolet
        "compass" -> c.academyLuminousBlue to c.success
        else -> c.academyElectricBlue to c.academyViolet
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(accentPair.first, accentPair.second)))
            .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(20.dp)) {
            val r = size.minDimension * 0.34f
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = r * 0.45f,
                center = center
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.45f),
                radius = r * 1.15f,
                center = Offset(center.x, center.y),
                style = Stroke(width = 1.8f)
            )
        }
    }
}
