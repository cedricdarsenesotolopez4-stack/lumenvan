package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.LessonEntity
import com.example.data.local.entity.SubjectEntity
import com.example.data.local.entity.UnitEntity
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LessonsCatalogState(
    val courses: List<CourseEntity> = emptyList(),
    val subjects: List<SubjectEntity> = emptyList(),
    val units: List<UnitEntity> = emptyList(),
    val lessons: List<LessonEntity> = emptyList()
)

class LessonsViewModel(private val repository: LumenRepository) : ViewModel() {

    val catalogState: StateFlow<LessonsCatalogState> = combine(
        repository.courses,
        repository.subjects,
        repository.units,
        repository.lessons
    ) { courses, subjects, units, lessons ->
        LessonsCatalogState(courses, subjects, units, lessons)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LessonsCatalogState()
    )

    fun observeLesson(lessonId: Long) = repository.observeLesson(lessonId)

    fun advanceLessonStage(lesson: LessonEntity, nextStage: Int) {
        viewModelScope.launch {
            repository.updateLessonStage(lesson, newStage = nextStage)
        }
    }

    fun completeLessonEvaluation(lesson: LessonEntity, scorePercent: Int) {
        viewModelScope.launch {
            repository.updateLessonStage(
                lesson = lesson,
                newStage = 4,
                completed = true,
                score = scorePercent
            )
        }
    }
}
