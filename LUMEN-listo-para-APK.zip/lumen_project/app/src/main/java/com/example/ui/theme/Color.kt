package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Base negro profundo y grafito futurista
val ObsidianVoid = Color(0xFF04060B)
val DeepSpaceBlack = Color(0xFF070A12)
val GraphiteDark = Color(0xFF0E121D)
val GraphiteSurface = Color(0xFF141A28)
val GraphiteElevated = Color(0xFF1B2235)
val GraphiteOutline = Color(0xFF28324B)

// Textos: blanco ligeramente cálido y pizarra fría
val WarmWhiteText = Color(0xFFF6F5F0)
val SoftWarmWhite = Color(0xFFDAD9D2)
val MutedCoolSlate = Color(0xFF949DB6)

// Protagonistas: azul eléctrico y violeta luminoso
val ElectricBlue = Color(0xFF4D6BFF)
val ElectricBlueBright = Color(0xFF6E88FF)
val ElectricBlueDeep = Color(0xFF334CE0)
val ElectricBlueContainer = Color(0xFF121C3F)

val LuminousViolet = Color(0xFF8466FF)
val VioletContainerDark = Color(0xFF1E1740)

// Cristal líquido (Liquid Glass)
val GlassSurfaceDark = Color(0xCC111624)
val GlassTopSpecular = Color(0x3DFFFFFF)
val GlassBottomRim = Color(0x14FFFFFF)

// Estados semánticos
val EmeraldSuccess = Color(0xFF2AD496)
val AmberWarning = Color(0xFFF0A840)
val CrimsonError = Color(0xFFFF5E73)

// Paleta clara académica opcional (preservada para toggle en Ajustes)
val ParchmentLight = Color(0xFFF5F6FA)
val IvoryCardLight = Color(0xFFFFFFFF)
val SoftWarmSurfaceLight = Color(0xFFE9ECF5)
val InkDarkText = Color(0xFF0E1320)
val SlateSecondaryLight = Color(0xFF525B72)
val ElectricBlueLight = Color(0xFF3452E1)
val BlueContainerLight = Color(0xFFE0E6FF)
val VioletLight = Color(0xFF6246E5)
val VioletContainerLight = Color(0xFFEBE7FF)
val OutlineLight = Color(0xFFD2D8E8)

// Paleta dedicada Academia & Preparación (reconstrucción de alto contraste)
val AcademyBgBlack = Color(0xFF090909)
val AcademyBlackSecondary = Color(0xFF111111)
val AcademyGraphite = Color(0xFF1B1B1D)
val AcademyDarkGray = Color(0xFF29292D)
val AcademyMediumGray = Color(0xFF77777D)
val AcademyWhite = Color(0xFFF4F4F7)
val AcademyElectricBlue = Color(0xFF394BFA)
val AcademyLuminousBlue = Color(0xFF5267FF)
val AcademyViolet = Color(0xFF7027F5)
val AcademyDeepViolet = Color(0xFF281047)

