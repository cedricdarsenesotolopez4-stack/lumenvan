package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiConnectionMode
import com.example.data.local.entity.TutorEntity
import com.example.ui.components.LumenAiStatusBanner
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenElectricButton
import com.example.ui.components.LumenGlassDialog
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.components.TutorAvatarBadge
import com.example.ui.components.hexToColor
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.TutorsAndChatViewModel
import com.example.ui.viewmodel.TutorsHubUiState

@Composable
fun TutorsScreen(
    hubState: TutorsHubUiState,
    viewModel: TutorsAndChatViewModel,
    onOpenConversation: (Long) -> Unit,
    onOpenConversationsCenter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var showCreateTutor by remember { mutableStateOf(false) }
    var inspectingTutor by remember { mutableStateOf<TutorEntity?>(null) }

    Scaffold(
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateTutor = true },
                containerColor = lumenColors.electricBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("create_tutor_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Crear tutor personalizado")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .testTag("tutors_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    LumenAiStatusBanner(
                        message = hubState.aiStatusMessage,
                        isConnected = hubState.connectionMode == AiConnectionMode.FIREBASE_CONNECTED
                    )
                }

                item {
                    LumenSectionHeader(
                        title = "Claustro de tutores",
                        subtitle = "Metodología socrática guiada",
                        actionLabel = "Sesiones (${hubState.conversations.size})",
                        onAction = onOpenConversationsCenter
                    )
                }

                items(hubState.tutors, key = { it.id }) { tutor ->
                    val accent = hexToColor(tutor.accentHex, lumenColors.electricBlueBright)
                    val relatedConvs = hubState.conversations.count { it.tutorId == tutor.id }

                    val cardContent: @Composable () -> Unit = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(accent.copy(alpha = 0.25f), Color.Transparent)
                                        )
                                    )
                                    .border(1.dp, accent.copy(alpha = 0.45f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                TutorAvatarBadge(initials = tutor.avatarInitials, accentColor = accent, size = 48.dp)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = tutor.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (tutor.isCustom) {
                                        LumenBadge(
                                            text = "Personal",
                                            containerColor = lumenColors.violetContainer,
                                            contentColor = lumenColors.violet
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${tutor.specialty.uppercase()} · $relatedConvs SESIÓN(ES)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = tutor.academicPersonality,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                LumenElectricButton(
                                    text = "Iniciar tutoría",
                                    icon = Icons.Rounded.ChatBubbleOutline,
                                    onClick = {
                                        viewModel.startConversationWithTutor(tutor) { convId ->
                                            onOpenConversation(convId)
                                        }
                                    },
                                    modifier = Modifier.testTag("start_tutor_chat_${tutor.id}")
                                )
                            }
                            OutlinedButton(onClick = { inspectingTutor = tutor }) {
                                Text("Enfoque")
                            }
                            if (tutor.isCustom) {
                                IconButton(onClick = { viewModel.deleteTutor(tutor) }) {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = "Eliminar tutor personalizado",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }

                    if (tutor.id % 2L == 1L) {
                        LumenGlassPanel(
                            glowColor = accent,
                            onClick = { inspectingTutor = tutor },
                            modifier = Modifier.testTag("tutor_card_${tutor.id}")
                        ) { cardContent() }
                    } else {
                        LumenSurfaceCard(
                            borderColor = accent.copy(alpha = 0.42f),
                            onClick = { inspectingTutor = tutor },
                            modifier = Modifier.testTag("tutor_card_${tutor.id}")
                        ) { cardContent() }
                    }
                }
            }
        }
    }

    inspectingTutor?.let { tutor ->
        LumenGlassDialog(
            title = "${tutor.name} · ${tutor.specialty}",
            onDismissRequest = { inspectingTutor = null },
            confirmButton = {
                Button(onClick = {
                    val target = tutor
                    inspectingTutor = null
                    viewModel.startConversationWithTutor(target) { convId ->
                        onOpenConversation(convId)
                    }
                }) { Text("Comenzar sesión") }
            },
            dismissButton = {
                TextButton(onClick = { inspectingTutor = null }) { Text("Cerrar") }
            }
        ) {
            LumenMonospaceTag(text = "PERSONALIDAD ACADÉMICA")
            Text(tutor.academicPersonality, style = MaterialTheme.typography.bodyMedium)
            LumenMonospaceTag(text = "INSTRUCCIONES PEDAGÓGICAS", accentColor = lumenColors.violet)
            Text(tutor.pedagogicalInstructions, style = MaterialTheme.typography.bodyMedium)
        }
    }

    if (showCreateTutor) {
        CreateCustomTutorDialog(
            onDismiss = { showCreateTutor = false },
            onConfirm = { name, specialty, area, personality, instructions ->
                viewModel.createCustomTutor(name, specialty, area, personality, instructions, "#8466FF")
                showCreateTutor = false
            }
        )
    }
}

@Composable
private fun CreateCustomTutorDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var personality by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("") }

    LumenGlassDialog(
        title = "Crear tutor personalizado",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(name, specialty, area, personality, instructions) },
                enabled = name.isNotBlank() && specialty.isNotBlank()
            ) { Text("Crear tutor") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    ) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre del tutor *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = specialty, onValueChange = { specialty = it }, label = { Text("Especialidad *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = area, onValueChange = { area = it }, label = { Text("Materia relacionada") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = personality, onValueChange = { personality = it }, label = { Text("Personalidad académica") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = instructions, onValueChange = { instructions = it }, label = { Text("Instrucciones pedagógicas") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
    }
}
