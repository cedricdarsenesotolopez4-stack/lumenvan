package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiConnectionMode
import com.example.data.ai.AiRepository
import com.example.data.ai.AiStreamEvent
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.TutorEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.LumenRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.timeout
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

data class TutorsHubUiState(
    val tutors: List<TutorEntity> = emptyList(),
    val conversations: List<ConversationEntity> = emptyList(),
    val searchQuery: String = "",
    val connectionMode: AiConnectionMode = AiConnectionMode.FIREBASE_CONNECTED,
    val aiStatusMessage: String = ""
)

data class ChatSessionState(
    val activeConversation: ConversationEntity? = null,
    val activeTutor: TutorEntity? = null,
    val messages: List<MessageEntity> = emptyList(),
    val streamingText: String = "",
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val lastFailedPrompt: String? = null
)

class TutorsAndChatViewModel(
    private val repository: LumenRepository,
    private val aiRepository: AiRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _activeConversationId = MutableStateFlow<Long?>(null)
    private val _streamingText = MutableStateFlow("")
    private val _isGenerating = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _lastFailedPrompt = MutableStateFlow<String?>(null)
    private val _connectionRefreshTick = MutableStateFlow(0)

    private var generationJob: Job? = null

    val hubState: StateFlow<TutorsHubUiState> = combine(
        repository.tutors,
        repository.conversations,
        _searchQuery,
        _connectionRefreshTick
    ) { tutors, conversations, query, _ ->
        val filteredConvs = if (query.isBlank()) conversations else {
            conversations.filter { conv ->
                conv.title.contains(query, ignoreCase = true) ||
                    conv.lastMessagePreview.contains(query, ignoreCase = true)
            }
        }
        TutorsHubUiState(
            tutors = tutors,
            conversations = filteredConvs,
            searchQuery = query,
            connectionMode = aiRepository.currentConnectionMode(),
            aiStatusMessage = aiRepository.currentStatusDescription()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TutorsHubUiState(
            connectionMode = aiRepository.currentConnectionMode(),
            aiStatusMessage = aiRepository.currentStatusDescription()
        )
    )

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val messagesFlow = _activeConversationId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.observeMessages(id)
    }

    val chatState: StateFlow<ChatSessionState> = combine(
        _activeConversationId,
        repository.conversations,
        repository.tutors,
        messagesFlow,
        combine(_streamingText, _isGenerating, _errorMessage, _lastFailedPrompt) { s, g, e, f ->
            listOf(s, g, e, f)
        }
    ) { activeId, conversations, tutors, messages, flags ->
        val conv = conversations.find { it.id == activeId }
        val tutor = conv?.let { c -> tutors.find { it.id == c.tutorId } }
        ChatSessionState(
            activeConversation = conv,
            activeTutor = tutor,
            messages = messages,
            streamingText = flags[0] as String,
            isGenerating = flags[1] as Boolean,
            errorMessage = flags[2] as String?,
            lastFailedPrompt = flags[3] as String?
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ChatSessionState()
    )

    val activeConversationId: StateFlow<Long?> = _activeConversationId.asStateFlow()

    fun refreshConnectionStatus() {
        _connectionRefreshTick.value++
    }

    fun updateSearch(query: String) {
        _searchQuery.value = query
    }

    fun selectConversation(conversationId: Long?) {
        _activeConversationId.value = conversationId
        _errorMessage.value = null
        refreshConnectionStatus()
    }

    fun startConversationWithTutor(tutor: TutorEntity, topicTitle: String = "", onOpened: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val prefs = preferencesRepository.preferences.first()
            val title = topicTitle.ifBlank { "Tutoría de ${tutor.specialty}" }
            val convId = repository.createConversation(
                tutorId = tutor.id,
                title = title,
                level = prefs.preferredLevel
            )
            _activeConversationId.value = convId
            _errorMessage.value = null
            refreshConnectionStatus()
            onOpened(convId)
        }
    }

    fun startContextualTutorSession(
        subjectName: String,
        areaName: String,
        topicName: String?,
        readinessPercent: Int,
        initialPrompt: String? = null,
        onOpened: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val prefs = preferencesRepository.preferences.first()
            val allTutors = hubState.value.tutors.ifEmpty { repository.tutors.first() }
            val matchedTutor = allTutors.firstOrNull {
                it.specialty.equals(subjectName, ignoreCase = true) ||
                    it.subjectArea.equals(subjectName, ignoreCase = true) ||
                    subjectName.contains(it.subjectArea, ignoreCase = true) ||
                    it.specialty.contains(subjectName.take(5), ignoreCase = true)
            } ?: allTutors.firstOrNull() ?: return@launch

            val cleanTopic = topicName?.takeIf { it.isNotBlank() } ?: areaName
            val title = "$subjectName · $cleanTopic"
            val convId = repository.createConversation(
                tutorId = matchedTutor.id,
                title = title,
                level = prefs.preferredLevel
            )
            repository.insertMessage(
                MessageEntity(
                    conversationId = convId,
                    role = "tutor",
                    content = "Sesión contextual iniciada en $subjectName (${areaName}, preparación actual: $readinessPercent%). ¿Qué aspecto de «$cleanTopic» quieres trabajar ahora?"
                )
            )
            _activeConversationId.value = convId
            _errorMessage.value = null
            refreshConnectionStatus()
            onOpened(convId)

            val question = initialPrompt?.trim().orEmpty()
            if (question.isNotBlank()) {
                val createdConv = repository.conversations.first().find { it.id == convId }
                val enriched = "Contexto académico [Materia: $subjectName | Área: $areaName | Tema: $cleanTopic | Preparación: $readinessPercent%]. Consulta del estudiante: $question"
                sendMessageInternal(
                    userText = enriched,
                    insertUserMessage = true,
                    convOverride = createdConv,
                    tutorOverride = matchedTutor
                )
            }
        }
    }

    fun createCustomTutor(
        name: String,
        specialty: String,
        subjectArea: String,
        personality: String,
        instructions: String,
        accentHex: String
    ) {
        if (name.isBlank() || specialty.isBlank()) return
        val initials = name.trim().split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.first().uppercase() }
            .ifBlank { "TU" }
        viewModelScope.launch {
            repository.saveTutor(
                TutorEntity(
                    name = name.trim(),
                    specialty = specialty.trim(),
                    avatarInitials = initials,
                    accentHex = accentHex,
                    academicPersonality = personality.trim().ifBlank { "Mentor académico claro, paciente y estructurado." },
                    pedagogicalInstructions = instructions.trim().ifBlank { "Guía paso a paso, propón ejercicios y verifica comprensión antes de dar la solución." },
                    subjectArea = subjectArea.trim().ifBlank { specialty.trim() },
                    isCustom = true
                )
            )
        }
    }

    fun deleteTutor(tutor: TutorEntity) {
        viewModelScope.launch { repository.deleteTutor(tutor) }
    }

    fun renameConversation(conversation: ConversationEntity, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch { repository.renameConversation(conversation, newTitle) }
    }

    fun changeTutorForConversation(conversation: ConversationEntity, newTutorId: Long) {
        viewModelScope.launch { repository.changeConversationTutor(conversation, newTutorId) }
    }

    fun deleteConversation(conversation: ConversationEntity) {
        viewModelScope.launch {
            if (_activeConversationId.value == conversation.id) {
                _activeConversationId.value = null
            }
            repository.deleteConversation(conversation)
        }
    }

    fun sendMessage(userText: String, insertUserMessage: Boolean = true) {
        sendMessageInternal(userText = userText, insertUserMessage = insertUserMessage)
    }

    @OptIn(FlowPreview::class)
    private fun sendMessageInternal(
        userText: String,
        insertUserMessage: Boolean = true,
        convOverride: ConversationEntity? = null,
        tutorOverride: TutorEntity? = null
    ) {
        val trimmed = userText.trim()
        if (trimmed.isBlank() || _isGenerating.value) return
        val currentConv = convOverride ?: chatState.value.activeConversation ?: return
        val currentTutor = tutorOverride ?: chatState.value.activeTutor ?: return

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            _isGenerating.value = true
            _errorMessage.value = null
            _lastFailedPrompt.value = null
            _streamingText.value = ""
            refreshConnectionStatus()

            try {
                val historyBefore = repository.getMessagesOnce(currentConv.id)
                if (insertUserMessage) {
                    repository.insertMessage(
                        MessageEntity(
                            conversationId = currentConv.id,
                            role = "user",
                            content = trimmed
                        )
                    )
                }

                var finalReply = ""
                var isPlaceholder = false
                aiRepository.streamTutorReply(
                    tutor = currentTutor,
                    studentLevel = currentConv.studentLevel,
                    history = historyBefore,
                    userPrompt = trimmed
                )
                    .timeout(60.seconds)
                    .collect { event ->
                        when (event) {
                            is AiStreamEvent.Chunk -> _streamingText.value = event.accumulatedText
                            is AiStreamEvent.Completed -> {
                                finalReply = event.finalText
                                isPlaceholder = event.isPlaceholder
                            }
                        }
                    }

                if (finalReply.isNotBlank()) {
                    repository.insertMessage(
                        MessageEntity(
                            conversationId = currentConv.id,
                            role = "tutor",
                            content = finalReply,
                            isPlaceholderNotice = isPlaceholder
                        )
                    )
                } else {
                    _errorMessage.value = "Gemini no devolvió contenido. Inténtalo de nuevo."
                    _lastFailedPrompt.value = trimmed
                }
            } catch (e: TimeoutCancellationException) {
                Log.e("TutorsAndChatVM", "Tiempo de espera agotado con Gemini", e)
                val partial = _streamingText.value.trim()
                if (partial.isNotBlank()) {
                    repository.insertMessage(
                        MessageEntity(
                            conversationId = currentConv.id,
                            role = "tutor",
                            content = "$partial\n\n[Respuesta interrumpida por tiempo de espera]",
                            isPlaceholderNotice = false
                        )
                    )
                }
                _errorMessage.value = "La conexión con Gemini superó los 60 segundos sin recibir datos. Pulsa Reintentar o verifica tu red."
                _lastFailedPrompt.value = trimmed
            } catch (e: CancellationException) {
                if (_streamingText.value.isNotBlank()) {
                    repository.insertMessage(
                        MessageEntity(
                            conversationId = currentConv.id,
                            role = "tutor",
                            content = "${_streamingText.value}\n\n[Generación detenida por el estudiante]",
                            isPlaceholderNotice = false
                        )
                    )
                }
                throw e
            } catch (e: Exception) {
                Log.e("TutorsAndChatVM", "Error generando respuesta de Gemini", e)
                _errorMessage.value = e.localizedMessage ?: "No se pudo conectar con Gemini."
                _lastFailedPrompt.value = trimmed
            } finally {
                _streamingText.value = ""
                _isGenerating.value = false
                refreshConnectionStatus()
            }
        }
    }

    fun retryLastFailed() {
        val prompt = _lastFailedPrompt.value ?: return
        _errorMessage.value = null
        sendMessage(prompt, insertUserMessage = false)
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        _isGenerating.value = false
        _streamingText.value = ""
    }
}
