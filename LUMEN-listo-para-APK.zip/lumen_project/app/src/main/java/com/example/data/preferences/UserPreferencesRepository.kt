package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.lumenDataStore: DataStore<Preferences> by preferencesDataStore(name = "lumen_prefs")

data class UserPreferences(
    val userName: String = "Estudiante",
    val isDarkTheme: Boolean = true,
    val dailyStudyGoalMinutes: Int = 60,
    val preferredLevel: String = "Intermedio",
    val spacedRepetitionGoal: Int = 15,
    val remindersEnabled: Boolean = true,
    val reminderHour: Int = 19,
    val reminderMinute: Int = 0,
    val pointsBalance: Int = 120,
    val maxStreakDays: Int = 1,
    val avatarKey: String = "cosmos",
    val unlockedRewardIdsCsv: String = "",
    val lastActiveSubjectId: Long = 0L,
    val activeAccentTitle: String = "Aprendiz LUMEN"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val DAILY_GOAL_MIN = intPreferencesKey("daily_goal_minutes")
        val PREFERRED_LEVEL = stringPreferencesKey("preferred_level")
        val SPACED_REP_GOAL = intPreferencesKey("spaced_rep_goal")
        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
        val REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
        val POINTS_BALANCE = intPreferencesKey("points_balance")
        val MAX_STREAK_DAYS = intPreferencesKey("max_streak_days")
        val AVATAR_KEY = stringPreferencesKey("avatar_key")
        val UNLOCKED_REWARDS = stringPreferencesKey("unlocked_reward_ids")
        val LAST_ACTIVE_SUBJECT_ID = androidx.datastore.preferences.core.longPreferencesKey("last_active_subject_id")
        val ACTIVE_ACCENT_TITLE = stringPreferencesKey("active_accent_title")
    }

    val preferences: Flow<UserPreferences> = context.lumenDataStore.data.map { prefs ->
        UserPreferences(
            userName = prefs[Keys.USER_NAME] ?: "Estudiante",
            isDarkTheme = prefs[Keys.DARK_THEME] ?: true,
            dailyStudyGoalMinutes = prefs[Keys.DAILY_GOAL_MIN] ?: 60,
            preferredLevel = prefs[Keys.PREFERRED_LEVEL] ?: "Intermedio",
            spacedRepetitionGoal = prefs[Keys.SPACED_REP_GOAL] ?: 15,
            remindersEnabled = prefs[Keys.REMINDERS_ENABLED] ?: true,
            reminderHour = prefs[Keys.REMINDER_HOUR] ?: 19,
            reminderMinute = prefs[Keys.REMINDER_MINUTE] ?: 0,
            pointsBalance = prefs[Keys.POINTS_BALANCE] ?: 120,
            maxStreakDays = prefs[Keys.MAX_STREAK_DAYS] ?: 1,
            avatarKey = prefs[Keys.AVATAR_KEY] ?: "cosmos",
            unlockedRewardIdsCsv = prefs[Keys.UNLOCKED_REWARDS] ?: "",
            lastActiveSubjectId = prefs[Keys.LAST_ACTIVE_SUBJECT_ID] ?: 0L,
            activeAccentTitle = prefs[Keys.ACTIVE_ACCENT_TITLE] ?: "Aprendiz LUMEN"
        )
    }

    suspend fun setUserName(name: String) {
        context.lumenDataStore.edit { it[Keys.USER_NAME] = name.ifBlank { "Estudiante" } }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.lumenDataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setDailyStudyGoal(minutes: Int) {
        context.lumenDataStore.edit { it[Keys.DAILY_GOAL_MIN] = minutes.coerceIn(15, 360) }
    }

    suspend fun setPreferredLevel(level: String) {
        context.lumenDataStore.edit { it[Keys.PREFERRED_LEVEL] = level }
    }

    suspend fun setSpacedRepetitionGoal(count: Int) {
        context.lumenDataStore.edit { it[Keys.SPACED_REP_GOAL] = count.coerceIn(5, 100) }
    }

    suspend fun setRemindersEnabled(enabled: Boolean) {
        context.lumenDataStore.edit { it[Keys.REMINDERS_ENABLED] = enabled }
    }

    suspend fun setReminderTime(hour: Int, minute: Int) {
        context.lumenDataStore.edit {
            it[Keys.REMINDER_HOUR] = hour.coerceIn(0, 23)
            it[Keys.REMINDER_MINUTE] = minute.coerceIn(0, 59)
        }
    }

    suspend fun addPoints(delta: Int) {
        if (delta == 0) return
        context.lumenDataStore.edit { prefs ->
            val current = prefs[Keys.POINTS_BALANCE] ?: 120
            prefs[Keys.POINTS_BALANCE] = (current + delta).coerceAtLeast(0)
        }
    }

    suspend fun redeemReward(rewardId: String, title: String, cost: Int): Boolean {
        var success = false
        context.lumenDataStore.edit { prefs ->
            val current = prefs[Keys.POINTS_BALANCE] ?: 120
            val existingSet = (prefs[Keys.UNLOCKED_REWARDS] ?: "")
                .split(",")
                .filter { it.isNotBlank() }
                .toMutableSet()
            if (rewardId !in existingSet && current >= cost) {
                existingSet.add(rewardId)
                prefs[Keys.POINTS_BALANCE] = current - cost
                prefs[Keys.UNLOCKED_REWARDS] = existingSet.joinToString(",")
                prefs[Keys.ACTIVE_ACCENT_TITLE] = title
                success = true
            }
        }
        return success
    }

    suspend fun updateMaxStreak(currentStreak: Int) {
        context.lumenDataStore.edit { prefs ->
            val best = prefs[Keys.MAX_STREAK_DAYS] ?: 1
            if (currentStreak > best) {
                prefs[Keys.MAX_STREAK_DAYS] = currentStreak
            }
        }
    }

    suspend fun setAvatarKey(key: String) {
        context.lumenDataStore.edit { it[Keys.AVATAR_KEY] = key }
    }

    suspend fun setActiveAccentTitle(title: String) {
        context.lumenDataStore.edit { it[Keys.ACTIVE_ACCENT_TITLE] = title }
    }

    suspend fun setLastActiveSubjectId(subjectId: Long) {
        context.lumenDataStore.edit { it[Keys.LAST_ACTIVE_SUBJECT_ID] = subjectId }
    }
}
