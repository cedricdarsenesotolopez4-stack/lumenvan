package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.configureAppCheck
import com.example.data.preferences.UserPreferences
import com.example.ui.navigation.LumenAppRoot
import com.example.ui.theme.LumenTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Paso 1 obligatorio: configurar Firebase App Check con el Intent de lanzamiento
        // antes de inicializar ViewModels, UI o cualquier operación de Firebase AI Logic.
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val container = (application as LumenApplication).container

        setContent {
            val prefs by container.preferencesRepository.preferences
                .collectAsStateWithLifecycle(initialValue = UserPreferences())

            LumenTheme(darkTheme = prefs.isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LumenAppRoot(container = container)
                }
            }
        }
    }
}
