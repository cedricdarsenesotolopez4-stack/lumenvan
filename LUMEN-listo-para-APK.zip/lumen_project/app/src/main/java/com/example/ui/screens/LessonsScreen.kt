package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.LessonEntity
import com.example.ui.components.Lumen3dOrbitalNode
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenCounterPill
import com.example.ui.components.LumenElectricButton
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.components.NodeVisualState
import com.example.ui.components.courseCoverDrawable
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.LessonsCatalogState
import com.example.ui.viewmodel.LessonsViewModel
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun LessonsCatalogScreen(
    state: LessonsCatalogState,
    onSelectLesson: (LessonEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var selectedCourseId by remember(state.courses) {
        mutableLongStateOf(state.courses.firstOrNull()?.id ?: 0L)
    }
    val activeCourse = state.courses.find { it.id == selectedCourseId } ?: state.courses.firstOrNull()
    val courseLessons = state.lessons.filter { it.courseId == (activeCourse?.id ?: -1L) }
    val activeLesson = courseLessons.firstOrNull { !it.isCompleted && it.isUnlocked }
        ?: courseLessons.firstOrNull { it.isUnlocked }
        ?: courseLessons.firstOrNull()

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("lessons_catalog_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                LumenSectionHeader(
                    title = "Camino de aprendizaje",
                    subtitle = "Nodos secuenciales 3D por etapas"
                )
            }

            if (state.courses.isNotEmpty()) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.courses, key = { it.id }) { course ->
                            FilterChip(
                                selected = activeCourse?.id == course.id,
                                onClick = { selectedCourseId = course.id },
                                label = { Text(course.title) }
                            )
                        }
                    }
                }
            }

            activeCourse?.let { course ->
                val subject = state.subjects.find { it.id == course.subjectId }
                val completedCount = courseLessons.count { it.isCompleted }
                val progress = if (courseLessons.isNotEmpty()) completedCount.toFloat() / courseLessons.size else 0f

                item {
                    LumenGlassPanel(
                        glowColor = lumenColors.electricBlue,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(132.dp)
                        ) {
                            Image(
                                painter = painterResource(id = courseCoverDrawable(course.coverKey)),
                                contentDescription = course.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0x3304060B), Color(0xEC070A12))
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(16.dp)
                            ) {
                                LumenMonospaceTag(text = "${subject?.name ?: "PROGRAMA"} · ${course.level}")
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = course.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color(0xFFF6F5F0)
                                )
                            }
                        }
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = course.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = lumenColors.electricBlueBright,
                                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                LumenCounterPill(
                                    label = "LECCIONES COMPLETADAS",
                                    value = "%02d/%02d".format(completedCount, courseLessons.size)
                                )
                            }
                        }
                    }
                }
            }

            // Ruta vertical 3D escalonada (referencia visual #2)
            itemsIndexed(courseLessons, key = { _, item -> item.id }) { idx, lesson ->
                val nodeState = when {
                    lesson.isCompleted -> NodeVisualState.COMPLETED
                    lesson.isUnlocked -> NodeVisualState.ACTIVE
                    else -> NodeVisualState.LOCKED
                }
                val isFirstActive = activeLesson?.id == lesson.id
                val alignEnd = idx % 2 == 1

                Column(modifier = Modifier.fillMaxWidth()) {
                    if (idx > 0) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(26.dp)
                        ) {
                            val startX = if ((idx - 1) % 2 == 1) size.width * 0.68f else size.width * 0.32f
                            val endX = if (alignEnd) size.width * 0.68f else size.width * 0.32f
                            drawLine(
                                color = lumenColors.electricBlue.copy(alpha = 0.42f),
                                start = Offset(startX, 0f),
                                end = Offset(endX, size.height),
                                strokeWidth = 3f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (!alignEnd) {
                            Lumen3dOrbitalNode(
                                state = nodeState,
                                onClick = { if (lesson.isUnlocked) onSelectLesson(lesson) },
                                floatingQuestionBubble = isFirstActive
                            )
                        }
                        LumenSurfaceCard(
                            modifier = Modifier.weight(1f),
                            containerColor = if (nodeState == NodeVisualState.LOCKED) {
                                MaterialTheme.colorScheme.surfaceContainerLowest
                            } else {
                                MaterialTheme.colorScheme.surfaceContainer
                            },
                            borderColor = when (nodeState) {
                                NodeVisualState.ACTIVE -> lumenColors.electricBlue.copy(alpha = 0.6f)
                                NodeVisualState.COMPLETED -> lumenColors.success.copy(alpha = 0.45f)
                                NodeVisualState.LOCKED -> MaterialTheme.colorScheme.outlineVariant
                            },
                            onClick = if (lesson.isUnlocked) ({ onSelectLesson(lesson) }) else null
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                LumenMonospaceTag(
                                    text = when (nodeState) {
                                        NodeVisualState.COMPLETED -> "COMPLETADA · ${lesson.scorePercent}%"
                                        NodeVisualState.ACTIVE -> if (isFirstActive) "LO QUE SIGUE" else "DISPONIBLE"
                                        NodeVisualState.LOCKED -> "BLOQUEADA"
                                    },
                                    accentColor = when (nodeState) {
                                        NodeVisualState.COMPLETED -> lumenColors.success
                                        NodeVisualState.ACTIVE -> lumenColors.electricBlueBright
                                        NodeVisualState.LOCKED -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                                Text(
                                    text = "${lesson.durationMinutes}m",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = lesson.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (nodeState == NodeVisualState.LOCKED) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                }
                            )
                            Text(
                                text = "Etapa ${lesson.currentStage + 1}/5",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (alignEnd) {
                            Lumen3dOrbitalNode(
                                state = nodeState,
                                onClick = { if (lesson.isUnlocked) onSelectLesson(lesson) },
                                floatingQuestionBubble = isFirstActive
                            )
                        }
                    }
                }
            }

            // Panel inferior "LO QUE SIGUE" con CTA eléctrico grande (referencia #2)
            activeLesson?.let { target ->
                item {
                    LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            LumenMonospaceTag(text = "LO QUE SIGUE")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = target.title,
                                style = MaterialTheme.typography.headlineMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = target.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            LumenElectricButton(
                                text = "¡Vamos!",
                                icon = Icons.Rounded.PlayArrow,
                                onClick = { onSelectLesson(target) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonDetailScreen(
    lessonId: Long,
    viewModel: LessonsViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val lesson by viewModel.observeLesson(lessonId).collectAsStateWithLifecycle(initialValue = null)
    val lumenColors = LocalLumenColors.current
    val currentLesson = lesson ?: return

    var activeStage by remember(currentLesson.id) { mutableIntStateOf(currentLesson.currentStage.coerceIn(0, 4)) }
    var selectedCompIndex by remember(currentLesson.id) { mutableIntStateOf(-1) }
    var compChecked by remember(currentLesson.id) { mutableStateOf(false) }
    var selectedEvalIndex by remember(currentLesson.id) { mutableIntStateOf(-1) }
    var evalSubmitted by remember(currentLesson.id) { mutableStateOf(currentLesson.isCompleted) }
    var activityDone by remember(currentLesson.id) { mutableStateOf(false) }

    val stageNames = listOf("Inicio", "Explicación", "Ejemplos", "Práctica", "Evaluación")

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .testTag("lesson_detail_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Volver a lecciones")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(currentLesson.title, style = MaterialTheme.typography.headlineLarge)
                        Text(
                            "${currentLesson.level.uppercase()} · ${currentLesson.durationMinutes} MIN",
                            style = MaterialTheme.typography.labelSmall,
                            color = lumenColors.electricBlueBright
                        )
                    }
                }
            }

            item {
                LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                    LessonHeroDiagram(
                        diagramType = currentLesson.diagramType,
                        electricBlue = lumenColors.electricBlueBright,
                        violet = lumenColors.violet,
                        emerald = lumenColors.success
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(currentLesson.subtitle, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(stageNames) { idx, name ->
                            FilterChip(
                                selected = activeStage == idx,
                                onClick = {
                                    activeStage = idx
                                    viewModel.advanceLessonStage(currentLesson, idx)
                                },
                                label = { Text("${idx + 1}. $name") }
                            )
                        }
                    }
                }
            }

            when (activeStage) {
                0 -> {
                    item {
                        LumenSurfaceCard {
                            LumenMonospaceTag(text = "ETAPA 01 · PANORAMA")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Panorama de la lección", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "En esta sesión recorrerás la explicación conceptual, definiciones clave, ejemplos resueltos, una actividad práctica y una evaluación final para registrar tu dominio.",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            LumenElectricButton(
                                text = if (currentLesson.currentStage > 0) "Continuar lección" else "Comenzar lección",
                                icon = Icons.Rounded.PlayArrow,
                                onClick = {
                                    activeStage = 1
                                    viewModel.advanceLessonStage(currentLesson, 1)
                                },
                                modifier = Modifier.testTag("lesson_start_button")
                            )
                        }
                    }
                }
                1 -> {
                    item {
                        LumenSurfaceCard {
                            LumenMonospaceTag(text = "ETAPA 02 · CONCEPTO")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Explicación conceptual", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(currentLesson.explanation, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    item {
                        LumenGlassPanel(glowColor = lumenColors.violet) {
                            Text(
                                "DEFINICIONES FUNDAMENTALES",
                                style = MaterialTheme.typography.labelMedium,
                                color = lumenColors.electricBlueBright
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            currentLesson.definitionsRaw.split("|||").forEach { entry ->
                                val parts = entry.split("::")
                                if (parts.size == 2) {
                                    Text(parts[0], style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        parts[1],
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                            }
                            LumenElectricButton(
                                text = "Ir a ejemplos y comprensión",
                                onClick = {
                                    activeStage = 2
                                    viewModel.advanceLessonStage(currentLesson, 2)
                                }
                            )
                        }
                    }
                }
                2 -> {
                    item {
                        LumenSurfaceCard {
                            LumenMonospaceTag(text = "ETAPA 03 · EJEMPLOS")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Ejemplos comentados", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            currentLesson.examplesRaw.split("|||").forEach { ex ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                                        .padding(14.dp)
                                ) {
                                    Text(ex, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    item {
                        val options = currentLesson.comprehensionOptionsRaw.split("|||")
                        LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                            Text(
                                "COMPROBACIÓN DE COMPRENSIÓN",
                                style = MaterialTheme.typography.labelMedium,
                                color = lumenColors.electricBlueBright
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(currentLesson.comprehensionQuestion, style = MaterialTheme.typography.bodyLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            options.forEachIndexed { idx, opt ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedCompIndex = idx
                                            compChecked = false
                                        }
                                        .padding(vertical = 4.dp)
                                ) {
                                    RadioButton(
                                        selected = selectedCompIndex == idx,
                                        onClick = {
                                            selectedCompIndex = idx
                                            compChecked = false
                                        }
                                    )
                                    Text(opt, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            if (compChecked) {
                                val isRight = selectedCompIndex == currentLesson.comprehensionAnswerIndex
                                Text(
                                    text = if (isRight) "Correcto. Has captado la idea central." else "Revisa de nuevo la definición: la opción correcta es «${options.getOrNull(currentLesson.comprehensionAnswerIndex).orEmpty()}».",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isRight) lumenColors.success else MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = { compChecked = true },
                                    enabled = selectedCompIndex >= 0
                                ) { Text("Comprobar") }
                                Box(modifier = Modifier.weight(1f)) {
                                    LumenElectricButton(
                                        text = "Ir a práctica",
                                        onClick = {
                                            activeStage = 3
                                            viewModel.advanceLessonStage(currentLesson, 3)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                3 -> {
                    item {
                        LumenSurfaceCard {
                            LumenMonospaceTag(text = "ETAPA 04 · PRÁCTICA")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Ejercicio y actividad práctica", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(currentLesson.practicalActivity, style = MaterialTheme.typography.bodyLarge)
                            Spacer(modifier = Modifier.height(14.dp))
                            OutlinedButton(
                                onClick = { activityDone = !activityDone },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.CheckCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (activityDone) "Actividad realizada" else "Marcar actividad como realizada")
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            LumenElectricButton(
                                text = "Ir a evaluación final",
                                onClick = {
                                    activeStage = 4
                                    viewModel.advanceLessonStage(currentLesson, 4)
                                }
                            )
                        }
                    }
                }
                4 -> {
                    item {
                        val evalOptions = currentLesson.evaluationOptionsRaw.split("|||")
                        LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                            LumenMonospaceTag(text = "ETAPA 05 · EVALUACIÓN FINAL")
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(currentLesson.evaluationQuestion, style = MaterialTheme.typography.bodyLarge)
                            Spacer(modifier = Modifier.height(10.dp))
                            evalOptions.forEachIndexed { idx, opt ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedEvalIndex = idx }
                                        .padding(vertical = 4.dp)
                                ) {
                                    RadioButton(
                                        selected = selectedEvalIndex == idx,
                                        onClick = { selectedEvalIndex = idx }
                                    )
                                    Text(opt, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            LumenElectricButton(
                                text = "Registrar evaluación",
                                enabled = selectedEvalIndex >= 0,
                                onClick = {
                                    val score = if (selectedEvalIndex == currentLesson.evaluationAnswerIndex) 100 else 60
                                    evalSubmitted = true
                                    viewModel.completeLessonEvaluation(currentLesson, score)
                                },
                                modifier = Modifier.testTag("lesson_submit_evaluation")
                            )

                            if (evalSubmitted) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Lección registrada en tu progreso (${currentLesson.scorePercent.coerceAtLeast(if (selectedEvalIndex == currentLesson.evaluationAnswerIndex) 100 else 60)}%).",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = lumenColors.success
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonHeroDiagram(
    diagramType: String,
    electricBlue: Color,
    violet: Color,
    emerald: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(144.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF04060B))
            .border(1.dp, electricBlue.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            for (i in 1..4) {
                val y = h * (i / 5f)
                drawLine(Color.White.copy(alpha = 0.06f), Offset(0f, y), Offset(w, y), 1f)
            }
            for (i in 1..6) {
                val x = w * (i / 7f)
                drawLine(Color.White.copy(alpha = 0.06f), Offset(x, 0f), Offset(x, h), 1f)
            }

            when (diagramType) {
                "WAVE" -> {
                    val path = Path()
                    val steps = 80
                    for (i in 0..steps) {
                        val t = i.toFloat() / steps
                        val x = t * w
                        val y = h * 0.5f + sin(t * 4f * PI).toFloat() * (h * 0.32f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, color = electricBlue, style = Stroke(width = 5f))
                    drawLine(violet.copy(alpha = 0.55f), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 2f)
                }
                "CELL" -> {
                    drawCircle(violet.copy(alpha = 0.24f), radius = h * 0.44f, center = Offset(w * 0.5f, h * 0.5f))
                    drawCircle(violet, radius = h * 0.44f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(3.5f))
                    drawCircle(electricBlue.copy(alpha = 0.28f), radius = h * 0.22f, center = Offset(w * 0.5f, h * 0.5f))
                    drawCircle(electricBlue, radius = h * 0.22f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(3f))
                    drawCircle(emerald, radius = 8f, center = Offset(w * 0.28f, h * 0.42f))
                    drawCircle(emerald, radius = 8f, center = Offset(w * 0.72f, h * 0.58f))
                }
                "TIMELINE" -> {
                    drawLine(electricBlue, Offset(w * 0.08f, h * 0.5f), Offset(w * 0.92f, h * 0.5f), 4f)
                    listOf(0.15f, 0.4f, 0.65f, 0.88f).forEachIndexed { idx, frac ->
                        val cx = w * frac
                        drawCircle(if (idx % 2 == 0) electricBlue else violet, radius = 11f, center = Offset(cx, h * 0.5f))
                        drawCircle(Color.White.copy(alpha = 0.6f), radius = 11f, center = Offset(cx, h * 0.5f), style = Stroke(2f))
                    }
                }
                else -> {
                    val curve = Path()
                    for (i in 0..60) {
                        val t = i / 60f
                        val x = w * (0.1f + 0.8f * t)
                        val y = h * (0.85f - 0.72f * t * t)
                        if (i == 0) curve.moveTo(x, y) else curve.lineTo(x, y)
                    }
                    drawPath(curve, color = electricBlue, style = Stroke(width = 5f))
                    val px = w * 0.58f
                    val py = h * (0.85f - 0.72f * 0.6f * 0.6f)
                    drawLine(violet, Offset(px - w * 0.24f, py + h * 0.26f), Offset(px + w * 0.24f, py - h * 0.26f), 3.5f)
                    drawCircle(Color.White, radius = 8f, center = Offset(px, py))
                }
            }
        }
    }
}
