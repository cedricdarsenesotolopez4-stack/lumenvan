package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val folder: String,
    val tagsCsv: String,
    val category: String, // Apunte, Definición, Resumen, Documento, Referencia
    val referenceSource: String = "",
    val subjectName: String,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "flashcards")
data class FlashcardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val front: String,
    val back: String,
    val masteryLevel: Int = 0, // 0..5
    val easeFactor: Double = 2.5,
    val intervalDays: Int = 1,
    val repetitions: Int = 0,
    val nextReviewAt: Long = System.currentTimeMillis(),
    val lastReviewedAt: Long = 0L
)

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subjectName: String,
    val description: String,
    val bestScorePercent: Int = 0,
    val attemptsCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "quiz_questions",
    foreignKeys = [
        ForeignKey(
            entity = QuizEntity::class,
            parentColumns = ["id"],
            childColumns = ["quizId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("quizId")]
)
data class QuizQuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: Long,
    val questionType: String, // "MULTIPLE", "TRUE_FALSE", "OPEN"
    val prompt: String,
    val optionsRaw: String, // "|||" separated
    val correctAnswer: String,
    val explanation: String
)

@Entity(tableName = "lab_entries")
data class LabEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val toolName: String,
    val inputTopic: String,
    val generatedOutput: String,
    val observations: String = "",
    val savedToLibrary: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
