package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.QuizEntity
import com.example.data.local.entity.QuizQuestionEntity
import com.example.ui.components.LumenBadge
import com.example.ui.components.LumenCounterPill
import com.example.ui.components.LumenElectricButton
import com.example.ui.components.LumenGlassDialog
import com.example.ui.components.LumenGlassPanel
import com.example.ui.components.LumenMonospaceTag
import com.example.ui.components.LumenSectionHeader
import com.example.ui.components.LumenSurfaceCard
import com.example.ui.theme.LocalLumenColors
import com.example.ui.viewmodel.LibraryUiState
import com.example.ui.viewmodel.LibraryViewModel

@Composable
fun LibraryScreen(
    state: LibraryUiState,
    viewModel: LibraryViewModel,
    onOpenImportExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lumenColors = LocalLumenColors.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
    var showFlashcardDialog by remember { mutableStateOf(false) }
    var showCreateQuizDialog by remember { mutableStateOf(false) }
    var activeQuiz by remember { mutableStateOf<QuizEntity?>(null) }
    var reviewingCards by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> {
                            editingNote = null
                            showNoteDialog = true
                        }
                        1 -> showFlashcardDialog = true
                        else -> showCreateQuizDialog = true
                    }
                },
                containerColor = lumenColors.electricBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("library_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Crear en Biblioteca")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = lumenColors.glassSurface,
                contentColor = lumenColors.electricBlueBright
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Apuntes (${state.notes.size})") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Flashcards (${state.flashcards.size})") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Tests (${state.quizzes.size})") })
            }

            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                when (selectedTab) {
                    0 -> NotesTabContent(
                        state = state,
                        viewModel = viewModel,
                        onEditNote = { note ->
                            editingNote = note
                            showNoteDialog = true
                        },
                        onOpenImportExport = onOpenImportExport
                    )
                    1 -> FlashcardsTabContent(
                        state = state,
                        viewModel = viewModel,
                        reviewing = reviewingCards,
                        onToggleReview = { reviewingCards = it }
                    )
                    else -> QuizzesTabContent(
                        state = state,
                        viewModel = viewModel,
                        activeQuiz = activeQuiz,
                        onOpenQuiz = { activeQuiz = it }
                    )
                }
            }
        }
    }

    if (showNoteDialog) {
        NoteEditorDialog(
            initial = editingNote,
            onDismiss = { showNoteDialog = false },
            onConfirm = { title, content, folder, tags, cat, ref, subject ->
                viewModel.saveNote(
                    id = editingNote?.id ?: 0L,
                    title = title,
                    content = content,
                    folder = folder,
                    tagsCsv = tags,
                    category = cat,
                    referenceSource = ref,
                    subjectName = subject,
                    isFavorite = editingNote?.isFavorite ?: false
                )
                showNoteDialog = false
            }
        )
    }

    if (showFlashcardDialog) {
        CreateFlashcardDialog(
            onDismiss = { showFlashcardDialog = false },
            onConfirm = { subject, front, back ->
                viewModel.saveFlashcard(subject, front, back)
                showFlashcardDialog = false
            }
        )
    }

    if (showCreateQuizDialog) {
        CreateQuizDialog(
            onDismiss = { showCreateQuizDialog = false },
            onConfirm = { title, subject, desc, questions ->
                viewModel.createQuiz(title, subject, desc, questions)
                showCreateQuizDialog = false
            }
        )
    }
}

@Composable
private fun NotesTabContent(
    state: LibraryUiState,
    viewModel: LibraryViewModel,
    onEditNote: (NoteEntity) -> Unit,
    onOpenImportExport: () -> Unit
) {
    val lumenColors = LocalLumenColors.current
    val categories = listOf("Todas", "Apunte", "Definición", "Resumen", "Documento", "Referencia")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 840.dp)
            .testTag("library_notes_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LumenGlassPanel(contentPadding = PaddingValues(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = viewModel::updateSearch,
                        placeholder = { Text("Buscar apuntes, etiquetas o citas...") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("library_search_input")
                    )
                    OutlinedButton(onClick = onOpenImportExport) {
                        Icon(Icons.Rounded.UploadFile, contentDescription = "Importar o exportar")
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = state.onlyFavorites,
                            onClick = { viewModel.toggleOnlyFavorites() },
                            label = { Text("Favoritos") }
                        )
                    }
                    items(categories) { cat ->
                        FilterChip(
                            selected = state.selectedCategory == cat,
                            onClick = { viewModel.selectCategory(cat) },
                            label = { Text(cat) }
                        )
                    }
                }
                if (state.folders.size > 1) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.folders) { folder ->
                            FilterChip(
                                selected = state.selectedFolder == folder,
                                onClick = { viewModel.selectFolder(folder) },
                                label = { Text("Carpeta: $folder") }
                            )
                        }
                    }
                }
            }
        }

        if (state.notes.isEmpty()) {
            item {
                LumenSurfaceCard {
                    Text(
                        "No hay materiales con este filtro. Pulsa + para crear un apunte, definición, resumen o referencia.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(state.notes, key = { it.id }) { note ->
                LumenSurfaceCard(
                    onClick = { onEditNote(note) },
                    modifier = Modifier.testTag("note_card_${note.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            LumenBadge(
                                text = note.category,
                                containerColor = lumenColors.blueContainer,
                                contentColor = lumenColors.electricBlueBright
                            )
                            LumenBadge(
                                text = note.folder,
                                containerColor = lumenColors.violetContainer,
                                contentColor = lumenColors.violet
                            )
                        }
                        Row {
                            IconButton(onClick = { viewModel.toggleFavorite(note) }) {
                                Icon(
                                    imageVector = if (note.isFavorite) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = "Marcar favorito",
                                    tint = if (note.isFavorite) lumenColors.electricBlueBright else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onEditNote(note) }) {
                                Icon(Icons.Rounded.Edit, contentDescription = "Editar apunte")
                            }
                            IconButton(onClick = { viewModel.deleteNote(note) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar apunte", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                    Text(note.title, style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = note.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 4
                    )
                    if (note.referenceSource.isNotBlank() || note.tagsCsv.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = buildString {
                                append(note.subjectName.uppercase())
                                if (note.referenceSource.isNotBlank()) append(" · ${note.referenceSource}")
                                if (note.tagsCsv.isNotBlank()) append(" · #${note.tagsCsv.replace(",", " #")}")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = lumenColors.violet
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FlashcardsTabContent(
    state: LibraryUiState,
    viewModel: LibraryViewModel,
    reviewing: Boolean,
    onToggleReview: (Boolean) -> Unit
) {
    val lumenColors = LocalLumenColors.current
    var showAnswer by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 840.dp)
            .testTag("library_flashcards_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LumenGlassPanel(glowColor = lumenColors.electricBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LumenSectionHeader(
                        title = "Repaso espaciado",
                        subtitle = "Algoritmo SM-2 activo",
                        modifier = Modifier.weight(1f)
                    )
                    LumenCounterPill(
                        label = "HOY",
                        value = "%02d".format(state.dueFlashcards.size)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                LumenElectricButton(
                    text = if (reviewing) "Salir del modo repaso" else "Comenzar sesión de repaso",
                    icon = Icons.Rounded.Flip,
                    enabled = state.flashcards.isNotEmpty(),
                    onClick = {
                        showAnswer = false
                        onToggleReview(!reviewing)
                    },
                    modifier = Modifier.testTag("start_flashcard_review_button")
                )
            }
        }

        if (reviewing) {
            val activeCard = state.dueFlashcards.firstOrNull() ?: state.flashcards.firstOrNull()
            if (activeCard == null) {
                item {
                    LumenSurfaceCard {
                        Text("No hay tarjetas disponibles todavía.")
                    }
                }
            } else {
                item {
                    LumenGlassPanel(
                        glowColor = lumenColors.violet,
                        onClick = { showAnswer = !showAnswer },
                        modifier = Modifier.testTag("flashcard_review_card")
                    ) {
                        LumenMonospaceTag(
                            text = "${activeCard.subjectName} · NIVEL ${activeCard.masteryLevel}/5 · ${activeCard.intervalDays}D",
                            accentColor = lumenColors.violet
                        )
                        Spacer(modifier = Modifier.height(22.dp))
                        Text(
                            text = if (showAnswer) activeCard.back else activeCard.front,
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (showAnswer) "EVALÚA TU RECUERDO" else "TOCA LA TARJETA PARA REVELAR LA RESPUESTA",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (showAnswer) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        showAnswer = false
                                        viewModel.reviewFlashcard(activeCard, 1)
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Difícil") }
                                OutlinedButton(
                                    onClick = {
                                        showAnswer = false
                                        viewModel.reviewFlashcard(activeCard, 3)
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Bien") }
                                Button(
                                    onClick = {
                                        showAnswer = false
                                        viewModel.reviewFlashcard(activeCard, 5)
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Dominada") }
                            }
                        }
                    }
                }
            }
        } else {
            items(state.flashcards, key = { it.id }) { card ->
                LumenSurfaceCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LumenBadge(
                            text = "${card.subjectName} · Nivel ${card.masteryLevel}/5 · ${card.intervalDays}d",
                            containerColor = lumenColors.blueContainer,
                            contentColor = lumenColors.electricBlueBright
                        )
                        IconButton(onClick = { viewModel.deleteFlashcard(card) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Eliminar flashcard", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    Text(card.front, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        card.back,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun QuizzesTabContent(
    state: LibraryUiState,
    viewModel: LibraryViewModel,
    activeQuiz: QuizEntity?,
    onOpenQuiz: (QuizEntity?) -> Unit
) {
    val lumenColors = LocalLumenColors.current

    if (activeQuiz != null) {
        val questions by viewModel.observeQuizQuestions(activeQuiz.id).collectAsStateWithLifecycle(initialValue = emptyList())
        QuizRunnerCard(
            quiz = activeQuiz,
            questions = questions,
            onFinish = { score ->
                viewModel.recordQuizAttempt(activeQuiz, score)
            },
            onClose = { onOpenQuiz(null) }
        )
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 840.dp)
            .testTag("library_quizzes_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LumenSectionHeader(
                title = "Cuestionarios personales",
                subtitle = "Opción múltiple, V/F y respuesta abierta"
            )
        }
        items(state.quizzes, key = { it.id }) { quiz ->
            LumenSurfaceCard(onClick = { onOpenQuiz(quiz) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LumenBadge(
                        text = "${quiz.subjectName} · Mejor: ${quiz.bestScorePercent}%",
                        containerColor = lumenColors.blueContainer,
                        contentColor = lumenColors.electricBlueBright
                    )
                    IconButton(onClick = { viewModel.deleteQuiz(quiz) }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Eliminar cuestionario", tint = MaterialTheme.colorScheme.error)
                    }
                }
                Text(quiz.title, style = MaterialTheme.typography.titleLarge)
                Text(
                    quiz.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                LumenElectricButton(
                    text = "Responder cuestionario",
                    icon = Icons.Rounded.PlayArrow,
                    onClick = { onOpenQuiz(quiz) }
                )
            }
        }
    }
}

@Composable
private fun QuizRunnerCard(
    quiz: QuizEntity,
    questions: List<QuizQuestionEntity>,
    onFinish: (Int) -> Unit,
    onClose: () -> Unit
) {
    val lumenColors = LocalLumenColors.current
    var answers by remember(quiz.id) { mutableStateOf(mapOf<Long, String>()) }
    var submitted by remember(quiz.id) { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 840.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(quiz.title, style = MaterialTheme.typography.headlineLarge)
                    Text(
                        "${questions.size} PREGUNTAS · ${quiz.subjectName.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = lumenColors.electricBlueBright
                    )
                }
                TextButton(onClick = onClose) { Text("Salir") }
            }
        }

        items(questions, key = { it.id }) { q ->
            val currentAns = answers[q.id].orEmpty()
            LumenSurfaceCard {
                LumenBadge(
                    text = when (q.questionType) {
                        "TRUE_FALSE" -> "Verdadero / Falso"
                        "OPEN" -> "Respuesta abierta"
                        else -> "Opción múltiple"
                    },
                    containerColor = lumenColors.violetContainer,
                    contentColor = lumenColors.violet
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(q.prompt, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                if (q.questionType == "OPEN") {
                    OutlinedTextField(
                        value = currentAns,
                        onValueChange = { answers = answers + (q.id to it) },
                        label = { Text("Tu respuesta") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    q.optionsRaw.split("|||").forEach { opt ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { answers = answers + (q.id to opt) }
                        ) {
                            RadioButton(
                                selected = currentAns == opt,
                                onClick = { answers = answers + (q.id to opt) }
                            )
                            Text(opt, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                if (submitted) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Referencia: ${q.correctAnswer} — ${q.explanation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = lumenColors.electricBlueBright
                    )
                }
            }
        }

        item {
            LumenElectricButton(
                text = if (submitted) "Evaluación registrada" else "Finalizar y calificar",
                icon = Icons.Rounded.Quiz,
                onClick = {
                    val correct = questions.count { q ->
                        val ans = answers[q.id].orEmpty().trim()
                        if (q.questionType == "OPEN") {
                            ans.isNotBlank() && (ans.contains(q.correctAnswer, ignoreCase = true) || ans.length >= 12)
                        } else {
                            ans.equals(q.correctAnswer, ignoreCase = true)
                        }
                    }
                    val score = if (questions.isNotEmpty()) (correct * 100) / questions.size else 100
                    submitted = true
                    onFinish(score)
                }
            )
        }
    }
}

@Composable
private fun NoteEditorDialog(
    initial: NoteEntity?,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var content by remember { mutableStateOf(initial?.content ?: "") }
    var folder by remember { mutableStateOf(initial?.folder ?: "General") }
    var tags by remember { mutableStateOf(initial?.tagsCsv ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "Apunte") }
    var ref by remember { mutableStateOf(initial?.referenceSource ?: "") }
    var subject by remember { mutableStateOf(initial?.subjectName ?: "General") }

    LumenGlassDialog(
        title = if (initial == null) "Nuevo material en Biblioteca" else "Editar material",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(title, content, folder, tags, category, ref, subject) },
                enabled = title.isNotBlank() && content.isNotBlank(),
                modifier = Modifier.testTag("save_note_button")
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) {
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Título *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("note_title_input")
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Apunte", "Definición", "Resumen").forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            label = { Text("Contenido *") },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth().testTag("note_content_input")
        )
        OutlinedTextField(value = folder, onValueChange = { folder = it }, label = { Text("Carpeta") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Materia") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text("Etiquetas (separadas por coma)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ref, onValueChange = { ref = it }, label = { Text("Referencia / Fuente") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CreateFlashcardDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var subject by remember { mutableStateOf("Matemáticas") }
    var front by remember { mutableStateOf("") }
    var back by remember { mutableStateOf("") }

    LumenGlassDialog(
        title = "Nueva tarjeta de memoria",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onConfirm(subject, front, back) },
                enabled = front.isNotBlank() && back.isNotBlank()
            ) { Text("Crear tarjeta") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) {
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Materia") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = front, onValueChange = { front = it }, label = { Text("Pregunta / Anverso *") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = back, onValueChange = { back = it }, label = { Text("Respuesta / Reverso *") }, maxLines = 4, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CreateQuizDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, List<QuizQuestionEntity>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("General") }
    var qPrompt by remember { mutableStateOf("") }
    var qType by remember { mutableStateOf("MULTIPLE") }
    var qOptions by remember { mutableStateOf("Opción A|||Opción B|||Opción C") }
    var qAnswer by remember { mutableStateOf("Opción A") }

    LumenGlassDialog(
        title = "Crear cuestionario personal",
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val question = QuizQuestionEntity(
                        quizId = 0L,
                        questionType = qType,
                        prompt = qPrompt.trim(),
                        optionsRaw = if (qType == "OPEN") "" else qOptions.trim(),
                        correctAnswer = qAnswer.trim(),
                        explanation = "Definido por el estudiante en Biblioteca."
                    )
                    onConfirm(title, subject, "Cuestionario creado manualmente en LUMEN", listOf(question))
                },
                enabled = title.isNotBlank() && qPrompt.isNotBlank() && qAnswer.isNotBlank()
            ) { Text("Guardar test") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) {
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título del test *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Materia") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = qType == "MULTIPLE", onClick = { qType = "MULTIPLE" }, label = { Text("Múltiple") })
            FilterChip(selected = qType == "TRUE_FALSE", onClick = {
                qType = "TRUE_FALSE"
                qOptions = "Verdadero|||Falso"
                qAnswer = "Verdadero"
            }, label = { Text("V / F") })
            FilterChip(selected = qType == "OPEN", onClick = { qType = "OPEN" }, label = { Text("Abierta") })
        }
        OutlinedTextField(value = qPrompt, onValueChange = { qPrompt = it }, label = { Text("Primera pregunta *") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
        if (qType != "OPEN") {
            OutlinedTextField(value = qOptions, onValueChange = { qOptions = it }, label = { Text("Opciones separadas por |||") }, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(value = qAnswer, onValueChange = { qAnswer = it }, label = { Text("Respuesta esperada *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    }
}
