# Generar el APK instalable de LUMEN

## Opción rápida: Android Studio

1. Instala Android Studio.
2. Abre la carpeta `LUMEN`.
3. Espera a que Gradle sincronice el proyecto.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de prueba quedará en `app/build/outputs/apk/debug/`.
6. Pásalo al teléfono e instálalo.

El proyecto ya incluye un `debug.keystore` para el tipo de compilación `debugConfig` que usa este proyecto.

## Opción automática: GitHub Actions

El repositorio incluye `.github/workflows/build-apk.yml`. Sube el proyecto a GitHub y ejecuta **Actions > Build LUMEN APK > Run workflow**. El APK aparecerá como artefacto descargable del workflow.

> Nota: para las funciones de IA/Firebase, el proyecto ya contiene `google-services.json`. No publiques ese archivo ni tus credenciales privadas en un repositorio público si el proyecto real usa datos sensibles.
